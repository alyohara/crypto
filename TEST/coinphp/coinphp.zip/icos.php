<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from mize.market/icos by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Apr 2018 20:58:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">

        <link rel="shorcut icon" type="image/png" href="images/1524688798.png">
    
    <title>Mize Market - CryptoCurrency Markets</title>
    <meta name="description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <link rel="canonical" href="icos.php" />


    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="icos.php"/>
    <meta property="og:title" content="CryptoCurrency Markets"/>
    <meta property="og:description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <meta property="og:site_name" content="Mize Market"/>
    

    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <meta name="twitter:title" content="CryptoCurrency Markets"/>
    <meta name="twitter:url" content="icos.php"/>
            
    <meta name="theme-color" content="#FFD700">

            <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.css">
            <link rel="stylesheet" href="assets/frontend/css/frontend.css">
    
    <style>
        #top-menu {background-color: #ffffff;}
        #top-menu .item {color: #333333;}
        
        @media only screen and (max-width: 1024px) {
            #top-menu .price-currency-item, #top-menu .menu-item  {
                display: none;
            }
        }

        @media only screen and (min-width: 1024px) {
            #sidebar-menu-toggle  {
                display: none;
            }
        }

                #sidebar-menu {background-color: #ffffff;}
        #sidebar-menu .item {color: #333333;}
        #header-logo {height: 50px; }
        #stats {padding-top: 130px;}
        #footer {background-color: #f3f3f3;}
        #footer-main h1, #footer-main h1 .sub.header {color: #333333;}
        #footer-main h3 {color: #222222;}
        #footer-main .item, #footer-main .item i {color: #333333;}
        #footer-bottom-bar, #footer-bottom-bar a {
            background-color: #f0f0f0;
            color: #333333;
        }
    </style>

    <style></style>
</head>
<body>

<div id="sidebar-menu" class="ui big vertical sidebar menu left">
    <a class="item menu-item" href="market.php">Market</a><a class="item menu-item" href="converter.php">Converter</a><a class="item menu-item" href="icos.php">ICOs</a><a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/">Facebook&nbsp;<i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg">Youtube&nbsp;<i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/">Instagram&nbsp;<i class="instagram icon"></i></a>    <div class="item">
        <select class="price-currency fluid ui search dropdown"><option value="BTC">Bitcoin</option><option selected value="USD">US Dollar</option><option value="EUR">Eurozone Euro</option><option value="GBP">Pound Sterling</option><option value="JPY">Japanese Yen</option><option value="CAD">Canadian Dollar</option><option value="AUD">Australian Dollar</option><option value="CNY">Chinese Yuan</option><option value="CHF">Swiss Franc</option><option value="SEK">Swedish Krona</option><option value="NZD">New Zealand Dollar</option><option value="KRW">South Korean Won</option><option value="AED">UAE Dirham</option><option value="AFN">Afghan Afghani</option><option value="ALL">Albanian Lek</option><option value="AMD">Armenian Dram</option><option value="ANG">Netherlands Antillean Guilder</option><option value="AOA">Angolan Kwanza</option><option value="ARS">Argentine Peso</option><option value="AWG">Aruban Florin</option><option value="AZN">Azerbaijani Manat</option><option value="BAM">Bosnia-Herzegovina Convertible Mark</option><option value="BBD">Barbadian Dollar</option><option value="BDT">Bangladeshi Taka</option><option value="BGN">Bulgarian Lev</option><option value="BHD">Bahraini Dinar</option><option value="BIF">Burundian Franc</option><option value="BMD">Bermudan Dollar</option><option value="BND">Brunei Dollar</option><option value="BOB">Bolivian Boliviano</option><option value="BRL">Brazilian Real</option><option value="BSD">Bahamian Dollar</option><option value="BTN">Bhutanese Ngultrum</option><option value="BWP">Botswanan Pula</option><option value="BZD">Belize Dollar</option><option value="CDF">Congolese Franc</option><option value="CLF">Chilean Unit of Account (UF)</option><option value="CLP">Chilean Peso</option><option value="COP">Colombian Peso</option><option value="CRC">Costa Rican Colón</option><option value="CUP">Cuban Peso</option><option value="CVE">Cape Verdean Escudo</option><option value="CZK">Czech Koruna</option><option value="DJF">Djiboutian Franc</option><option value="DKK">Danish Krone</option><option value="DOP">Dominican Peso</option><option value="DZD">Algerian Dinar</option><option value="EGP">Egyptian Pound</option><option value="ETB">Ethiopian Birr</option><option value="FJD">Fijian Dollar</option><option value="FKP">Falkland Islands Pound</option><option value="GEL">Georgian Lari</option><option value="GHS">Ghanaian Cedi</option><option value="GIP">Gibraltar Pound</option><option value="GMD">Gambian Dalasi</option><option value="GNF">Guinean Franc</option><option value="GTQ">Guatemalan Quetzal</option><option value="GYD">Guyanaese Dollar</option><option value="HKD">Hong Kong Dollar</option><option value="HNL">Honduran Lempira</option><option value="HRK">Croatian Kuna</option><option value="HTG">Haitian Gourde</option><option value="HUF">Hungarian Forint</option><option value="IDR">Indonesian Rupiah</option><option value="ILS">Israeli Shekel</option><option value="INR">Indian Rupee</option><option value="IQD">Iraqi Dinar</option><option value="IRR">Iranian Rial</option><option value="ISK">Icelandic Króna</option><option value="JEP">Jersey Pound</option><option value="JMD">Jamaican Dollar</option><option value="JOD">Jordanian Dinar</option><option value="KES">Kenyan Shilling</option><option value="KGS">Kyrgystani Som</option><option value="KHR">Cambodian Riel</option><option value="KMF">Comorian Franc</option><option value="KPW">North Korean Won</option><option value="KWD">Kuwaiti Dinar</option><option value="KYD">Cayman Islands Dollar</option><option value="KZT">Kazakhstani Tenge</option><option value="LAK">Laotian Kip</option><option value="LBP">Lebanese Pound</option><option value="LKR">Sri Lankan Rupee</option><option value="LRD">Liberian Dollar</option><option value="LSL">Lesotho Loti</option><option value="LYD">Libyan Dinar</option><option value="MAD">Moroccan Dirham</option><option value="MDL">Moldovan Leu</option><option value="MGA">Malagasy Ariary</option><option value="MKD">Macedonian Denar</option><option value="MMK">Myanma Kyat</option><option value="MNT">Mongolian Tugrik</option><option value="MOP">Macanese Pataca</option><option value="MRU">Mauritanian Ouguiya</option><option value="MUR">Mauritian Rupee</option><option value="MVR">Maldivian Rufiyaa</option><option value="MWK">Malawian Kwacha</option><option value="MXN">Mexican Peso</option><option value="MYR">Malaysian Ringgit</option><option value="MZN">Mozambican Metical</option><option value="NAD">Namibian Dollar</option><option value="NGN">Nigerian Naira</option><option value="NIO">Nicaraguan Córdoba</option><option value="NOK">Norwegian Krone</option><option value="NPR">Nepalese Rupee</option><option value="OMR">Omani Rial</option><option value="PAB">Panamanian Balboa</option><option value="PEN">Peruvian Nuevo Sol</option><option value="PGK">Papua New Guinean Kina</option><option value="PHP">Philippine Peso</option><option value="PKR">Pakistani Rupee</option><option value="PLN">Polish Zloty</option><option value="PYG">Paraguayan Guarani</option><option value="QAR">Qatari Rial</option><option value="RON">Romanian Leu</option><option value="RSD">Serbian Dinar</option><option value="RUB">Russian Ruble</option><option value="RWF">Rwandan Franc</option><option value="SAR">Saudi Riyal</option><option value="SBD">Solomon Islands Dollar</option><option value="SCR">Seychellois Rupee</option><option value="SDG">Sudanese Pound</option><option value="SGD">Singapore Dollar</option><option value="SHP">Saint Helena Pound</option><option value="SLL">Sierra Leonean Leone</option><option value="SOS">Somali Shilling</option><option value="SRD">Surinamese Dollar</option><option value="STN">São Tomé and Príncipe Dobra</option><option value="SVC">Salvadoran Colón</option><option value="SYP">Syrian Pound</option><option value="SZL">Swazi Lilangeni</option><option value="THB">Thai Baht</option><option value="TJS">Tajikistani Somoni</option><option value="TMT">Turkmenistani Manat</option><option value="TND">Tunisian Dinar</option><option value="TOP">Tongan Paʻanga</option><option value="TRY">Turkish Lira</option><option value="TTD">Trinidad and Tobago Dollar</option><option value="TWD">New Taiwan Dollar</option><option value="TZS">Tanzanian Shilling</option><option value="UAH">Ukrainian Hryvnia</option><option value="UGX">Ugandan Shilling</option><option value="UYU">Uruguayan Peso</option><option value="UZS">Uzbekistan Som</option><option value="VEF">Venezuelan Bolívar Fuerte</option><option value="VND">Vietnamese Dong</option><option value="VUV">Vanuatu Vatu</option><option value="WST">Samoan Tala</option><option value="XAF">CFA Franc BEAC</option><option value="XCD">East Caribbean Dollar</option><option value="XOF">CFA Franc BCEAO</option><option value="XPF">CFP Franc</option><option value="YER">Yemeni Rial</option><option value="ZAR">South African Rand</option><option value="ZMW">Zambian Kwacha</option><option value="ZWL">Zimbabwean Dollar</option><option value="XAG">Silver (troy ounce)</option><option value="XAU">Gold (troy ounce)</option><option value="ETH">Ethereum</option><option value="XRP">Ripple</option><option value="BCH">Bitcoin Cash</option><option value="EOS">EOS</option><option value="LTC">Litecoin</option><option value="ADA">Cardano</option><option value="XLM">Stellar</option><option value="MIOTA">IOTA</option><option value="TRX">TRON</option><option value="NEO">NEO</option><option value="XMR">Monero</option><option value="DASH">Dash</option><option value="XEM">NEM</option><option value="USDT">Tether</option><option value="ETC">Ethereum Classic</option><option value="VEN">VeChain</option><option value="OMG">OmiseGO</option><option value="QTUM">Qtum</option><option value="ICX">ICON</option><option value="BNB">Binance Coin</option><option value="BTG">Bitcoin Gold</option><option value="LSK">Lisk</option><option value="STEEM">Steem</option><option value="ZEC">Zcash</option><option value="XVG">Verge</option><option value="SC">Siacoin</option><option value="BCN">Bytecoin</option><option value="BTM*">Bytom</option><option value="NANO">Nano</option><option value="BCD">Bitcoin Diamond</option><option value="WAN">Wanchain</option><option value="BTCP">Bitcoin Private</option><option value="PPT">Populous</option><option value="BTS">BitShares</option><option value="ZIL">Zilliqa</option><option value="AE">Aeternity</option><option value="DOGE">Dogecoin</option><option value="MKR">Maker</option><option value="DCR">Decred</option><option value="STRAT">Stratis</option><option value="ONT">Ontology</option><option value="XIN">Mixin</option><option value="ZRX">0x</option><option value="WAVES">Waves</option><option value="DGD">DigixDAO</option><option value="HSR">Hshare</option><option value="RHOC">RChain</option><option value="GNT">Golem</option><option value="SNT">Status</option><option value="AION">Aion</option><option value="WTC">Waltonchain</option><option value="REP">Augur</option><option value="LRC">Loopring</option><option value="DGB">DigiByte</option><option value="BAT">Basic Attention Token</option><option value="IOST">IOStoken</option><option value="KMD">Komodo</option><option value="ARDR">Ardor</option><option value="MITH">Mithril</option><option value="KNC">Kyber Network</option><option value="ARK">Ark</option><option value="MONA">MonaCoin</option><option value="KCS">KuCoin Shares</option><option value="CENNZ">Centrality</option><option value="PIVX">PIVX</option><option value="ELF">aelf</option><option value="SYS">Syscoin</option><option value="CNX">Cryptonex</option><option value="DRGN">Dragonchain</option><option value="SUB">Substratum</option><option value="DCN">Dentacoin</option><option value="GAS">Gas</option><option value="NPXS">Pundi X</option><option value="STORM">Storm</option><option value="QASH">QASH</option><option value="ETHOS">Ethos</option><option value="FCT">Factom</option><option value="NAS">Nebulas</option><option value="GTO">Gifto</option><option value="RDD">ReddCoin</option><option value="CTXC">Cortex</option><option value="BNT">Bancor</option><option value="VERI">Veritaseum</option><option value="SALT">SALT</option><option value="FUN">FunFair</option><option value="GXS">GXChain</option><option value="ELA">Elastos</option><option value="WAX">WAX</option><option value="XZC">ZCoin</option><option value="NXT">Nxt</option><option value="POWR">Power Ledger</option><option value="ENG">Enigma</option><option value="MCO">Monaco</option><option value="KIN">Kin</option><option value="R">Revain</option><option value="LOOM">Loom Network</option><option value="ETN">Electroneum</option><option value="NCASH">Nucleus Vision</option><option value="REQ">Request Network</option><option value="GBYTE">Byteball Bytes</option><option value="MAID">MaidSafeCoin</option><option value="FSN">Fusion</option><option value="NEBL">Neblio</option><option value="LINK">ChainLink</option><option value="PAY">TenX</option><option value="SMT">SmartMesh</option><option value="DBC">DeepBrain Chain</option><option value="ZEN">ZenCash</option><option value="SMART">SmartCash</option><option value="STORJ">Storj</option><option value="PART">Particl</option><option value="SKY">Skycoin</option><option value="CND">Cindicator</option><option value="MANA">Decentraland</option><option value="ICN">Iconomi</option><option value="ACT">Achain</option><option value="MAN">Matrix AI Network</option><option value="GTC">Game.com</option><option value="POA">POA Network</option><option value="CVC">Civic</option><option value="EMC">Emercoin</option><option value="NXS">Nexus</option><option value="BOS">BOScoin</option><option value="NULS">Nuls</option><option value="TPAY">TokenPay</option><option value="PAYX">Paypex</option><option value="DENT">Dent</option><option value="POLY">Polymath</option><option value="POE">Po.et</option><option value="LCC">Litecoin Cash</option><option value="DTR">Dynamic Trading Rights</option><option value="GNO">Gnosis</option><option value="BTCD">BitcoinDark</option><option value="RLC">iExec RLC</option><option value="MTL">Metal</option><option value="VTC">Vertcoin</option><option value="DEW">DEW</option><option value="TNB">Time New Bank</option><option value="QSP">Quantstamp</option><option value="ANT">Aragon</option><option value="CMT">CyberMiles</option><option value="GAME">GameCredits</option><option value="BTX">Bitcore</option><option value="HT">Huobi Token</option><option value="SAN">Santiment Network Token</option><option value="ENJ">Enjin Coin</option><option value="SPHTX">SophiaTX</option><option value="RDN">Raiden Network Token</option><option value="ABT">Arcblock</option><option value="AGI">SingularityNET</option><option value="MED">MediBloc</option><option value="HPB">High Performance Blockchain</option><option value="PPP">PayPie</option><option value="GRS">Groestlcoin</option><option value="CPX">Apex</option><option value="AUTO">Cube</option><option value="GNX">Genaro Network</option><option value="XDN">DigitalNote</option><option value="BLOCK">Blocknet</option><option value="AMB">Ambrosus</option><option value="SRN">SIRIN LABS Token</option><option value="UBQ">Ubiq</option><option value="DROP">Dropil</option><option value="DTA">DATA</option><option value="RUFF">Ruff</option><option value="CS">Credits</option><option value="TKY">THEKEY</option><option value="VEE">BLOCKv</option><option value="RPX">Red Pulse</option><option value="THETA">Theta Token</option><option value="BLZ">Bluzelle</option><option value="SNM">SONM</option><option value="IGNIS">Ignis</option><option value="NAV">NavCoin</option><option value="PLR">Pillar</option><option value="ZCL">ZClassic</option><option value="INK">Ink</option><option value="GVT">Genesis Vision</option><option value="LEND">ETHLend</option><option value="CLOAK">CloakCoin</option><option value="AST">AirSwap</option><option value="TOMO">TomoChain</option><option value="XAS">Asch</option><option value="DDD">Scry.info</option><option value="BAY">BitBay</option><option value="EMC2">Einsteinium</option><option value="BIX">Bibox Token</option><option value="OST">OST</option><option value="C20">CRYPTO20</option><option value="ADX">AdEx</option><option value="QRL">Quantum Resistant Ledger</option><option value="RCN">Ripio Credit Network</option><option value="IHT">IHT Real Estate Protocol</option><option value="EDO">Eidoo</option><option value="DATA">Streamr DATAcoin</option><option value="TEL">Telcoin</option><option value="ITC">IoT Chain</option><option value="BTO">Bottos</option><option value="CRPT">Crypterium</option><option value="ION">ION</option><option value="BRD">Bread</option><option value="MNX">MinexCoin</option><option value="WPR">WePower</option><option value="PPC">Peercoin</option><option value="ELEC">Electrify.Asia</option><option value="INS">INS Ecosystem</option><option value="SLS">SaluS</option><option value="VIBE">VIBE</option><option value="VIA">Viacoin</option><option value="NANJ">NANJCOIN</option><option value="BCO">BridgeCoin</option><option value="INT">Internet Node Token</option><option value="WABI">WaBi</option><option value="EDG">Edgeless</option><option value="SNGLS">SingularDTV</option><option value="JNT">Jibrel Network</option><option value="APPC">AppCoins</option><option value="DNT">district0x</option><option value="RNTB">BitRent</option><option value="SPANK">SpankChain</option><option value="UTK">UTRUST</option><option value="MDS">MediShares</option><option value="WINGS">Wings</option><option value="PURA">Pura</option><option value="TNT">Tierion</option><option value="LBC">LBRY Credits</option><option value="TRAC">OriginTrail</option><option value="MOD">Modum</option><option value="OCN">Odyssey</option><option value="EVN">Envion</option><option value="QLC">QLINK</option><option value="XCP">Counterparty</option><option value="WGR">Wagerr</option><option value="BURST">Burst</option><option value="PRL">Oyster</option><option value="FTC">Feathercoin</option><option value="TRIG">Triggers</option><option value="DPY">Delphy</option><option value="FUEL">Etherparty</option><option value="ECA">Electra</option><option value="NLG">Gulden</option><option value="MLN">Melon</option><option value="DCT">DECENT</option><option value="SBD*">Steem Dollars</option><option value="MOBI">Mobius</option><option value="DAT">Datum</option><option value="PRE">Presearch</option><option value="XP">Experience Points</option><option value="TNC">Trinity Network Credit</option><option value="ZOI">Zoin</option><option value="TKN">TokenCard</option><option value="SOAR">Soarcoin</option><option value="ADT">adToken</option><option value="BCPT">BlockMason Credit Protocol</option><option value="TAAS">TaaS</option><option value="NGC">NAGA</option><option value="SXDT">Spectre.ai Dividend Token</option><option value="XBY">XTRABYTES</option><option value="CDT">Blox</option><option value="UTNP">Universa</option><option value="RKT">Rock</option><option value="ETP">Metaverse ETP</option><option value="SOC">All Sports</option><option value="COSS">COSS</option><option value="BITCNY">bitCNY</option><option value="SAFEX">Safe Exchange Coin</option><option value="BAX">BABB</option><option value="LET">LinkEye</option><option value="LGO">Legolas Exchange</option><option value="REN">Republic Protocol</option><option value="ZPT">Zeepin</option><option value="BKX">Bankex</option><option value="CSC">CasinoCoin</option><option value="QUN">QunQun</option><option value="XEL">Elastic</option><option value="KICK">KickCoin</option><option value="DATX">DATx</option><option value="UKG">Unikoin Gold</option><option value="BANCA">Banca</option><option value="ODE">ODEM</option><option value="RFR">Refereum</option><option value="TEN">Tokenomy</option><option value="VIB">Viberate</option><option value="GUP">Matchpool</option><option value="SHIFT">Shift</option><option value="XDCE">XinFin Network</option><option value="STK">STK</option><option value="YOYOW">YOYOW</option><option value="SHIP">ShipChain</option><option value="RVN">Ravencoin</option><option value="HAV">Havven</option><option value="XSH">SHIELD</option><option value="PRO">Propy</option><option value="DIME">Dimecoin</option><option value="HTML">HTMLCOIN</option><option value="CFI">Cofound.it</option><option value="TAU">Lamden</option><option value="PHR">Phore</option><option value="MER">Mercury</option><option value="AEON">Aeon</option><option value="CPC*">CPChain</option><option value="DAI">Dai</option><option value="HMQ">Humaniq</option><option value="ACAT">Alphacat</option><option value="ONION">DeepOnion</option><option value="AMP">Synereo</option><option value="LUN">Lunyr</option><option value="HST">Decision Token</option><option value="1ST">FirstBlood</option><option value="TIO">Trade Token</option><option value="SENT">Sentinel</option><option value="DMT">DMarket</option><option value="EKT">EDUCare</option><option value="UP">UpToken</option><option value="UGC">ugChain</option><option value="POT">PotCoin</option><option value="PEPECASH">Pepe Cash</option><option value="NMC">Namecoin</option><option value="TRST">WeTrust</option><option value="SENC">Sentinel Chain</option><option value="CRW">Crown</option><option value="UNO">Unobtanium</option><option value="DOCK">Dock</option><option value="AIDOC">AI Doctor</option><option value="FOTA">Fortuna</option><option value="COB">Cobinhood</option><option value="UUU">U Network</option><option value="ECC">ECC</option><option value="TIX">Blocktix</option><option value="MGO">MobileGo</option><option value="ZSC">Zeusshield</option><option value="EVX">Everex</option><option value="HMC">Hi Mutual Society</option><option value="IOC">I/O Coin</option><option value="SWFTC">SwftCoin</option><option value="MTH">Monetha</option><option value="XSN">StakeNet</option><option value="MSP">Mothership</option><option value="MWAT">Restart Energy MWAT</option><option value="BITB">Bean Cash</option><option value="SWH">Switcheo</option><option value="THC">HempCoin</option><option value="KEY">Selfkey</option><option value="LYM">Lympo</option><option value="BCA">Bitcoin Atom</option><option value="SNC">SunContract</option><option value="NMR">Numeraire</option><option value="TRUE">True Chain</option><option value="TSL">Energo</option><option value="ARN">Aeron</option><option value="MTN">Medicalchain</option><option value="DADI">DADI</option><option value="AIT">AICHAIN</option><option value="CAPP">Cappasity</option><option value="$PAC">PACcoin</option><option value="ORME">Ormeus Coin</option><option value="RNT">OneRoot Network</option><option value="DLT">Agrello</option><option value="PPY">Peerplays</option><option value="SPC">SpaceChain</option><option value="BLK">BlackCoin</option><option value="YEE">YEE</option><option value="DXT">Datawallet</option><option value="KRM">Karma</option><option value="ALQO">ALQO</option><option value="XPM">Primecoin</option><option value="CV">carVertical</option><option value="LEO">LEOcoin</option><option value="BOT">Bodhi</option><option value="MDA">Moeda Loyalty Points</option><option value="PASC">Pascal Coin</option><option value="BLT">Bloom</option><option value="DMD">Diamond</option><option value="RADS">Radium</option><option value="VRC">VeriCoin</option><option value="QBT*">Qbao</option><option value="OCT">OracleChain</option><option value="ATM">ATMChain</option><option value="OMNI">Omni</option><option value="GRID">Grid+</option><option value="MDT">Measurable Data Token</option><option value="RVR">RevolutionVR</option><option value="HOT">Hydro Protocol</option><option value="FLASH">Flash</option><option value="AXP">aXpire</option><option value="SIB">SIBCoin</option><option value="COV">Covesting</option><option value="FAIR">FairCoin</option><option value="GRC">GridCoin</option><option value="MTX">Matryx</option><option value="STQ">Storiqa</option><option value="LKK">Lykke</option><option value="POSW">PoSW Coin</option><option value="HVN">Hive Project</option><option value="CAT*">BitClave</option><option value="EDR">E-Dinar Coin</option><option value="OAX">OAX</option><option value="IDH">indaHash</option><option value="UQC">Uquid Coin</option><option value="PARETO">Pareto Network</option><option value="BBN">Banyan Network</option><option value="MEDIC">MedicCoin</option><option value="XWC">WhiteCoin</option><option value="LA">LATOKEN</option><option value="EVE">Devery</option><option value="TCT">TokenClub</option><option value="LUX">LUXCoin</option><option value="BPT">Blockport</option><option value="RMT">SureRemit</option><option value="ICOS">ICOS</option><option value="PRA">ProChain</option><option value="HKN">Hacken</option><option value="EXP">Expanse</option><option value="IXT">iXledger</option><option value="INCNT">Incent</option><option value="AURA">Aurora DAO</option><option value="TFD">TE-FOOD</option><option value="CHSB">SwissBorg</option><option value="PZM">PRIZM</option><option value="BMC">Blackmoon</option><option value="BIS">Bismuth</option><option value="TBAR">Titanium BAR</option><option value="SLT">Smartlands</option><option value="EKO">EchoLink</option><option value="FLO">FlorinCoin</option><option value="PLBT">Polybius</option><option value="NCT">PolySwarm</option><option value="SLR">SolarCoin</option><option value="SRCOIN">SRCOIN</option><option value="MUE">MonetaryUnit</option><option value="BERRY">Rentberry</option><option value="DIVX">Divi</option><option value="BBR">Boolberry</option><option value="BEE">Bee Token</option><option value="MOT">Olympus Labs</option><option value="COLX">ColossusXT</option><option value="STX">Stox</option><option value="ZAP">Zap</option><option value="BDG">BitDegree</option><option value="XMY">Myriad</option><option value="ARY">Block Array</option><option value="LMC">LoMoCoin</option><option value="SNOV">Snovio</option><option value="LINDA">Linda</option><option value="RISE">Rise</option><option value="RBY">Rubycoin</option><option value="SWM">Swarm</option><option value="BITUSD">bitUSD</option><option value="OK">OKCash</option><option value="XRL">Rialto</option><option value="BSD*">BitSend</option><option value="NLC2">NoLimitCoin</option><option value="DNA">EncrypGen</option><option value="DTB">Databits</option><option value="BITG">Bitcoin Green</option><option value="CLAM">Clams</option><option value="DEB">Debitum</option><option value="ENRG">Energycoin</option><option value="AUC">Auctus</option><option value="NEOS">NeosCoin</option><option value="IPBC">Interplanetary Broadcast Coin</option><option value="CAS">Cashaa</option><option value="XSPEC">Spectrecoin</option><option value="SWT">Swarm City</option><option value="XPA">XPA</option><option value="CXO">CargoX</option><option value="DICE">Etheroll</option><option value="FLDC">FoldingCoin</option><option value="PRG">Paragon</option><option value="NET*">Nimiq Exchange Token</option><option value="DIM">DIMCOIN</option><option value="ALIS">ALIS</option><option value="CVT">CyberVein</option><option value="FLUZ">Fluz Fluz</option><option value="PTOY">Patientory</option><option value="DRT">DomRaider</option><option value="GBX">GoByte</option><option value="NEU">Neumark</option><option value="DBET">DecentBet</option><option value="NXC">Nexium</option><option value="MOON">Mooncoin</option><option value="FLIXX">Flixxo</option><option value="MUSIC">Musicoin</option><option value="EVR">Everus</option><option value="CREDO">Credo</option><option value="QAU">Quantum</option><option value="HAT">Hat.Exchange</option><option value="GOLOS">Golos</option><option value="LALA">LALA World</option><option value="LOC">LockTrip</option><option value="TUSD">True USD</option><option value="BCC">BitConnect</option><option value="REM">Remme</option><option value="EFX">Effect.AI</option><option value="AIR">AirToken</option><option value="ART">Maecenas</option><option value="NYC">NewYorkCoin</option><option value="SYNX">Syndicate</option><option value="CAN">CanYaCoin</option><option value="IPSX">IP Exchange</option><option value="CHP">CoinPoker</option><option value="PST">Primas</option><option value="FTX">FintruX Network</option><option value="NPX">NaPoleonX</option><option value="BNTY">Bounty0x</option><option value="LDC">Leadcoin</option><option value="DBIX">DubaiCoin</option><option value="WRC">Worldcore</option><option value="GAM">Gambit</option><option value="WCT">Waves Community Token</option><option value="HWC">HollyWoodCoin</option><option value="OXY">Oxycoin</option><option value="COFI">CoinFi</option><option value="AUR">Auroracoin</option><option value="DTH">Dether</option><option value="MYST">Mysterium</option><option value="XLR">Solaris</option><option value="ATN">ATN</option><option value="CBT">CommerceBlock</option><option value="TCC">The ChampCoin</option><option value="HEAT">HEAT</option><option value="SIG">Spectiv</option><option value="DYN">Dynamic</option><option value="XST">Stealthcoin</option><option value="PLU">Pluton</option><option value="BQ">bitqy</option><option value="FDX">FidentiaX</option><option value="POLIS">Polis</option><option value="PFR">Payfair</option><option value="TX">TransferCoin</option><option value="AVT">Aventus</option><option value="INSTAR">Insights Network</option><option value="HXX">Hexx</option><option value="IFT">InvestFeed</option><option value="ESP">Espers</option><option value="ADB">adbank</option><option value="TIME">Chronobank</option><option value="IPL">InsurePal</option><option value="SPHR">Sphere</option><option value="GETX">Guaranteed Ethurance Token Extra</option><option value="TIPS">FedoraCoin</option><option value="CVCOIN">CVCoin</option><option value="PURE">Pure</option><option value="TOA">ToaCoin</option><option value="SEQ">Sequence</option><option value="ELIX">Elixir</option><option value="MINT">Mintcoin</option><option value="ATL">ATLANT</option><option value="PINK">PinkCoin</option><option value="DAN">Daneel</option><option value="ZLA">Zilla</option><option value="COVAL">Circuits of Value</option><option value="PUT*">Profile Utility Token</option><option value="PND">Pandacoin</option><option value="CLR">ClearCoin</option><option value="MYB">MyBit Token</option><option value="ATB">ATBCoin</option><option value="OPT">Opus</option><option value="BCY">Bitcrystals</option><option value="RVT">Rivetz</option><option value="TKS">Tokes</option><option value="EBST">eBoost</option><option value="XAUR">Xaurum</option><option value="IOP">Internet of People</option><option value="BLUE">BLUE</option><option value="XNK">Ink Protocol</option><option value="CURE">Curecoin</option><option value="BWK">Bulwark</option><option value="VOISE">Voise</option><option value="PKT">Playkey</option><option value="PBL">Publica</option><option value="HGT">HelloGold</option><option value="CAG">Change</option><option value="DOVU">Dovu</option><option value="GEO">GeoCoin</option><option value="LIFE">LIFE</option><option value="B2B">B2BX</option><option value="POLL">ClearPoll</option><option value="REBL">REBL</option><option value="ADH">AdHive</option><option value="UCASH">U.CASH</option><option value="NVC">Novacoin</option><option value="ABY">ArtByte</option><option value="GLA">Gladius Token</option><option value="GET">GET Protocol</option><option value="TRF">Travelflex</option><option value="HAC">Hackspace Capital</option><option value="KORE">Kore</option><option value="HQX">HOQU</option><option value="MSR">Masari</option><option value="ERO">Eroscoin</option><option value="XHV">Haven Protocol</option><option value="PRIX">Privatix</option><option value="VIT">Vice Industry Token</option><option value="SXUT">Spectre.ai Utility Token</option><option value="DOPE">DopeCoin</option><option value="SPF">SportyCo</option><option value="BRX">Breakout Stake</option><option value="CHIPS">CHIPS</option><option value="OBITS">OBITS</option><option value="NVST">NVO</option><option value="CSNO">BitDice</option><option value="LEV">Leverj</option><option value="GAT">Gatcoin</option><option value="VIU">Viuly</option><option value="EXRN">EXRNchain</option><option value="PIRL">Pirl</option><option value="PING">CryptoPing</option><option value="XBC">Bitcoin Plus</option><option value="IDXM">IDEX Membership</option><option value="DOT">Dotcoin</option><option value="BTCZ">BitcoinZ</option><option value="LOCI">LOCIcoin</option><option value="PTC">Pesetacoin</option><option value="MEME">Memetic / PepeCoin</option><option value="TFL">TrueFlip</option><option value="SPD">Stipend</option><option value="AID">AidCoin</option><option value="NKC">Nework</option><option value="NIO*">Autonio</option><option value="SEXC">ShareX</option><option value="APX">APX</option><option value="GLD">GoldCoin</option><option value="CAT">BlockCAT</option><option value="EXCL">ExclusiveCoin</option><option value="HYP">HyperStake</option><option value="ASTRO">Astro</option><option value="QWARK">Qwark</option><option value="ERC">EuropeCoin</option><option value="KB3">B3Coin</option><option value="MAX">MaxCoin</option><option value="TRCT">Tracto</option><option value="J8T">JET8</option><option value="INXT">Internxt</option><option value="DEV">DeviantCoin</option><option value="USNBT">NuBits</option><option value="HUSH">Hush</option><option value="SUMO">Sumokoin</option><option value="1WO">1World</option><option value="XNN">Xenon</option><option value="PLAY">HEROcoin</option><option value="SPR">SpreadCoin</option><option value="SPRTS">Sprouts</option><option value="SEND">Social Send</option><option value="LEDU">Education Ecosystem</option><option value="VTR">vTorrent</option><option value="ING">Iungo</option><option value="WISH">MyWish</option><option value="BTM">Bitmark</option><option value="UNIT">Universal Currency</option><option value="CANN">CannabisCoin</option><option value="AIX">Aigang</option><option value="BON">Bonpay</option><option value="VRM">VeriumReserve</option><option value="NTRN">Neutron</option><option value="CPAY">Cryptopay</option><option value="2GIVE">2GIVE</option><option value="MONK">Monkey Project</option><option value="EXY">Experty</option><option value="MNTP">GoldMint</option><option value="STAC">StarterCoin</option><option value="DNR">Denarius</option><option value="UFR">Upfiring</option><option value="BIO">BioCoin</option><option value="ADST">AdShares</option><option value="HORSE">Ethorse</option><option value="DRP">DCORP</option><option value="BTDX">Bitcloud</option><option value="CPY">COPYTRACK</option><option value="ZEIT">Zeitcoin</option><option value="BRK">Breakout</option><option value="PIX">Lampix</option><option value="OTN">Open Trading Network</option><option value="SETH">Sether</option><option value="FLAP">FlappyCoin</option><option value="RC">RussiaCoin</option><option value="ZRC">ZrCoin</option><option value="GCR">Global Currency Reserve</option><option value="CRB">Creditbit</option><option value="REF">RefToken</option><option value="BLITZ">Blitzcash</option><option value="RIC">Riecoin</option><option value="EZT">EZToken</option><option value="SWIFT">Bitswift</option><option value="STAR">Starbase</option><option value="MVC">Maverick Chain</option><option value="BET*">DAO.Casino</option><option value="KRB">Karbo</option><option value="SSS">Sharechain</option><option value="BPL">Blockpool</option><option value="UFO">Uniform Fiscal Object</option><option value="TRC">Terracoin</option><option value="SHP*">Sharpe Platform Token</option><option value="RUPX">Rupaya</option><option value="PBT">Primalbase Token</option><option value="XMCC">Monoeci</option><option value="EGC">EverGreenCoin</option><option value="ZER">Zero</option><option value="ADC">AudioCoin</option><option value="QRK">Quark</option><option value="AU">AurumCoin</option><option value="ODN">Obsidian</option><option value="REAL">REAL</option><option value="SCL">Sociall</option><option value="DGPT">DigiPulse</option><option value="CMPCO">CampusCoin</option><option value="BEZ">Bezop</option><option value="HUC">HunterCoin</option><option value="TRUST">TrustPlus</option><option value="PIPL">PiplCoin</option><option value="XGOX">XGOX</option><option value="BASH">LuckChain</option><option value="PYLNT">Pylon Network</option><option value="ZEPH">Zephyr</option><option value="FOR">FORCE</option><option value="CRED">Verify</option><option value="TIE">Ties.DB</option><option value="RUP">Rupee</option><option value="VZT">Vezt</option><option value="1337">Elite</option><option value="JIYO">Jiyo</option><option value="AMM">MicroMoney</option><option value="SXC">Sexcoin</option><option value="HIRE">HireMatch</option><option value="EVC">EventChain</option><option value="EFL">e-Gulden</option><option value="PUT">PutinCoin</option><option value="VSX">Vsync</option><option value="TZC">TrezarCoin</option><option value="ZNY">Bitzeny</option><option value="XMG">Magi</option><option value="CRAVE">Crave</option><option value="EQT">EquiTrader</option><option value="LINX">Linx</option><option value="ACE">Ace</option><option value="CHC">ChainCoin</option><option value="808">808Coin</option><option value="GCN">GCN Coin</option><option value="QVT">Qvolta</option><option value="GRFT">Graft</option><option value="ARG">Argentum</option><option value="UIS">Unitus</option><option value="GMT">Mercury Protocol</option><option value="MAG">Magnet</option><option value="SENSE">Sense</option><option value="FRD">Farad</option><option value="MTNC">Masternodecoin</option><option value="TBX">Tokenbox</option><option value="NOBL">NobleCoin</option><option value="TES">TeslaCoin</option><option value="CREA">Creativecoin</option><option value="XBP">BlitzPredict</option><option value="ITNS">IntenseCoin</option><option value="ESZ">EtherSportz</option><option value="CPC">Capricoin</option><option value="LDOGE">LiteDoge</option><option value="SMS">Speed Mining Service</option><option value="INN">Innova</option><option value="MXT">MarteXcoin</option><option value="EFYT">Ergo</option><option value="ELLA">Ellaism</option><option value="DP">DigitalPrice</option><option value="DAY">Chronologic</option><option value="SMLY">SmileyCoin</option><option value="FYN">FundYourselfNow</option><option value="KZC">Kzcash</option><option value="WAND">WandX</option><option value="NKA">IncaKoin</option><option value="CDN">Canada eCoin</option><option value="HOLD">Interstellar Holdings</option><option value="EMV">Ethereum Movie Venture</option><option value="CL">Coinlancer</option><option value="EBTC">eBitcoin</option><option value="RAIN">Condensate</option><option value="UNB">UnbreakableCoin</option><option value="BTW">BitWhite</option><option value="BUN">BunnyCoin</option><option value="KEK">KekCoin</option><option value="STAK">STRAKS</option><option value="BBP">BiblePay</option><option value="IC">Ignition</option><option value="ANC">Anoncoin</option><option value="LNC">Blocklancer</option><option value="ALT">Altcoin</option><option value="ORB">Orbitcoin</option><option value="YOC">Yocoin</option><option value="ONG">onG.social</option><option value="BUZZ">BuzzCoin</option><option value="AHT">Bowhead</option><option value="KOBO">Kobocoin</option><option value="ETBS">Ethbits</option><option value="IND">Indorse Token</option><option value="SAGA">SagaCoin</option><option value="TIG">Tigereum</option><option value="LATX">LatiumX</option><option value="XFT">Footy Cash</option><option value="OCC">Octoin Coin</option><option value="SKIN">SkinCoin</option><option value="ELTCOIN">ELTCOIN</option><option value="TDX">Tidex Token</option><option value="FRST">FirstCoin</option><option value="ACC*">Accelerator Network</option><option value="GPU">GPU Coin</option><option value="MRJA">GanjaCoin</option><option value="OCL">Oceanlab</option><option value="ARC">ArcticCoin</option><option value="CARBON">Carboncoin</option><option value="DEM">Deutsche eMark</option><option value="BYC">Bytecent</option><option value="MCAP">MCAP</option><option value="NMS">Numus</option><option value="LGD">Legends Room</option><option value="42">42-coin</option><option value="DFS">DFSCoin</option><option value="LOG">Woodcoin</option><option value="SNRG">Synergy</option><option value="MOIN">Moin</option><option value="VULC">Vulcano</option><option value="MRT">Miners' Reward Token</option><option value="VIVO">VIVO</option><option value="JEW">Shekel</option><option value="SKC">Skeincoin</option><option value="GCC*">Global Cryptocurrency</option><option value="ADZ">Adzcoin</option><option value="FUNK">The Cypherfunks</option><option value="GJC">Global Jobcoin</option><option value="MZC">MAZA</option><option value="CTR">Centra</option><option value="MEC">Megacoin</option><option value="ORE">Galactrum</option><option value="XPTX">PlatinumBAR</option><option value="DEUS">DeusCoin</option><option value="DFT">DraftCoin</option><option value="PCN">PeepCoin</option><option value="BRIT">BritCoin</option><option value="BTA">Bata</option><option value="UNIFY">Unify</option><option value="ZET">Zetacoin</option><option value="EPY">Emphy</option><option value="STU">bitJob</option><option value="DCY">Dinastycoin</option><option value="NETKO">Netko</option><option value="GUN">Guncoin</option><option value="MAGE">MagicCoin</option><option value="XLC">LeviarCoin</option><option value="NSR">NuShares</option><option value="FCN">Fantomcoin</option><option value="CRC*">CrowdCoin</option><option value="DRPU">DRP Utility</option><option value="FJC">FujiCoin</option><option value="ECASH">Ethereum Cash</option><option value="KLN">Kolion</option><option value="MBRS">Embers</option><option value="PROC">ProCurrency</option><option value="REC">Regalcoin</option><option value="BSM">Bitsum</option><option value="ICOO">ICO OpenLedger</option><option value="START">Startcoin</option><option value="EQL">Equal</option><option value="XPD">PetroDollar</option><option value="WILD">Wild Crypto</option><option value="QBIC">Qbic</option><option value="MBI">Monster Byte</option><option value="CCRB">CryptoCarbon</option><option value="HERO">Sovereign Hero</option><option value="ATS">Authorship</option><option value="IFLT">InflationCoin</option><option value="GRWI">Growers International</option><option value="BTWTY">Bit20</option><option value="MAC">Machinecoin</option><option value="HBN">HoboNickels</option><option value="SCT">Soma</option><option value="CCT">Crystal Clear </option><option value="ESC">Escroco</option><option value="IETH">iEthereum</option><option value="HPC">Happycoin</option><option value="SUR">Suretly</option><option value="CRM">Cream</option><option value="ACC">AdCoin</option><option value="JET">Jetcoin</option><option value="INSN">InsaneCoin</option><option value="ARCT">ArbitrageCT</option><option value="LCP">Litecoin Plus</option><option value="ITI">iTicoin</option><option value="PHO">Photon</option><option value="VOT">VoteCoin</option><option value="EBET">EthBet</option><option value="MNE">Minereum</option><option value="BTB">BitBar</option><option value="RBT">Rimbit</option><option value="FST">Fastcoin</option><option value="XCPO">Copico</option><option value="BTG*">Bitgem</option><option value="PXC">Phoenixcoin</option><option value="TTC">TittieCoin</option><option value="LANA">LanaCoin</option><option value="ARCO">AquariusCoin</option><option value="GRLC">Garlicoin</option><option value="WHL">WhaleCoin</option><option value="XCN">Cryptonite</option><option value="ERC20">ERC20</option><option value="BDL">Bitdeal</option><option value="KUSH">KushCoin</option><option value="VRS">Veros</option><option value="SCORE">Scorecoin</option><option value="DRXNE">DROXNE</option><option value="ITT">Intelligent Trading Foundation</option><option value="SGR">Sugar Exchange</option><option value="TOK">Tokugawa</option><option value="SDRN">Senderon</option><option value="MOJO">MojoCoin</option><option value="MAO">Mao Zedong</option><option value="VIDZ">PureVidz</option><option value="IRL">IrishCoin</option><option value="RLT">RouletteToken</option><option value="XBL">Billionaire Token</option><option value="PLC">PlusCoin</option><option value="ELE">Elementrem</option><option value="SLG">Sterlingcoin</option><option value="KBR">Kubera Coin</option><option value="SCS">Speedcash</option><option value="BITSILVER">bitSilver</option><option value="BLC">Blakecoin</option><option value="MANNA">Manna</option><option value="TRUMP">TrumpCoin</option><option value="TEK">TEKcoin</option><option value="DAXX">DaxxCoin</option><option value="PAK">Pakcoin</option><option value="BTCA">Bitair</option><option value="STN*">Steneum Coin</option><option value="CJ">Cryptojacks</option><option value="CTX">CarTaxi Token</option><option value="BTCRED">Bitcoin Red</option><option value="CAB">Cabbage</option><option value="MNM">Mineum</option><option value="GRN">Granite</option><option value="AERM">Aerium</option><option value="GOLF">Golfcoin</option><option value="GUESS">Peerguess</option><option value="SRC">SecureCoin</option><option value="OPC">OP Coin</option><option value="WGO">WavesGo</option><option value="POST">PostCoin</option><option value="BCF">Bitcoin Fast</option><option value="XCXT">CoinonatX</option><option value="DMB">Digital Money Bits</option><option value="ZCG">Zlancer</option><option value="ONX">Onix</option><option value="CNT">Centurion</option><option value="GAP">Gapcoin</option><option value="DIX">Dix Asset</option><option value="CESC">CryptoEscudo</option><option value="ETG">Ethereum Gold</option><option value="BITGOLD">bitGold</option><option value="HNC">Helleniccoin</option><option value="CCN">CannaCoin</option><option value="TOKC">TOKYO</option><option value="ATOM">Atomic Coin</option><option value="OTX">Octanox</option><option value="PASL">Pascal Lite</option><option value="BIGUP">BigUp</option><option value="PLC*">Polcoin</option><option value="LTB">LiteBar</option><option value="LEA">LeaCoin</option><option value="SHND">StrongHands</option><option value="IMX">Impact</option><option value="ABJ">Abjcoin</option><option value="NRO">Neuro</option><option value="300">300 Token</option><option value="NUKO">Nekonium</option><option value="CUBE">DigiCube</option><option value="BTPL">Bitcoin Planet</option><option value="RED">RedCoin</option><option value="PXI">Prime-XI</option><option value="ECO">EcoCoin</option><option value="SWING">Swing</option><option value="MCRN">MACRON</option><option value="C2">Coin2.1</option><option value="XRE">RevolverCoin</option><option value="SHDW">Shadow Token</option><option value="XCO">X-Coin</option><option value="NTO">Fujinto</option><option value="REE">ReeCoin</option><option value="BOST">BoostCoin</option><option value="LBTC">LiteBitcoin</option><option value="HVCO">High Voltage</option><option value="611">SixEleven</option><option value="ETHD">Ethereum Dark</option><option value="SFC">Solarflarecoin</option><option value="FUNC">FUNCoin</option><option value="TAJ">TajCoin</option><option value="VPRC">VapersCoin</option><option value="MAY">Theresa May Coin</option><option value="GTC*">Global Tour Coin</option><option value="HBC">HomeBlockCoin</option><option value="SOON">SoonCoin</option><option value="DSR">Desire</option><option value="TRDT">Trident Group</option><option value="BITEUR">bitEUR</option><option value="BRAT">BROTHER</option><option value="NEWB">Newbium</option><option value="EAGLE">EagleCoin</option><option value="COAL">BitCoal</option><option value="CMT*">Comet</option><option value="VUC">Virta Unique Coin</option><option value="XHI">HiCoin</option><option value="FLAX">Flaxscript</option><option value="CRX">Chronos</option><option value="PCOIN">Pioneer Coin</option><option value="ERY">Eryllium</option><option value="BIP">BipCoin</option><option value="GP">GoldPieces</option><option value="ITZ">Interzone</option><option value="KRONE">Kronecoin</option><option value="CNNC">Cannation</option><option value="ADCN">Asiadigicoin</option><option value="UET">Useless Ethereum Token</option><option value="QCN">QuazarCoin</option><option value="ZMC">ZetaMicron</option><option value="MSCN">Master Swiscoin</option><option value="LTCU">LiteCoin Ultra</option><option value="RKC">Royal Kingdom Coin</option><option value="LUNA">Luna Coin</option><option value="GBC">GBCGoldCoin</option><option value="SANDG">Save and Gain</option><option value="CRDNC">Credence Coin</option><option value="PRC">PRCoin</option><option value="ACP">AnarchistsPrime</option><option value="WOMEN">WomenCoin</option><option value="NANOX">Project-X</option><option value="COUPE">Coupecoin</option><option value="HMC*">HarmonyCoin</option><option value="PIZZA">PizzaCoin</option><option value="CALC">CaliphCoin</option><option value="GRE">Greencoin</option><option value="XTO">Tao</option><option value="HDG">Hedge</option><option value="MUSE">MUSE</option><option value="TGT">Target Coin</option><option value="ECOB">Ecobit</option><option value="RMC">Russian Miner Coin</option><option value="HBT">Hubii Network</option><option value="AC">AsiaCoin</option><option value="KLC">KiloCoin</option><option value="GOOD">Goodomy</option><option value="ECN">E-coin</option><option value="ETT">EncryptoTel [WAVES]</option><option value="VSL">vSlice</option><option value="IXC">Ixcoin</option><option value="STA">Starta</option><option value="REX">imbrex</option><option value="CBX">Bullion</option><option value="DAR">Darcrus</option><option value="TRIA">Triaconta</option><option value="NOTE">DNotes</option><option value="INPAY">InPay</option><option value="BLU">BlueCoin</option><option value="LEAF">LeafCoin</option><option value="FLIK">FLiK</option><option value="BBT">BitBoost</option><option value="WDC">WorldCoin</option><option value="FYP">FlypMe</option><option value="JC">Jesus Coin</option><option value="UNIC">UniCoin</option><option value="SHORTY">Shorty</option><option value="FLT">FlutterCoin</option><option value="V">Version</option><option value="UNI">Universe</option><option value="POP">PopularCoin</option><option value="I0C">I0Coin</option><option value="NDC">NEVERDIE</option><option value="FUCK">FuckToken</option><option value="ZENI">Zennies</option><option value="HTC">HitCoin</option><option value="SDC">ShadowCash</option><option value="CDX">Commodity Ad Network</option><option value="RNS">Renos</option><option value="STRC">StarCredits</option><option value="METAL">MetalCoin</option><option value="RIYA">Etheriya</option><option value="BPC">Bitpark Coin</option><option value="NET">NetCoin</option><option value="BXT">BitTokens</option><option value="PIGGY">Piggycoin</option><option value="DGC">Digitalcoin</option><option value="BRO">Bitradio</option><option value="BITS">Bitstar</option><option value="TRI">Triangles</option><option value="OPAL">Opal</option><option value="USC">Ultimate Secure Cash</option><option value="TROLL">Trollcoin</option><option value="Q2C">QubitCoin</option><option value="VTA">Virtacoin</option><option value="BLZ*">BlazeCoin</option><option value="BTCS">Bitcoin Scrypt</option><option value="HODL">HOdlcoin</option><option value="TIT">Titcoin</option><option value="BITBTC">bitBTC</option><option value="KURT">Kurrent</option><option value="GAIA">GAIA</option><option value="NYAN">Nyancoin</option><option value="TAG">TagCoin</option><option value="TALK">BTCtalkcoin</option><option value="ARI">Aricoin</option><option value="DSH">Dashcoin</option><option value="HAL">Halcyon</option><option value="MOTO">Motocoin</option><option value="EBCH">eBitcoinCash</option><option value="BUCKS">SwagBucks</option><option value="UTC">UltraCoin</option><option value="FLY">Flycoin</option><option value="SMC">SmartCoin</option><option value="TRK">Truckcoin</option><option value="XPY">PayCoin</option><option value="RPC">RonPaulCoin</option><option value="NXX">Nexxus</option><option value="ISL">IslaCoin</option><option value="SUPER">SuperCoin</option><option value="XJO">Joulecoin</option><option value="GB">GoldBlocks</option><option value="PR">Prototanium</option><option value="CASH">Cashcoin</option><option value="EVIL">Evil Coin</option><option value="8BIT">8Bit</option><option value="BLOCKPAY">BlockPay</option><option value="MAD*">SatoshiMadness</option><option value="BOLI">Bolivarcoin</option><option value="TSE">Tattoocoin (Standard Edition)</option><option value="DDF">DigitalDevelopersFund</option><option value="TKR">CryptoInsight</option><option value="PHS">Philosopher Stones</option><option value="VISIO">Visio</option><option value="TGC">Tigercoin</option><option value="CHESS">ChessCoin</option><option value="AMBER">AmberCoin</option><option value="ENT">Eternity</option><option value="CNO">Coin(O)</option><option value="BITZ">Bitz</option><option value="CYP">Cypher</option><option value="FRC">Freicoin</option><option value="XRA">Ratecoin</option><option value="GRIM">Grimcoin</option><option value="XCT">C-Bit</option><option value="EMD">Emerald Crypto</option><option value="MARS">Marscoin</option><option value="ICN*">iCoin</option><option value="NEVA">NevaCoin</option><option value="SPEX">SproutsExtreme</option><option value="INFX">Influxcoin</option><option value="CHAN">ChanCoin</option><option value="AMMO">Ammo Reloaded</option><option value="PX">PX</option><option value="BTCR">Bitcurrency</option><option value="SPACE">SpaceCoin</option><option value="BERN">BERNcash</option><option value="888">OctoCoin</option><option value="DTC">Datacoin</option><option value="QBC">Quebecoin</option><option value="KED">Darsek</option><option value="CTO">Crypto</option><option value="LCT">LendConnect</option><option value="SIGT">Signatum</option><option value="XIOS">Xios</option><option value="GLT">GlobalToken</option><option value="UNITS">GameUnits</option><option value="B@">Bankcoin</option><option value="RBIES">Rubies</option><option value="IMS">Independent Money System</option><option value="VC">VirtualCoin</option><option value="GLC">GlobalCoin</option><option value="ZUR">Zurcoin</option><option value="FNC">FinCoin</option><option value="AMS">AmsterdamCoin</option><option value="QTL">Quatloo</option><option value="PNX">Phantomx</option><option value="CAT**">Catcoin</option><option value="CCO">Ccore</option><option value="DUO">ParallelCoin</option><option value="MST">MustangCoin</option><option value="PKB">ParkByte</option><option value="BSTY">GlobalBoost-Y</option><option value="FIRE">Firecoin</option><option value="STV">Sativacoin</option><option value="YAC">Yacoin</option><option value="BUMBA">BumbaCoin</option><option value="AIB">Advanced Internet Blocks</option><option value="JIN">Jin Coin</option><option value="HONEY">Honey</option><option value="SCRT">SecretCoin</option><option value="XVP">Virtacoinplus</option><option value="DRS">Digital Rupees</option><option value="EVO">Evotion</option><option value="ELC">Elacoin</option><option value="ICOB">ICOBID</option><option value="EL">Elcoin</option><option value="CON">PayCon</option><option value="XBTS">Beatcoin</option><option value="GCC">GuccioneCoin</option><option value="XNG">Enigma</option><option value="HMP">HempCoin</option><option value="XBTC21">Bitcoin 21</option><option value="DLC">Dollarcoin</option><option value="BRIA">BriaCoin</option><option value="$$$">Money</option><option value="BTQ">BitQuark</option><option value="YTN">YENTEN</option><option value="XCRE">Creatio</option><option value="DALC">Dalecoin</option><option value="EUC">Eurocoin</option><option value="ACOIN">Acoin</option><option value="FUZZ">FuzzBalls</option><option value="GLS">GlassCoin</option><option value="CACH">CacheCoin</option><option value="MNC">Mincoin</option><option value="SOIL">SOILcoin</option><option value="BLN">Bolenum</option><option value="BENJI">BenjiRolls</option><option value="NTWK">Network Token</option><option value="MDC">Madcoin</option><option value="AGLC">AgrolifeCoin</option><option value="BLRY">BillaryCoin</option><option value="J">Joincoin</option><option value="CPN">CompuCoin</option><option value="STARS">StarCash Network</option><option value="CXT">Coinonat</option><option value="DBTC">Debitcoin</option><option value="ALL*">Allion</option><option value="ROOFS">Roofs</option><option value="ASAFE2">AllSafe</option><option value="CF">Californium</option><option value="BAS">BitAsean</option><option value="MAR">Marijuanacoin</option><option value="RIDE">Ride My Car</option><option value="MTLMC3">Metal Music Coin</option><option value="GPL">Gold Pressed Latinum</option><option value="SONG">SongCoin</option><option value="ZZC">ZoZoCoin</option><option value="WARP">WARP</option><option value="SH">Shilling</option><option value="BNX">BnrtxCoin</option><option value="MND">MindCoin</option><option value="RBX">Ripto Bux</option><option value="BXC">Bitcedi</option><option value="BSTAR">Blackstar</option><option value="ZYD">Zayedcoin</option><option value="URO">Uro</option><option value="PRX">Printerium</option><option value="VIP">VIP Tokens</option><option value="ATX">Artex Coin</option><option value="WORM">HealthyWormCoin</option><option value="KNC*">KingN Coin</option><option value="JWL">Jewels</option><option value="SLEVIN">Slevin</option><option value="POS">PoSToken</option><option value="DRM">Dreamcoin</option><option value="MILO">MiloCoin</option><option value="ICON">Iconic</option><option value="PONZI">PonziCoin</option><option value="DLISK">DAPPSTER</option><option value="EXN">ExchangeN</option><option value="PIE">PIECoin</option><option value="BSC">BowsCoin</option><option value="LTCR">Litecred</option><option value="GEERT">GeertCoin</option><option value="VLT">Veltor</option><option value="BIOS">BiosCrypto</option><option value="PULSE">Pulse</option><option value="STEPS">Steps</option><option value="LIR">LetItRide</option><option value="ARB">ARbit</option><option value="IMPS">ImpulseCoin</option><option value="BOAT">BOAT</option><option value="ZNE">Zonecoin</option><option value="JS">JavaScript Token</option><option value="PLACO">PlayerCoin</option><option value="VEC2">VectorAI</option><option value="WBB">Wild Beast Block</option><option value="CWXT">CryptoWorldX Token</option><option value="OFF">Cthulhu Offerings</option><option value="SDP">SydPak</option><option value="DES">Destiny</option><option value="RSGP">RSGPcoin</option><option value="TAGR">TAGRcoin</option><option value="OS76">OsmiumCoin</option><option value="PLNC">PLNcoin</option><option value="TOR">Torcoin</option><option value="VOLT">Bitvolt</option><option value="PEX">PosEx</option><option value="JOBS">JobsCoin</option><option value="ARGUS">Argus</option><option value="DOLLAR">Dollar Online</option><option value="CTIC3">Coimatic 3.0</option><option value="XRC">Rawcoin</option><option value="P7C">P7Coin</option><option value="BIOB">BioBar</option><option value="IBANK">iBank</option><option value="CREVA">CrevaCoin</option><option value="ELS">Elysium</option><option value="SOCC">SocialCoin</option><option value="CONX">Concoin</option><option value="SLFI">Selfiecoin</option><option value="NODC">NodeCoin</option><option value="MGM">Magnum</option><option value="GSR">GeyserCoin</option><option value="CTIC2">Coimatic 2.0</option><option value="ULA">Ulatech</option><option value="VLTC">Vault Coin</option><option value="LVPS">LevoPlus</option><option value="TSTR">Tristar Coin</option><option value="FXE">FuturXe</option><option value="DGCS">Digital Credits</option><option value="EBT">Ebittree Coin</option><option value="AI">POLY AI</option><option value="CKUSD">CK USD</option><option value="OC">OceanChain</option><option value="WIC*">WaykiChain</option><option value="XMC">Monero Classic</option><option value="MOAC">MOAC</option><option value="IQT">iQuant</option><option value="SBTC">Super Bitcoin</option><option value="KCASH">Kcash</option><option value="CAN*">Content and AD Network</option><option value="STC">StarChain</option><option value="NOAH">Noah Coin</option><option value="MEET">CoinMeet</option><option value="EPC">Electronic PK Chain</option><option value="BCX">BitcoinX</option><option value="CHAT">ChatCoin</option><option value="AAC">Acute Angle Cloud</option><option value="ATMC">ATMCoin</option><option value="DRG">Dragon Coins</option><option value="MOF">Molecular Future</option><option value="XMO">Monero Original</option><option value="SHOW">Show</option><option value="FAIR*">FairGame</option><option value="CMS">COMSA [ETH]</option><option value="RCT">RealChain</option><option value="BFT">BnkToTheFuture</option><option value="BSTN">BitStation</option><option value="GEM">Gems </option><option value="TOPC">TopChain</option><option value="FIL">Filecoin [Futures]</option><option value="OF">OFCOIN</option><option value="UBTC">United Bitcoin</option><option value="LIGHT">LightChain</option><option value="AWR">AWARE</option><option value="KST">StarCoin</option><option value="XUC">Exchange Union</option><option value="NTK">Neurotoken</option><option value="VLC">ValueChain</option><option value="CMS*">COMSA [XEM]</option><option value="FRGC">Fargocoin</option><option value="XTZ">Tezos (Pre-Launch)</option><option value="MAG*">Maggie</option><option value="SSC">SelfSell</option><option value="BCDN">BlockCDN</option><option value="LBTC*">Lightning Bitcoin [Futures]</option><option value="WETH">WETH</option><option value="SCC">StockChain</option><option value="HLC">HalalChain</option><option value="IPC">IPChain</option><option value="ATC">Arbitracoin</option><option value="AMLT">AMLT Token</option><option value="FID">Fidelium</option><option value="EARTH">Earth Token</option><option value="PRS">PressOne</option><option value="EOSDAC">eosDAC</option><option value="QUBE">Qube</option><option value="BIG">BigONE Token</option><option value="DIG">Dignity</option><option value="MRK">MARK.SPACE</option><option value="UIP">UnlimitedIP</option><option value="ADK">Aidos Kuneen</option><option value="ADI">Aditus</option><option value="CFUN">CFun</option><option value="AVH">Animation Vision Cash</option><option value="READ">Read</option><option value="BBI">BelugaPay</option><option value="WC">WINCOIN</option><option value="XIN*">Infinity Economics</option><option value="CVH">Curriculum Vitae</option><option value="SBC">StrikeBitClub</option><option value="BRM">BrahmaOS</option><option value="TDS">TokenDesk</option><option value="CHX">Chainium</option><option value="CROP">Cropcoin</option><option value="XTL">Stellite</option><option value="XOT">Internet of Things</option><option value="SEN">Consensus</option><option value="CANDY">Candy</option><option value="IDT">InvestDigital</option><option value="GCS">GameChain System</option><option value="XID">Sphre AIR </option><option value="ECH">Etherecash</option><option value="BT2">BT2 [CST]</option><option value="SWTC">Jingtum Tech</option><option value="HPY">Hyper Pay</option><option value="GBG">Golos Gold</option><option value="DERO">Dero</option><option value="WIN">WCOIN</option><option value="GOD">Bitcoin God</option><option value="ANI">Animecoin</option><option value="B2X">SegWit2x</option><option value="SNIP">SnipCoin</option><option value="MLM">MktCoin</option><option value="BUBO">Budbo</option><option value="BELA">Bela</option><option value="SIC">Swisscoin</option><option value="ABC">Alphabit</option><option value="PCS">Pabyosi Coin (Special)</option><option value="BSR">BitSoar</option><option value="MSD">MSD</option><option value="XSTC">Safe Trade Coin</option><option value="FDZ">Friendz</option><option value="APC">AlpaCoin</option><option value="IFC">Infinitecoin</option><option value="GRMD">GreenMed</option><option value="EMB">EmberCoin</option><option value="PHI">PHI Token</option><option value="PCL">Peculium</option><option value="ACC**">ACChain</option><option value="MFG">SyncFab</option><option value="LST">Lendroid Support Token</option><option value="BAR">Titanium Blockchain</option><option value="W3C">W3Coin</option><option value="ENT*">ENTCash</option><option value="XID*">International Diamond</option><option value="CLUB">ClubCoin</option><option value="DUTCH">Dutch Coin</option><option value="CEFS">CryptopiaFeeShares</option><option value="OX">OX Fina</option><option value="SPK">Sparks</option><option value="EDRC">EDRCoin</option><option value="WA">WA Space</option><option value="NOX">Nitro</option><option value="HDLB">HODL Bucks</option><option value="UTT">United Traders Token</option><option value="EDT">EtherDelta Token</option><option value="CLD">Cloud</option><option value="MCR">Macro</option><option value="SLOTH">Slothcoin</option><option value="COR">CORION</option><option value="MARX">MarxCoin</option><option value="PRES">President Trump</option><option value="RBBT">RabbitCoin</option><option value="NAMO">NamoCoin</option><option value="MCI">Musiconomi</option><option value="ERA">ERA</option><option value="SONO">SONO</option><option value="HIGH">High Gain</option><option value="XRY">Royalties</option><option value="BET">BetaCoin</option><option value="SIGMA">SIGMAcoin</option><option value="HC">Harvest Masternode Coin</option><option value="INDI">Indicoin</option><option value="ZBC">Zilbercoin</option><option value="TLE">Tattoocoin (Limited Edition)</option><option value="EAG">EA Coin</option><option value="ZENGOLD">ZenGold</option><option value="TESLA">TeslaCoilCoin</option><option value="FUTC">FutCoin</option><option value="FRN">Francs</option><option value="BTCM">BTCMoon</option><option value="ROYAL">RoyalCoin</option><option value="NUMUS">NumusCash</option><option value="DON">Donationcoin</option><option value="PRN">Protean</option><option value="TER">TerraNova</option><option value="RYZ">ANRYZE</option><option value="LDCN">LandCoin</option><option value="SJW">SJWCoin</option><option value="GDC">GrandCoin</option><option value="CYDER">Cyder</option><option value="MBL">MobileCash</option><option value="BITCF">First Bitcoin Capital</option><option value="GAIN">UGAIN</option><option value="DAV">DavorCoin</option><option value="PLX">PlexCoin</option><option value="ELITE">Ethereum Lite</option><option value="CHEAP">Cheapcoin</option><option value="UNRC">UniversalRoyalCoin</option><option value="SJCX">Storjcoin X</option><option value="SKR">Sakuracoin</option><option value="HYPER">Hyper</option><option value="AV">AvatarCoin</option><option value="TURBO">TurboCoin</option><option value="TOPAZ">Topaz Coin</option><option value="ETT*">EncryptoTel [ETH]</option><option value="BLAZR">BlazerCoin</option><option value="TELL">Tellurion</option><option value="TCOIN">T-coin</option><option value="DMC">DynamicCoin</option><option value="WINK">Wink</option><option value="QBT">Cubits</option><option value="BIT">First Bitcoin</option><option value="MINEX">Minex</option><option value="GAY">GAY Money</option><option value="CME">Cashme</option><option value="HNC*">Huncoin</option><option value="GRX">GOLD Reward Token</option><option value="BTE">BitSerial</option><option value="BUB">Bubble</option><option value="SHA">SHACoin</option><option value="BEST">BestChain</option><option value="GMX">GoldMaxCoin</option><option value="POKE">PokeCoin</option><option value="SUP">Superior Coin</option><option value="XTD">XTD Coin</option><option value="HALLO">Halloween Coin</option><option value="RUNNERS">Runners</option><option value="ANTX">Antimatter</option><option value="KDC">KlondikeCoin</option><option value="WIC">Wi Coin</option><option value="LEVO">Levocoin</option><option value="UNITY">SuperNET</option><option value="SMOKE">Smoke</option><option value="UNC">UNCoin</option><option value="PRIMU">Primulon</option><option value="NEOG">NEO GOLD</option><option value="CFC">CoffeeCoin</option><option value="RICHX">RichCoin</option><option value="BAT*">BatCoin</option><option value="OP">Operand</option><option value="GARY">President Johnson</option><option value="RHFC">RHFCoin</option><option value="MAGN">Magnetcoin</option><option value="INDIA">India Coin</option><option value="UR">UR</option><option value="WSX">WeAreSatoshi</option><option value="AKY">Akuya Coin</option><option value="ZSE">ZSEcoin</option><option value="BTBc">Bitbase</option><option value="KARMA">Karmacoin</option><option value="XQN">Quotient</option><option value="TODAY">TodayCoin</option><option value="AXIOM">Axiom</option><option value="RCN*">Rcoin</option><option value="STEX">STEX</option><option value="CC">CyberCoin</option><option value="BSN">Bastonet</option><option value="NBIT">netBit</option><option value="ACES">Aces</option><option value="RUBIT">RubleBit</option><option value="DASHS">Dashs</option><option value="FONZ">Fonziecoin</option><option value="DBG">Digital Bullion Gold</option><option value="LEPEN">LePen</option><option value="SKULL">Pirate Blocks</option><option value="SISA">SISA</option><option value="LKC">LinkedCoin</option><option value="MONETA">Moneta</option><option value="SAK">Sharkcoin</option><option value="PSY">Psilocybin</option><option value="FAP">FAPcoin</option><option value="FAZZ">Fazzcoin</option><option value="REGA">Regacoin</option><option value="CYC">Cycling Coin</option><option value="DCRE">DeltaCredits</option><option value="SPORT">SportsCoin</option><option value="TRICK">TrickyCoin</option><option value="X2">X2</option><option value="SHELL">ShellCoin</option><option value="OPES">Opescoin</option><option value="PAYP">PayPeer</option><option value="HCC">Happy Creator Coin</option><option value="FRWC">FrankyWillCoin</option><option value="KASHH">KashhCoin</option><option value="BITOK">Bitok</option><option value="TCR">TheCreed</option><option value="DISK">DarkLisk</option><option value="OMC">Omicron</option><option value="EGG">EggCoin</option><option value="LAZ">Lazaruscoin</option><option value="GML">GameLeagueCoin</option><option value="PRM">PrismChain</option><option value="BIRDS">Birds</option><option value="THS">TechShares</option><option value="ACN">Avoncoin</option><option value="QORA">Qora</option><option value="TOP*">TopCoin</option><option value="CRYPT">CryptCoin</option><option value="ASN">Aseancoin</option><option value="EREAL">eREAL</option><option value="XVC">Vcash</option><option value="UGT">UG Token</option><option value="FRCT">Farstcoin</option></select>    </div>
</div>

<nav id="top-menu" class="ui borderless fluid fixed menu">
    
        <a id="sidebar-menu-toggle" class="item"><i class="sidebar icon"></i></a>
        <a href="index.php" class="brand item"><img id="header-logo" src="images/1524688786.png"></a>        <div class="right menu">
            <a class="item menu-item" href="market.php">Market</a><a class="item menu-item" href="converter.php">Converter</a><a class="item menu-item" href="icos.php">ICOs</a><a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/"><i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg"><i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/"><i class="instagram icon"></i></a>            <div class="price-currency-item item">
                <select class="price-currency  ui search dropdown"><option value="BTC">Bitcoin</option><option selected value="USD">US Dollar</option><option value="EUR">Eurozone Euro</option><option value="GBP">Pound Sterling</option><option value="JPY">Japanese Yen</option><option value="CAD">Canadian Dollar</option><option value="AUD">Australian Dollar</option><option value="CNY">Chinese Yuan</option><option value="CHF">Swiss Franc</option><option value="SEK">Swedish Krona</option><option value="NZD">New Zealand Dollar</option><option value="KRW">South Korean Won</option><option value="AED">UAE Dirham</option><option value="AFN">Afghan Afghani</option><option value="ALL">Albanian Lek</option><option value="AMD">Armenian Dram</option><option value="ANG">Netherlands Antillean Guilder</option><option value="AOA">Angolan Kwanza</option><option value="ARS">Argentine Peso</option><option value="AWG">Aruban Florin</option><option value="AZN">Azerbaijani Manat</option><option value="BAM">Bosnia-Herzegovina Convertible Mark</option><option value="BBD">Barbadian Dollar</option><option value="BDT">Bangladeshi Taka</option><option value="BGN">Bulgarian Lev</option><option value="BHD">Bahraini Dinar</option><option value="BIF">Burundian Franc</option><option value="BMD">Bermudan Dollar</option><option value="BND">Brunei Dollar</option><option value="BOB">Bolivian Boliviano</option><option value="BRL">Brazilian Real</option><option value="BSD">Bahamian Dollar</option><option value="BTN">Bhutanese Ngultrum</option><option value="BWP">Botswanan Pula</option><option value="BZD">Belize Dollar</option><option value="CDF">Congolese Franc</option><option value="CLF">Chilean Unit of Account (UF)</option><option value="CLP">Chilean Peso</option><option value="COP">Colombian Peso</option><option value="CRC">Costa Rican Colón</option><option value="CUP">Cuban Peso</option><option value="CVE">Cape Verdean Escudo</option><option value="CZK">Czech Koruna</option><option value="DJF">Djiboutian Franc</option><option value="DKK">Danish Krone</option><option value="DOP">Dominican Peso</option><option value="DZD">Algerian Dinar</option><option value="EGP">Egyptian Pound</option><option value="ETB">Ethiopian Birr</option><option value="FJD">Fijian Dollar</option><option value="FKP">Falkland Islands Pound</option><option value="GEL">Georgian Lari</option><option value="GHS">Ghanaian Cedi</option><option value="GIP">Gibraltar Pound</option><option value="GMD">Gambian Dalasi</option><option value="GNF">Guinean Franc</option><option value="GTQ">Guatemalan Quetzal</option><option value="GYD">Guyanaese Dollar</option><option value="HKD">Hong Kong Dollar</option><option value="HNL">Honduran Lempira</option><option value="HRK">Croatian Kuna</option><option value="HTG">Haitian Gourde</option><option value="HUF">Hungarian Forint</option><option value="IDR">Indonesian Rupiah</option><option value="ILS">Israeli Shekel</option><option value="INR">Indian Rupee</option><option value="IQD">Iraqi Dinar</option><option value="IRR">Iranian Rial</option><option value="ISK">Icelandic Króna</option><option value="JEP">Jersey Pound</option><option value="JMD">Jamaican Dollar</option><option value="JOD">Jordanian Dinar</option><option value="KES">Kenyan Shilling</option><option value="KGS">Kyrgystani Som</option><option value="KHR">Cambodian Riel</option><option value="KMF">Comorian Franc</option><option value="KPW">North Korean Won</option><option value="KWD">Kuwaiti Dinar</option><option value="KYD">Cayman Islands Dollar</option><option value="KZT">Kazakhstani Tenge</option><option value="LAK">Laotian Kip</option><option value="LBP">Lebanese Pound</option><option value="LKR">Sri Lankan Rupee</option><option value="LRD">Liberian Dollar</option><option value="LSL">Lesotho Loti</option><option value="LYD">Libyan Dinar</option><option value="MAD">Moroccan Dirham</option><option value="MDL">Moldovan Leu</option><option value="MGA">Malagasy Ariary</option><option value="MKD">Macedonian Denar</option><option value="MMK">Myanma Kyat</option><option value="MNT">Mongolian Tugrik</option><option value="MOP">Macanese Pataca</option><option value="MRU">Mauritanian Ouguiya</option><option value="MUR">Mauritian Rupee</option><option value="MVR">Maldivian Rufiyaa</option><option value="MWK">Malawian Kwacha</option><option value="MXN">Mexican Peso</option><option value="MYR">Malaysian Ringgit</option><option value="MZN">Mozambican Metical</option><option value="NAD">Namibian Dollar</option><option value="NGN">Nigerian Naira</option><option value="NIO">Nicaraguan Córdoba</option><option value="NOK">Norwegian Krone</option><option value="NPR">Nepalese Rupee</option><option value="OMR">Omani Rial</option><option value="PAB">Panamanian Balboa</option><option value="PEN">Peruvian Nuevo Sol</option><option value="PGK">Papua New Guinean Kina</option><option value="PHP">Philippine Peso</option><option value="PKR">Pakistani Rupee</option><option value="PLN">Polish Zloty</option><option value="PYG">Paraguayan Guarani</option><option value="QAR">Qatari Rial</option><option value="RON">Romanian Leu</option><option value="RSD">Serbian Dinar</option><option value="RUB">Russian Ruble</option><option value="RWF">Rwandan Franc</option><option value="SAR">Saudi Riyal</option><option value="SBD">Solomon Islands Dollar</option><option value="SCR">Seychellois Rupee</option><option value="SDG">Sudanese Pound</option><option value="SGD">Singapore Dollar</option><option value="SHP">Saint Helena Pound</option><option value="SLL">Sierra Leonean Leone</option><option value="SOS">Somali Shilling</option><option value="SRD">Surinamese Dollar</option><option value="STN">São Tomé and Príncipe Dobra</option><option value="SVC">Salvadoran Colón</option><option value="SYP">Syrian Pound</option><option value="SZL">Swazi Lilangeni</option><option value="THB">Thai Baht</option><option value="TJS">Tajikistani Somoni</option><option value="TMT">Turkmenistani Manat</option><option value="TND">Tunisian Dinar</option><option value="TOP">Tongan Paʻanga</option><option value="TRY">Turkish Lira</option><option value="TTD">Trinidad and Tobago Dollar</option><option value="TWD">New Taiwan Dollar</option><option value="TZS">Tanzanian Shilling</option><option value="UAH">Ukrainian Hryvnia</option><option value="UGX">Ugandan Shilling</option><option value="UYU">Uruguayan Peso</option><option value="UZS">Uzbekistan Som</option><option value="VEF">Venezuelan Bolívar Fuerte</option><option value="VND">Vietnamese Dong</option><option value="VUV">Vanuatu Vatu</option><option value="WST">Samoan Tala</option><option value="XAF">CFA Franc BEAC</option><option value="XCD">East Caribbean Dollar</option><option value="XOF">CFA Franc BCEAO</option><option value="XPF">CFP Franc</option><option value="YER">Yemeni Rial</option><option value="ZAR">South African Rand</option><option value="ZMW">Zambian Kwacha</option><option value="ZWL">Zimbabwean Dollar</option><option value="XAG">Silver (troy ounce)</option><option value="XAU">Gold (troy ounce)</option><option value="ETH">Ethereum</option><option value="XRP">Ripple</option><option value="BCH">Bitcoin Cash</option><option value="EOS">EOS</option><option value="LTC">Litecoin</option><option value="ADA">Cardano</option><option value="XLM">Stellar</option><option value="MIOTA">IOTA</option><option value="TRX">TRON</option><option value="NEO">NEO</option><option value="XMR">Monero</option><option value="DASH">Dash</option><option value="XEM">NEM</option><option value="USDT">Tether</option><option value="ETC">Ethereum Classic</option><option value="VEN">VeChain</option><option value="OMG">OmiseGO</option><option value="QTUM">Qtum</option><option value="ICX">ICON</option><option value="BNB">Binance Coin</option><option value="BTG">Bitcoin Gold</option><option value="LSK">Lisk</option><option value="STEEM">Steem</option><option value="ZEC">Zcash</option><option value="XVG">Verge</option><option value="SC">Siacoin</option><option value="BCN">Bytecoin</option><option value="BTM*">Bytom</option><option value="NANO">Nano</option><option value="BCD">Bitcoin Diamond</option><option value="WAN">Wanchain</option><option value="BTCP">Bitcoin Private</option><option value="PPT">Populous</option><option value="BTS">BitShares</option><option value="ZIL">Zilliqa</option><option value="AE">Aeternity</option><option value="DOGE">Dogecoin</option><option value="MKR">Maker</option><option value="DCR">Decred</option><option value="STRAT">Stratis</option><option value="ONT">Ontology</option><option value="XIN">Mixin</option><option value="ZRX">0x</option><option value="WAVES">Waves</option><option value="DGD">DigixDAO</option><option value="HSR">Hshare</option><option value="RHOC">RChain</option><option value="GNT">Golem</option><option value="SNT">Status</option><option value="AION">Aion</option><option value="WTC">Waltonchain</option><option value="REP">Augur</option><option value="LRC">Loopring</option><option value="DGB">DigiByte</option><option value="BAT">Basic Attention Token</option><option value="IOST">IOStoken</option><option value="KMD">Komodo</option><option value="ARDR">Ardor</option><option value="MITH">Mithril</option><option value="KNC">Kyber Network</option><option value="ARK">Ark</option><option value="MONA">MonaCoin</option><option value="KCS">KuCoin Shares</option><option value="CENNZ">Centrality</option><option value="PIVX">PIVX</option><option value="ELF">aelf</option><option value="SYS">Syscoin</option><option value="CNX">Cryptonex</option><option value="DRGN">Dragonchain</option><option value="SUB">Substratum</option><option value="DCN">Dentacoin</option><option value="GAS">Gas</option><option value="NPXS">Pundi X</option><option value="STORM">Storm</option><option value="QASH">QASH</option><option value="ETHOS">Ethos</option><option value="FCT">Factom</option><option value="NAS">Nebulas</option><option value="GTO">Gifto</option><option value="RDD">ReddCoin</option><option value="CTXC">Cortex</option><option value="BNT">Bancor</option><option value="VERI">Veritaseum</option><option value="SALT">SALT</option><option value="FUN">FunFair</option><option value="GXS">GXChain</option><option value="ELA">Elastos</option><option value="WAX">WAX</option><option value="XZC">ZCoin</option><option value="NXT">Nxt</option><option value="POWR">Power Ledger</option><option value="ENG">Enigma</option><option value="MCO">Monaco</option><option value="KIN">Kin</option><option value="R">Revain</option><option value="LOOM">Loom Network</option><option value="ETN">Electroneum</option><option value="NCASH">Nucleus Vision</option><option value="REQ">Request Network</option><option value="GBYTE">Byteball Bytes</option><option value="MAID">MaidSafeCoin</option><option value="FSN">Fusion</option><option value="NEBL">Neblio</option><option value="LINK">ChainLink</option><option value="PAY">TenX</option><option value="SMT">SmartMesh</option><option value="DBC">DeepBrain Chain</option><option value="ZEN">ZenCash</option><option value="SMART">SmartCash</option><option value="STORJ">Storj</option><option value="PART">Particl</option><option value="SKY">Skycoin</option><option value="CND">Cindicator</option><option value="MANA">Decentraland</option><option value="ICN">Iconomi</option><option value="ACT">Achain</option><option value="MAN">Matrix AI Network</option><option value="GTC">Game.com</option><option value="POA">POA Network</option><option value="CVC">Civic</option><option value="EMC">Emercoin</option><option value="NXS">Nexus</option><option value="BOS">BOScoin</option><option value="NULS">Nuls</option><option value="TPAY">TokenPay</option><option value="PAYX">Paypex</option><option value="DENT">Dent</option><option value="POLY">Polymath</option><option value="POE">Po.et</option><option value="LCC">Litecoin Cash</option><option value="DTR">Dynamic Trading Rights</option><option value="GNO">Gnosis</option><option value="BTCD">BitcoinDark</option><option value="RLC">iExec RLC</option><option value="MTL">Metal</option><option value="VTC">Vertcoin</option><option value="DEW">DEW</option><option value="TNB">Time New Bank</option><option value="QSP">Quantstamp</option><option value="ANT">Aragon</option><option value="CMT">CyberMiles</option><option value="GAME">GameCredits</option><option value="BTX">Bitcore</option><option value="HT">Huobi Token</option><option value="SAN">Santiment Network Token</option><option value="ENJ">Enjin Coin</option><option value="SPHTX">SophiaTX</option><option value="RDN">Raiden Network Token</option><option value="ABT">Arcblock</option><option value="AGI">SingularityNET</option><option value="MED">MediBloc</option><option value="HPB">High Performance Blockchain</option><option value="PPP">PayPie</option><option value="GRS">Groestlcoin</option><option value="CPX">Apex</option><option value="AUTO">Cube</option><option value="GNX">Genaro Network</option><option value="XDN">DigitalNote</option><option value="BLOCK">Blocknet</option><option value="AMB">Ambrosus</option><option value="SRN">SIRIN LABS Token</option><option value="UBQ">Ubiq</option><option value="DROP">Dropil</option><option value="DTA">DATA</option><option value="RUFF">Ruff</option><option value="CS">Credits</option><option value="TKY">THEKEY</option><option value="VEE">BLOCKv</option><option value="RPX">Red Pulse</option><option value="THETA">Theta Token</option><option value="BLZ">Bluzelle</option><option value="SNM">SONM</option><option value="IGNIS">Ignis</option><option value="NAV">NavCoin</option><option value="PLR">Pillar</option><option value="ZCL">ZClassic</option><option value="INK">Ink</option><option value="GVT">Genesis Vision</option><option value="LEND">ETHLend</option><option value="CLOAK">CloakCoin</option><option value="AST">AirSwap</option><option value="TOMO">TomoChain</option><option value="XAS">Asch</option><option value="DDD">Scry.info</option><option value="BAY">BitBay</option><option value="EMC2">Einsteinium</option><option value="BIX">Bibox Token</option><option value="OST">OST</option><option value="C20">CRYPTO20</option><option value="ADX">AdEx</option><option value="QRL">Quantum Resistant Ledger</option><option value="RCN">Ripio Credit Network</option><option value="IHT">IHT Real Estate Protocol</option><option value="EDO">Eidoo</option><option value="DATA">Streamr DATAcoin</option><option value="TEL">Telcoin</option><option value="ITC">IoT Chain</option><option value="BTO">Bottos</option><option value="CRPT">Crypterium</option><option value="ION">ION</option><option value="BRD">Bread</option><option value="MNX">MinexCoin</option><option value="WPR">WePower</option><option value="PPC">Peercoin</option><option value="ELEC">Electrify.Asia</option><option value="INS">INS Ecosystem</option><option value="SLS">SaluS</option><option value="VIBE">VIBE</option><option value="VIA">Viacoin</option><option value="NANJ">NANJCOIN</option><option value="BCO">BridgeCoin</option><option value="INT">Internet Node Token</option><option value="WABI">WaBi</option><option value="EDG">Edgeless</option><option value="SNGLS">SingularDTV</option><option value="JNT">Jibrel Network</option><option value="APPC">AppCoins</option><option value="DNT">district0x</option><option value="RNTB">BitRent</option><option value="SPANK">SpankChain</option><option value="UTK">UTRUST</option><option value="MDS">MediShares</option><option value="WINGS">Wings</option><option value="PURA">Pura</option><option value="TNT">Tierion</option><option value="LBC">LBRY Credits</option><option value="TRAC">OriginTrail</option><option value="MOD">Modum</option><option value="OCN">Odyssey</option><option value="EVN">Envion</option><option value="QLC">QLINK</option><option value="XCP">Counterparty</option><option value="WGR">Wagerr</option><option value="BURST">Burst</option><option value="PRL">Oyster</option><option value="FTC">Feathercoin</option><option value="TRIG">Triggers</option><option value="DPY">Delphy</option><option value="FUEL">Etherparty</option><option value="ECA">Electra</option><option value="NLG">Gulden</option><option value="MLN">Melon</option><option value="DCT">DECENT</option><option value="SBD*">Steem Dollars</option><option value="MOBI">Mobius</option><option value="DAT">Datum</option><option value="PRE">Presearch</option><option value="XP">Experience Points</option><option value="TNC">Trinity Network Credit</option><option value="ZOI">Zoin</option><option value="TKN">TokenCard</option><option value="SOAR">Soarcoin</option><option value="ADT">adToken</option><option value="BCPT">BlockMason Credit Protocol</option><option value="TAAS">TaaS</option><option value="NGC">NAGA</option><option value="SXDT">Spectre.ai Dividend Token</option><option value="XBY">XTRABYTES</option><option value="CDT">Blox</option><option value="UTNP">Universa</option><option value="RKT">Rock</option><option value="ETP">Metaverse ETP</option><option value="SOC">All Sports</option><option value="COSS">COSS</option><option value="BITCNY">bitCNY</option><option value="SAFEX">Safe Exchange Coin</option><option value="BAX">BABB</option><option value="LET">LinkEye</option><option value="LGO">Legolas Exchange</option><option value="REN">Republic Protocol</option><option value="ZPT">Zeepin</option><option value="BKX">Bankex</option><option value="CSC">CasinoCoin</option><option value="QUN">QunQun</option><option value="XEL">Elastic</option><option value="KICK">KickCoin</option><option value="DATX">DATx</option><option value="UKG">Unikoin Gold</option><option value="BANCA">Banca</option><option value="ODE">ODEM</option><option value="RFR">Refereum</option><option value="TEN">Tokenomy</option><option value="VIB">Viberate</option><option value="GUP">Matchpool</option><option value="SHIFT">Shift</option><option value="XDCE">XinFin Network</option><option value="STK">STK</option><option value="YOYOW">YOYOW</option><option value="SHIP">ShipChain</option><option value="RVN">Ravencoin</option><option value="HAV">Havven</option><option value="XSH">SHIELD</option><option value="PRO">Propy</option><option value="DIME">Dimecoin</option><option value="HTML">HTMLCOIN</option><option value="CFI">Cofound.it</option><option value="TAU">Lamden</option><option value="PHR">Phore</option><option value="MER">Mercury</option><option value="AEON">Aeon</option><option value="CPC*">CPChain</option><option value="DAI">Dai</option><option value="HMQ">Humaniq</option><option value="ACAT">Alphacat</option><option value="ONION">DeepOnion</option><option value="AMP">Synereo</option><option value="LUN">Lunyr</option><option value="HST">Decision Token</option><option value="1ST">FirstBlood</option><option value="TIO">Trade Token</option><option value="SENT">Sentinel</option><option value="DMT">DMarket</option><option value="EKT">EDUCare</option><option value="UP">UpToken</option><option value="UGC">ugChain</option><option value="POT">PotCoin</option><option value="PEPECASH">Pepe Cash</option><option value="NMC">Namecoin</option><option value="TRST">WeTrust</option><option value="SENC">Sentinel Chain</option><option value="CRW">Crown</option><option value="UNO">Unobtanium</option><option value="DOCK">Dock</option><option value="AIDOC">AI Doctor</option><option value="FOTA">Fortuna</option><option value="COB">Cobinhood</option><option value="UUU">U Network</option><option value="ECC">ECC</option><option value="TIX">Blocktix</option><option value="MGO">MobileGo</option><option value="ZSC">Zeusshield</option><option value="EVX">Everex</option><option value="HMC">Hi Mutual Society</option><option value="IOC">I/O Coin</option><option value="SWFTC">SwftCoin</option><option value="MTH">Monetha</option><option value="XSN">StakeNet</option><option value="MSP">Mothership</option><option value="MWAT">Restart Energy MWAT</option><option value="BITB">Bean Cash</option><option value="SWH">Switcheo</option><option value="THC">HempCoin</option><option value="KEY">Selfkey</option><option value="LYM">Lympo</option><option value="BCA">Bitcoin Atom</option><option value="SNC">SunContract</option><option value="NMR">Numeraire</option><option value="TRUE">True Chain</option><option value="TSL">Energo</option><option value="ARN">Aeron</option><option value="MTN">Medicalchain</option><option value="DADI">DADI</option><option value="AIT">AICHAIN</option><option value="CAPP">Cappasity</option><option value="$PAC">PACcoin</option><option value="ORME">Ormeus Coin</option><option value="RNT">OneRoot Network</option><option value="DLT">Agrello</option><option value="PPY">Peerplays</option><option value="SPC">SpaceChain</option><option value="BLK">BlackCoin</option><option value="YEE">YEE</option><option value="DXT">Datawallet</option><option value="KRM">Karma</option><option value="ALQO">ALQO</option><option value="XPM">Primecoin</option><option value="CV">carVertical</option><option value="LEO">LEOcoin</option><option value="BOT">Bodhi</option><option value="MDA">Moeda Loyalty Points</option><option value="PASC">Pascal Coin</option><option value="BLT">Bloom</option><option value="DMD">Diamond</option><option value="RADS">Radium</option><option value="VRC">VeriCoin</option><option value="QBT*">Qbao</option><option value="OCT">OracleChain</option><option value="ATM">ATMChain</option><option value="OMNI">Omni</option><option value="GRID">Grid+</option><option value="MDT">Measurable Data Token</option><option value="RVR">RevolutionVR</option><option value="HOT">Hydro Protocol</option><option value="FLASH">Flash</option><option value="AXP">aXpire</option><option value="SIB">SIBCoin</option><option value="COV">Covesting</option><option value="FAIR">FairCoin</option><option value="GRC">GridCoin</option><option value="MTX">Matryx</option><option value="STQ">Storiqa</option><option value="LKK">Lykke</option><option value="POSW">PoSW Coin</option><option value="HVN">Hive Project</option><option value="CAT*">BitClave</option><option value="EDR">E-Dinar Coin</option><option value="OAX">OAX</option><option value="IDH">indaHash</option><option value="UQC">Uquid Coin</option><option value="PARETO">Pareto Network</option><option value="BBN">Banyan Network</option><option value="MEDIC">MedicCoin</option><option value="XWC">WhiteCoin</option><option value="LA">LATOKEN</option><option value="EVE">Devery</option><option value="TCT">TokenClub</option><option value="LUX">LUXCoin</option><option value="BPT">Blockport</option><option value="RMT">SureRemit</option><option value="ICOS">ICOS</option><option value="PRA">ProChain</option><option value="HKN">Hacken</option><option value="EXP">Expanse</option><option value="IXT">iXledger</option><option value="INCNT">Incent</option><option value="AURA">Aurora DAO</option><option value="TFD">TE-FOOD</option><option value="CHSB">SwissBorg</option><option value="PZM">PRIZM</option><option value="BMC">Blackmoon</option><option value="BIS">Bismuth</option><option value="TBAR">Titanium BAR</option><option value="SLT">Smartlands</option><option value="EKO">EchoLink</option><option value="FLO">FlorinCoin</option><option value="PLBT">Polybius</option><option value="NCT">PolySwarm</option><option value="SLR">SolarCoin</option><option value="SRCOIN">SRCOIN</option><option value="MUE">MonetaryUnit</option><option value="BERRY">Rentberry</option><option value="DIVX">Divi</option><option value="BBR">Boolberry</option><option value="BEE">Bee Token</option><option value="MOT">Olympus Labs</option><option value="COLX">ColossusXT</option><option value="STX">Stox</option><option value="ZAP">Zap</option><option value="BDG">BitDegree</option><option value="XMY">Myriad</option><option value="ARY">Block Array</option><option value="LMC">LoMoCoin</option><option value="SNOV">Snovio</option><option value="LINDA">Linda</option><option value="RISE">Rise</option><option value="RBY">Rubycoin</option><option value="SWM">Swarm</option><option value="BITUSD">bitUSD</option><option value="OK">OKCash</option><option value="XRL">Rialto</option><option value="BSD*">BitSend</option><option value="NLC2">NoLimitCoin</option><option value="DNA">EncrypGen</option><option value="DTB">Databits</option><option value="BITG">Bitcoin Green</option><option value="CLAM">Clams</option><option value="DEB">Debitum</option><option value="ENRG">Energycoin</option><option value="AUC">Auctus</option><option value="NEOS">NeosCoin</option><option value="IPBC">Interplanetary Broadcast Coin</option><option value="CAS">Cashaa</option><option value="XSPEC">Spectrecoin</option><option value="SWT">Swarm City</option><option value="XPA">XPA</option><option value="CXO">CargoX</option><option value="DICE">Etheroll</option><option value="FLDC">FoldingCoin</option><option value="PRG">Paragon</option><option value="NET*">Nimiq Exchange Token</option><option value="DIM">DIMCOIN</option><option value="ALIS">ALIS</option><option value="CVT">CyberVein</option><option value="FLUZ">Fluz Fluz</option><option value="PTOY">Patientory</option><option value="DRT">DomRaider</option><option value="GBX">GoByte</option><option value="NEU">Neumark</option><option value="DBET">DecentBet</option><option value="NXC">Nexium</option><option value="MOON">Mooncoin</option><option value="FLIXX">Flixxo</option><option value="MUSIC">Musicoin</option><option value="EVR">Everus</option><option value="CREDO">Credo</option><option value="QAU">Quantum</option><option value="HAT">Hat.Exchange</option><option value="GOLOS">Golos</option><option value="LALA">LALA World</option><option value="LOC">LockTrip</option><option value="TUSD">True USD</option><option value="BCC">BitConnect</option><option value="REM">Remme</option><option value="EFX">Effect.AI</option><option value="AIR">AirToken</option><option value="ART">Maecenas</option><option value="NYC">NewYorkCoin</option><option value="SYNX">Syndicate</option><option value="CAN">CanYaCoin</option><option value="IPSX">IP Exchange</option><option value="CHP">CoinPoker</option><option value="PST">Primas</option><option value="FTX">FintruX Network</option><option value="NPX">NaPoleonX</option><option value="BNTY">Bounty0x</option><option value="LDC">Leadcoin</option><option value="DBIX">DubaiCoin</option><option value="WRC">Worldcore</option><option value="GAM">Gambit</option><option value="WCT">Waves Community Token</option><option value="HWC">HollyWoodCoin</option><option value="OXY">Oxycoin</option><option value="COFI">CoinFi</option><option value="AUR">Auroracoin</option><option value="DTH">Dether</option><option value="MYST">Mysterium</option><option value="XLR">Solaris</option><option value="ATN">ATN</option><option value="CBT">CommerceBlock</option><option value="TCC">The ChampCoin</option><option value="HEAT">HEAT</option><option value="SIG">Spectiv</option><option value="DYN">Dynamic</option><option value="XST">Stealthcoin</option><option value="PLU">Pluton</option><option value="BQ">bitqy</option><option value="FDX">FidentiaX</option><option value="POLIS">Polis</option><option value="PFR">Payfair</option><option value="TX">TransferCoin</option><option value="AVT">Aventus</option><option value="INSTAR">Insights Network</option><option value="HXX">Hexx</option><option value="IFT">InvestFeed</option><option value="ESP">Espers</option><option value="ADB">adbank</option><option value="TIME">Chronobank</option><option value="IPL">InsurePal</option><option value="SPHR">Sphere</option><option value="GETX">Guaranteed Ethurance Token Extra</option><option value="TIPS">FedoraCoin</option><option value="CVCOIN">CVCoin</option><option value="PURE">Pure</option><option value="TOA">ToaCoin</option><option value="SEQ">Sequence</option><option value="ELIX">Elixir</option><option value="MINT">Mintcoin</option><option value="ATL">ATLANT</option><option value="PINK">PinkCoin</option><option value="DAN">Daneel</option><option value="ZLA">Zilla</option><option value="COVAL">Circuits of Value</option><option value="PUT*">Profile Utility Token</option><option value="PND">Pandacoin</option><option value="CLR">ClearCoin</option><option value="MYB">MyBit Token</option><option value="ATB">ATBCoin</option><option value="OPT">Opus</option><option value="BCY">Bitcrystals</option><option value="RVT">Rivetz</option><option value="TKS">Tokes</option><option value="EBST">eBoost</option><option value="XAUR">Xaurum</option><option value="IOP">Internet of People</option><option value="BLUE">BLUE</option><option value="XNK">Ink Protocol</option><option value="CURE">Curecoin</option><option value="BWK">Bulwark</option><option value="VOISE">Voise</option><option value="PKT">Playkey</option><option value="PBL">Publica</option><option value="HGT">HelloGold</option><option value="CAG">Change</option><option value="DOVU">Dovu</option><option value="GEO">GeoCoin</option><option value="LIFE">LIFE</option><option value="B2B">B2BX</option><option value="POLL">ClearPoll</option><option value="REBL">REBL</option><option value="ADH">AdHive</option><option value="UCASH">U.CASH</option><option value="NVC">Novacoin</option><option value="ABY">ArtByte</option><option value="GLA">Gladius Token</option><option value="GET">GET Protocol</option><option value="TRF">Travelflex</option><option value="HAC">Hackspace Capital</option><option value="KORE">Kore</option><option value="HQX">HOQU</option><option value="MSR">Masari</option><option value="ERO">Eroscoin</option><option value="XHV">Haven Protocol</option><option value="PRIX">Privatix</option><option value="VIT">Vice Industry Token</option><option value="SXUT">Spectre.ai Utility Token</option><option value="DOPE">DopeCoin</option><option value="SPF">SportyCo</option><option value="BRX">Breakout Stake</option><option value="CHIPS">CHIPS</option><option value="OBITS">OBITS</option><option value="NVST">NVO</option><option value="CSNO">BitDice</option><option value="LEV">Leverj</option><option value="GAT">Gatcoin</option><option value="VIU">Viuly</option><option value="EXRN">EXRNchain</option><option value="PIRL">Pirl</option><option value="PING">CryptoPing</option><option value="XBC">Bitcoin Plus</option><option value="IDXM">IDEX Membership</option><option value="DOT">Dotcoin</option><option value="BTCZ">BitcoinZ</option><option value="LOCI">LOCIcoin</option><option value="PTC">Pesetacoin</option><option value="MEME">Memetic / PepeCoin</option><option value="TFL">TrueFlip</option><option value="SPD">Stipend</option><option value="AID">AidCoin</option><option value="NKC">Nework</option><option value="NIO*">Autonio</option><option value="SEXC">ShareX</option><option value="APX">APX</option><option value="GLD">GoldCoin</option><option value="CAT">BlockCAT</option><option value="EXCL">ExclusiveCoin</option><option value="HYP">HyperStake</option><option value="ASTRO">Astro</option><option value="QWARK">Qwark</option><option value="ERC">EuropeCoin</option><option value="KB3">B3Coin</option><option value="MAX">MaxCoin</option><option value="TRCT">Tracto</option><option value="J8T">JET8</option><option value="INXT">Internxt</option><option value="DEV">DeviantCoin</option><option value="USNBT">NuBits</option><option value="HUSH">Hush</option><option value="SUMO">Sumokoin</option><option value="1WO">1World</option><option value="XNN">Xenon</option><option value="PLAY">HEROcoin</option><option value="SPR">SpreadCoin</option><option value="SPRTS">Sprouts</option><option value="SEND">Social Send</option><option value="LEDU">Education Ecosystem</option><option value="VTR">vTorrent</option><option value="ING">Iungo</option><option value="WISH">MyWish</option><option value="BTM">Bitmark</option><option value="UNIT">Universal Currency</option><option value="CANN">CannabisCoin</option><option value="AIX">Aigang</option><option value="BON">Bonpay</option><option value="VRM">VeriumReserve</option><option value="NTRN">Neutron</option><option value="CPAY">Cryptopay</option><option value="2GIVE">2GIVE</option><option value="MONK">Monkey Project</option><option value="EXY">Experty</option><option value="MNTP">GoldMint</option><option value="STAC">StarterCoin</option><option value="DNR">Denarius</option><option value="UFR">Upfiring</option><option value="BIO">BioCoin</option><option value="ADST">AdShares</option><option value="HORSE">Ethorse</option><option value="DRP">DCORP</option><option value="BTDX">Bitcloud</option><option value="CPY">COPYTRACK</option><option value="ZEIT">Zeitcoin</option><option value="BRK">Breakout</option><option value="PIX">Lampix</option><option value="OTN">Open Trading Network</option><option value="SETH">Sether</option><option value="FLAP">FlappyCoin</option><option value="RC">RussiaCoin</option><option value="ZRC">ZrCoin</option><option value="GCR">Global Currency Reserve</option><option value="CRB">Creditbit</option><option value="REF">RefToken</option><option value="BLITZ">Blitzcash</option><option value="RIC">Riecoin</option><option value="EZT">EZToken</option><option value="SWIFT">Bitswift</option><option value="STAR">Starbase</option><option value="MVC">Maverick Chain</option><option value="BET*">DAO.Casino</option><option value="KRB">Karbo</option><option value="SSS">Sharechain</option><option value="BPL">Blockpool</option><option value="UFO">Uniform Fiscal Object</option><option value="TRC">Terracoin</option><option value="SHP*">Sharpe Platform Token</option><option value="RUPX">Rupaya</option><option value="PBT">Primalbase Token</option><option value="XMCC">Monoeci</option><option value="EGC">EverGreenCoin</option><option value="ZER">Zero</option><option value="ADC">AudioCoin</option><option value="QRK">Quark</option><option value="AU">AurumCoin</option><option value="ODN">Obsidian</option><option value="REAL">REAL</option><option value="SCL">Sociall</option><option value="DGPT">DigiPulse</option><option value="CMPCO">CampusCoin</option><option value="BEZ">Bezop</option><option value="HUC">HunterCoin</option><option value="TRUST">TrustPlus</option><option value="PIPL">PiplCoin</option><option value="XGOX">XGOX</option><option value="BASH">LuckChain</option><option value="PYLNT">Pylon Network</option><option value="ZEPH">Zephyr</option><option value="FOR">FORCE</option><option value="CRED">Verify</option><option value="TIE">Ties.DB</option><option value="RUP">Rupee</option><option value="VZT">Vezt</option><option value="1337">Elite</option><option value="JIYO">Jiyo</option><option value="AMM">MicroMoney</option><option value="SXC">Sexcoin</option><option value="HIRE">HireMatch</option><option value="EVC">EventChain</option><option value="EFL">e-Gulden</option><option value="PUT">PutinCoin</option><option value="VSX">Vsync</option><option value="TZC">TrezarCoin</option><option value="ZNY">Bitzeny</option><option value="XMG">Magi</option><option value="CRAVE">Crave</option><option value="EQT">EquiTrader</option><option value="LINX">Linx</option><option value="ACE">Ace</option><option value="CHC">ChainCoin</option><option value="808">808Coin</option><option value="GCN">GCN Coin</option><option value="QVT">Qvolta</option><option value="GRFT">Graft</option><option value="ARG">Argentum</option><option value="UIS">Unitus</option><option value="GMT">Mercury Protocol</option><option value="MAG">Magnet</option><option value="SENSE">Sense</option><option value="FRD">Farad</option><option value="MTNC">Masternodecoin</option><option value="TBX">Tokenbox</option><option value="NOBL">NobleCoin</option><option value="TES">TeslaCoin</option><option value="CREA">Creativecoin</option><option value="XBP">BlitzPredict</option><option value="ITNS">IntenseCoin</option><option value="ESZ">EtherSportz</option><option value="CPC">Capricoin</option><option value="LDOGE">LiteDoge</option><option value="SMS">Speed Mining Service</option><option value="INN">Innova</option><option value="MXT">MarteXcoin</option><option value="EFYT">Ergo</option><option value="ELLA">Ellaism</option><option value="DP">DigitalPrice</option><option value="DAY">Chronologic</option><option value="SMLY">SmileyCoin</option><option value="FYN">FundYourselfNow</option><option value="KZC">Kzcash</option><option value="WAND">WandX</option><option value="NKA">IncaKoin</option><option value="CDN">Canada eCoin</option><option value="HOLD">Interstellar Holdings</option><option value="EMV">Ethereum Movie Venture</option><option value="CL">Coinlancer</option><option value="EBTC">eBitcoin</option><option value="RAIN">Condensate</option><option value="UNB">UnbreakableCoin</option><option value="BTW">BitWhite</option><option value="BUN">BunnyCoin</option><option value="KEK">KekCoin</option><option value="STAK">STRAKS</option><option value="BBP">BiblePay</option><option value="IC">Ignition</option><option value="ANC">Anoncoin</option><option value="LNC">Blocklancer</option><option value="ALT">Altcoin</option><option value="ORB">Orbitcoin</option><option value="YOC">Yocoin</option><option value="ONG">onG.social</option><option value="BUZZ">BuzzCoin</option><option value="AHT">Bowhead</option><option value="KOBO">Kobocoin</option><option value="ETBS">Ethbits</option><option value="IND">Indorse Token</option><option value="SAGA">SagaCoin</option><option value="TIG">Tigereum</option><option value="LATX">LatiumX</option><option value="XFT">Footy Cash</option><option value="OCC">Octoin Coin</option><option value="SKIN">SkinCoin</option><option value="ELTCOIN">ELTCOIN</option><option value="TDX">Tidex Token</option><option value="FRST">FirstCoin</option><option value="ACC*">Accelerator Network</option><option value="GPU">GPU Coin</option><option value="MRJA">GanjaCoin</option><option value="OCL">Oceanlab</option><option value="ARC">ArcticCoin</option><option value="CARBON">Carboncoin</option><option value="DEM">Deutsche eMark</option><option value="BYC">Bytecent</option><option value="MCAP">MCAP</option><option value="NMS">Numus</option><option value="LGD">Legends Room</option><option value="42">42-coin</option><option value="DFS">DFSCoin</option><option value="LOG">Woodcoin</option><option value="SNRG">Synergy</option><option value="MOIN">Moin</option><option value="VULC">Vulcano</option><option value="MRT">Miners' Reward Token</option><option value="VIVO">VIVO</option><option value="JEW">Shekel</option><option value="SKC">Skeincoin</option><option value="GCC*">Global Cryptocurrency</option><option value="ADZ">Adzcoin</option><option value="FUNK">The Cypherfunks</option><option value="GJC">Global Jobcoin</option><option value="MZC">MAZA</option><option value="CTR">Centra</option><option value="MEC">Megacoin</option><option value="ORE">Galactrum</option><option value="XPTX">PlatinumBAR</option><option value="DEUS">DeusCoin</option><option value="DFT">DraftCoin</option><option value="PCN">PeepCoin</option><option value="BRIT">BritCoin</option><option value="BTA">Bata</option><option value="UNIFY">Unify</option><option value="ZET">Zetacoin</option><option value="EPY">Emphy</option><option value="STU">bitJob</option><option value="DCY">Dinastycoin</option><option value="NETKO">Netko</option><option value="GUN">Guncoin</option><option value="MAGE">MagicCoin</option><option value="XLC">LeviarCoin</option><option value="NSR">NuShares</option><option value="FCN">Fantomcoin</option><option value="CRC*">CrowdCoin</option><option value="DRPU">DRP Utility</option><option value="FJC">FujiCoin</option><option value="ECASH">Ethereum Cash</option><option value="KLN">Kolion</option><option value="MBRS">Embers</option><option value="PROC">ProCurrency</option><option value="REC">Regalcoin</option><option value="BSM">Bitsum</option><option value="ICOO">ICO OpenLedger</option><option value="START">Startcoin</option><option value="EQL">Equal</option><option value="XPD">PetroDollar</option><option value="WILD">Wild Crypto</option><option value="QBIC">Qbic</option><option value="MBI">Monster Byte</option><option value="CCRB">CryptoCarbon</option><option value="HERO">Sovereign Hero</option><option value="ATS">Authorship</option><option value="IFLT">InflationCoin</option><option value="GRWI">Growers International</option><option value="BTWTY">Bit20</option><option value="MAC">Machinecoin</option><option value="HBN">HoboNickels</option><option value="SCT">Soma</option><option value="CCT">Crystal Clear </option><option value="ESC">Escroco</option><option value="IETH">iEthereum</option><option value="HPC">Happycoin</option><option value="SUR">Suretly</option><option value="CRM">Cream</option><option value="ACC">AdCoin</option><option value="JET">Jetcoin</option><option value="INSN">InsaneCoin</option><option value="ARCT">ArbitrageCT</option><option value="LCP">Litecoin Plus</option><option value="ITI">iTicoin</option><option value="PHO">Photon</option><option value="VOT">VoteCoin</option><option value="EBET">EthBet</option><option value="MNE">Minereum</option><option value="BTB">BitBar</option><option value="RBT">Rimbit</option><option value="FST">Fastcoin</option><option value="XCPO">Copico</option><option value="BTG*">Bitgem</option><option value="PXC">Phoenixcoin</option><option value="TTC">TittieCoin</option><option value="LANA">LanaCoin</option><option value="ARCO">AquariusCoin</option><option value="GRLC">Garlicoin</option><option value="WHL">WhaleCoin</option><option value="XCN">Cryptonite</option><option value="ERC20">ERC20</option><option value="BDL">Bitdeal</option><option value="KUSH">KushCoin</option><option value="VRS">Veros</option><option value="SCORE">Scorecoin</option><option value="DRXNE">DROXNE</option><option value="ITT">Intelligent Trading Foundation</option><option value="SGR">Sugar Exchange</option><option value="TOK">Tokugawa</option><option value="SDRN">Senderon</option><option value="MOJO">MojoCoin</option><option value="MAO">Mao Zedong</option><option value="VIDZ">PureVidz</option><option value="IRL">IrishCoin</option><option value="RLT">RouletteToken</option><option value="XBL">Billionaire Token</option><option value="PLC">PlusCoin</option><option value="ELE">Elementrem</option><option value="SLG">Sterlingcoin</option><option value="KBR">Kubera Coin</option><option value="SCS">Speedcash</option><option value="BITSILVER">bitSilver</option><option value="BLC">Blakecoin</option><option value="MANNA">Manna</option><option value="TRUMP">TrumpCoin</option><option value="TEK">TEKcoin</option><option value="DAXX">DaxxCoin</option><option value="PAK">Pakcoin</option><option value="BTCA">Bitair</option><option value="STN*">Steneum Coin</option><option value="CJ">Cryptojacks</option><option value="CTX">CarTaxi Token</option><option value="BTCRED">Bitcoin Red</option><option value="CAB">Cabbage</option><option value="MNM">Mineum</option><option value="GRN">Granite</option><option value="AERM">Aerium</option><option value="GOLF">Golfcoin</option><option value="GUESS">Peerguess</option><option value="SRC">SecureCoin</option><option value="OPC">OP Coin</option><option value="WGO">WavesGo</option><option value="POST">PostCoin</option><option value="BCF">Bitcoin Fast</option><option value="XCXT">CoinonatX</option><option value="DMB">Digital Money Bits</option><option value="ZCG">Zlancer</option><option value="ONX">Onix</option><option value="CNT">Centurion</option><option value="GAP">Gapcoin</option><option value="DIX">Dix Asset</option><option value="CESC">CryptoEscudo</option><option value="ETG">Ethereum Gold</option><option value="BITGOLD">bitGold</option><option value="HNC">Helleniccoin</option><option value="CCN">CannaCoin</option><option value="TOKC">TOKYO</option><option value="ATOM">Atomic Coin</option><option value="OTX">Octanox</option><option value="PASL">Pascal Lite</option><option value="BIGUP">BigUp</option><option value="PLC*">Polcoin</option><option value="LTB">LiteBar</option><option value="LEA">LeaCoin</option><option value="SHND">StrongHands</option><option value="IMX">Impact</option><option value="ABJ">Abjcoin</option><option value="NRO">Neuro</option><option value="300">300 Token</option><option value="NUKO">Nekonium</option><option value="CUBE">DigiCube</option><option value="BTPL">Bitcoin Planet</option><option value="RED">RedCoin</option><option value="PXI">Prime-XI</option><option value="ECO">EcoCoin</option><option value="SWING">Swing</option><option value="MCRN">MACRON</option><option value="C2">Coin2.1</option><option value="XRE">RevolverCoin</option><option value="SHDW">Shadow Token</option><option value="XCO">X-Coin</option><option value="NTO">Fujinto</option><option value="REE">ReeCoin</option><option value="BOST">BoostCoin</option><option value="LBTC">LiteBitcoin</option><option value="HVCO">High Voltage</option><option value="611">SixEleven</option><option value="ETHD">Ethereum Dark</option><option value="SFC">Solarflarecoin</option><option value="FUNC">FUNCoin</option><option value="TAJ">TajCoin</option><option value="VPRC">VapersCoin</option><option value="MAY">Theresa May Coin</option><option value="GTC*">Global Tour Coin</option><option value="HBC">HomeBlockCoin</option><option value="SOON">SoonCoin</option><option value="DSR">Desire</option><option value="TRDT">Trident Group</option><option value="BITEUR">bitEUR</option><option value="BRAT">BROTHER</option><option value="NEWB">Newbium</option><option value="EAGLE">EagleCoin</option><option value="COAL">BitCoal</option><option value="CMT*">Comet</option><option value="VUC">Virta Unique Coin</option><option value="XHI">HiCoin</option><option value="FLAX">Flaxscript</option><option value="CRX">Chronos</option><option value="PCOIN">Pioneer Coin</option><option value="ERY">Eryllium</option><option value="BIP">BipCoin</option><option value="GP">GoldPieces</option><option value="ITZ">Interzone</option><option value="KRONE">Kronecoin</option><option value="CNNC">Cannation</option><option value="ADCN">Asiadigicoin</option><option value="UET">Useless Ethereum Token</option><option value="QCN">QuazarCoin</option><option value="ZMC">ZetaMicron</option><option value="MSCN">Master Swiscoin</option><option value="LTCU">LiteCoin Ultra</option><option value="RKC">Royal Kingdom Coin</option><option value="LUNA">Luna Coin</option><option value="GBC">GBCGoldCoin</option><option value="SANDG">Save and Gain</option><option value="CRDNC">Credence Coin</option><option value="PRC">PRCoin</option><option value="ACP">AnarchistsPrime</option><option value="WOMEN">WomenCoin</option><option value="NANOX">Project-X</option><option value="COUPE">Coupecoin</option><option value="HMC*">HarmonyCoin</option><option value="PIZZA">PizzaCoin</option><option value="CALC">CaliphCoin</option><option value="GRE">Greencoin</option><option value="XTO">Tao</option><option value="HDG">Hedge</option><option value="MUSE">MUSE</option><option value="TGT">Target Coin</option><option value="ECOB">Ecobit</option><option value="RMC">Russian Miner Coin</option><option value="HBT">Hubii Network</option><option value="AC">AsiaCoin</option><option value="KLC">KiloCoin</option><option value="GOOD">Goodomy</option><option value="ECN">E-coin</option><option value="ETT">EncryptoTel [WAVES]</option><option value="VSL">vSlice</option><option value="IXC">Ixcoin</option><option value="STA">Starta</option><option value="REX">imbrex</option><option value="CBX">Bullion</option><option value="DAR">Darcrus</option><option value="TRIA">Triaconta</option><option value="NOTE">DNotes</option><option value="INPAY">InPay</option><option value="BLU">BlueCoin</option><option value="LEAF">LeafCoin</option><option value="FLIK">FLiK</option><option value="BBT">BitBoost</option><option value="WDC">WorldCoin</option><option value="FYP">FlypMe</option><option value="JC">Jesus Coin</option><option value="UNIC">UniCoin</option><option value="SHORTY">Shorty</option><option value="FLT">FlutterCoin</option><option value="V">Version</option><option value="UNI">Universe</option><option value="POP">PopularCoin</option><option value="I0C">I0Coin</option><option value="NDC">NEVERDIE</option><option value="FUCK">FuckToken</option><option value="ZENI">Zennies</option><option value="HTC">HitCoin</option><option value="SDC">ShadowCash</option><option value="CDX">Commodity Ad Network</option><option value="RNS">Renos</option><option value="STRC">StarCredits</option><option value="METAL">MetalCoin</option><option value="RIYA">Etheriya</option><option value="BPC">Bitpark Coin</option><option value="NET">NetCoin</option><option value="BXT">BitTokens</option><option value="PIGGY">Piggycoin</option><option value="DGC">Digitalcoin</option><option value="BRO">Bitradio</option><option value="BITS">Bitstar</option><option value="TRI">Triangles</option><option value="OPAL">Opal</option><option value="USC">Ultimate Secure Cash</option><option value="TROLL">Trollcoin</option><option value="Q2C">QubitCoin</option><option value="VTA">Virtacoin</option><option value="BLZ*">BlazeCoin</option><option value="BTCS">Bitcoin Scrypt</option><option value="HODL">HOdlcoin</option><option value="TIT">Titcoin</option><option value="BITBTC">bitBTC</option><option value="KURT">Kurrent</option><option value="GAIA">GAIA</option><option value="NYAN">Nyancoin</option><option value="TAG">TagCoin</option><option value="TALK">BTCtalkcoin</option><option value="ARI">Aricoin</option><option value="DSH">Dashcoin</option><option value="HAL">Halcyon</option><option value="MOTO">Motocoin</option><option value="EBCH">eBitcoinCash</option><option value="BUCKS">SwagBucks</option><option value="UTC">UltraCoin</option><option value="FLY">Flycoin</option><option value="SMC">SmartCoin</option><option value="TRK">Truckcoin</option><option value="XPY">PayCoin</option><option value="RPC">RonPaulCoin</option><option value="NXX">Nexxus</option><option value="ISL">IslaCoin</option><option value="SUPER">SuperCoin</option><option value="XJO">Joulecoin</option><option value="GB">GoldBlocks</option><option value="PR">Prototanium</option><option value="CASH">Cashcoin</option><option value="EVIL">Evil Coin</option><option value="8BIT">8Bit</option><option value="BLOCKPAY">BlockPay</option><option value="MAD*">SatoshiMadness</option><option value="BOLI">Bolivarcoin</option><option value="TSE">Tattoocoin (Standard Edition)</option><option value="DDF">DigitalDevelopersFund</option><option value="TKR">CryptoInsight</option><option value="PHS">Philosopher Stones</option><option value="VISIO">Visio</option><option value="TGC">Tigercoin</option><option value="CHESS">ChessCoin</option><option value="AMBER">AmberCoin</option><option value="ENT">Eternity</option><option value="CNO">Coin(O)</option><option value="BITZ">Bitz</option><option value="CYP">Cypher</option><option value="FRC">Freicoin</option><option value="XRA">Ratecoin</option><option value="GRIM">Grimcoin</option><option value="XCT">C-Bit</option><option value="EMD">Emerald Crypto</option><option value="MARS">Marscoin</option><option value="ICN*">iCoin</option><option value="NEVA">NevaCoin</option><option value="SPEX">SproutsExtreme</option><option value="INFX">Influxcoin</option><option value="CHAN">ChanCoin</option><option value="AMMO">Ammo Reloaded</option><option value="PX">PX</option><option value="BTCR">Bitcurrency</option><option value="SPACE">SpaceCoin</option><option value="BERN">BERNcash</option><option value="888">OctoCoin</option><option value="DTC">Datacoin</option><option value="QBC">Quebecoin</option><option value="KED">Darsek</option><option value="CTO">Crypto</option><option value="LCT">LendConnect</option><option value="SIGT">Signatum</option><option value="XIOS">Xios</option><option value="GLT">GlobalToken</option><option value="UNITS">GameUnits</option><option value="B@">Bankcoin</option><option value="RBIES">Rubies</option><option value="IMS">Independent Money System</option><option value="VC">VirtualCoin</option><option value="GLC">GlobalCoin</option><option value="ZUR">Zurcoin</option><option value="FNC">FinCoin</option><option value="AMS">AmsterdamCoin</option><option value="QTL">Quatloo</option><option value="PNX">Phantomx</option><option value="CAT**">Catcoin</option><option value="CCO">Ccore</option><option value="DUO">ParallelCoin</option><option value="MST">MustangCoin</option><option value="PKB">ParkByte</option><option value="BSTY">GlobalBoost-Y</option><option value="FIRE">Firecoin</option><option value="STV">Sativacoin</option><option value="YAC">Yacoin</option><option value="BUMBA">BumbaCoin</option><option value="AIB">Advanced Internet Blocks</option><option value="JIN">Jin Coin</option><option value="HONEY">Honey</option><option value="SCRT">SecretCoin</option><option value="XVP">Virtacoinplus</option><option value="DRS">Digital Rupees</option><option value="EVO">Evotion</option><option value="ELC">Elacoin</option><option value="ICOB">ICOBID</option><option value="EL">Elcoin</option><option value="CON">PayCon</option><option value="XBTS">Beatcoin</option><option value="GCC">GuccioneCoin</option><option value="XNG">Enigma</option><option value="HMP">HempCoin</option><option value="XBTC21">Bitcoin 21</option><option value="DLC">Dollarcoin</option><option value="BRIA">BriaCoin</option><option value="$$$">Money</option><option value="BTQ">BitQuark</option><option value="YTN">YENTEN</option><option value="XCRE">Creatio</option><option value="DALC">Dalecoin</option><option value="EUC">Eurocoin</option><option value="ACOIN">Acoin</option><option value="FUZZ">FuzzBalls</option><option value="GLS">GlassCoin</option><option value="CACH">CacheCoin</option><option value="MNC">Mincoin</option><option value="SOIL">SOILcoin</option><option value="BLN">Bolenum</option><option value="BENJI">BenjiRolls</option><option value="NTWK">Network Token</option><option value="MDC">Madcoin</option><option value="AGLC">AgrolifeCoin</option><option value="BLRY">BillaryCoin</option><option value="J">Joincoin</option><option value="CPN">CompuCoin</option><option value="STARS">StarCash Network</option><option value="CXT">Coinonat</option><option value="DBTC">Debitcoin</option><option value="ALL*">Allion</option><option value="ROOFS">Roofs</option><option value="ASAFE2">AllSafe</option><option value="CF">Californium</option><option value="BAS">BitAsean</option><option value="MAR">Marijuanacoin</option><option value="RIDE">Ride My Car</option><option value="MTLMC3">Metal Music Coin</option><option value="GPL">Gold Pressed Latinum</option><option value="SONG">SongCoin</option><option value="ZZC">ZoZoCoin</option><option value="WARP">WARP</option><option value="SH">Shilling</option><option value="BNX">BnrtxCoin</option><option value="MND">MindCoin</option><option value="RBX">Ripto Bux</option><option value="BXC">Bitcedi</option><option value="BSTAR">Blackstar</option><option value="ZYD">Zayedcoin</option><option value="URO">Uro</option><option value="PRX">Printerium</option><option value="VIP">VIP Tokens</option><option value="ATX">Artex Coin</option><option value="WORM">HealthyWormCoin</option><option value="KNC*">KingN Coin</option><option value="JWL">Jewels</option><option value="SLEVIN">Slevin</option><option value="POS">PoSToken</option><option value="DRM">Dreamcoin</option><option value="MILO">MiloCoin</option><option value="ICON">Iconic</option><option value="PONZI">PonziCoin</option><option value="DLISK">DAPPSTER</option><option value="EXN">ExchangeN</option><option value="PIE">PIECoin</option><option value="BSC">BowsCoin</option><option value="LTCR">Litecred</option><option value="GEERT">GeertCoin</option><option value="VLT">Veltor</option><option value="BIOS">BiosCrypto</option><option value="PULSE">Pulse</option><option value="STEPS">Steps</option><option value="LIR">LetItRide</option><option value="ARB">ARbit</option><option value="IMPS">ImpulseCoin</option><option value="BOAT">BOAT</option><option value="ZNE">Zonecoin</option><option value="JS">JavaScript Token</option><option value="PLACO">PlayerCoin</option><option value="VEC2">VectorAI</option><option value="WBB">Wild Beast Block</option><option value="CWXT">CryptoWorldX Token</option><option value="OFF">Cthulhu Offerings</option><option value="SDP">SydPak</option><option value="DES">Destiny</option><option value="RSGP">RSGPcoin</option><option value="TAGR">TAGRcoin</option><option value="OS76">OsmiumCoin</option><option value="PLNC">PLNcoin</option><option value="TOR">Torcoin</option><option value="VOLT">Bitvolt</option><option value="PEX">PosEx</option><option value="JOBS">JobsCoin</option><option value="ARGUS">Argus</option><option value="DOLLAR">Dollar Online</option><option value="CTIC3">Coimatic 3.0</option><option value="XRC">Rawcoin</option><option value="P7C">P7Coin</option><option value="BIOB">BioBar</option><option value="IBANK">iBank</option><option value="CREVA">CrevaCoin</option><option value="ELS">Elysium</option><option value="SOCC">SocialCoin</option><option value="CONX">Concoin</option><option value="SLFI">Selfiecoin</option><option value="NODC">NodeCoin</option><option value="MGM">Magnum</option><option value="GSR">GeyserCoin</option><option value="CTIC2">Coimatic 2.0</option><option value="ULA">Ulatech</option><option value="VLTC">Vault Coin</option><option value="LVPS">LevoPlus</option><option value="TSTR">Tristar Coin</option><option value="FXE">FuturXe</option><option value="DGCS">Digital Credits</option><option value="EBT">Ebittree Coin</option><option value="AI">POLY AI</option><option value="CKUSD">CK USD</option><option value="OC">OceanChain</option><option value="WIC*">WaykiChain</option><option value="XMC">Monero Classic</option><option value="MOAC">MOAC</option><option value="IQT">iQuant</option><option value="SBTC">Super Bitcoin</option><option value="KCASH">Kcash</option><option value="CAN*">Content and AD Network</option><option value="STC">StarChain</option><option value="NOAH">Noah Coin</option><option value="MEET">CoinMeet</option><option value="EPC">Electronic PK Chain</option><option value="BCX">BitcoinX</option><option value="CHAT">ChatCoin</option><option value="AAC">Acute Angle Cloud</option><option value="ATMC">ATMCoin</option><option value="DRG">Dragon Coins</option><option value="MOF">Molecular Future</option><option value="XMO">Monero Original</option><option value="SHOW">Show</option><option value="FAIR*">FairGame</option><option value="CMS">COMSA [ETH]</option><option value="RCT">RealChain</option><option value="BFT">BnkToTheFuture</option><option value="BSTN">BitStation</option><option value="GEM">Gems </option><option value="TOPC">TopChain</option><option value="FIL">Filecoin [Futures]</option><option value="OF">OFCOIN</option><option value="UBTC">United Bitcoin</option><option value="LIGHT">LightChain</option><option value="AWR">AWARE</option><option value="KST">StarCoin</option><option value="XUC">Exchange Union</option><option value="NTK">Neurotoken</option><option value="VLC">ValueChain</option><option value="CMS*">COMSA [XEM]</option><option value="FRGC">Fargocoin</option><option value="XTZ">Tezos (Pre-Launch)</option><option value="MAG*">Maggie</option><option value="SSC">SelfSell</option><option value="BCDN">BlockCDN</option><option value="LBTC*">Lightning Bitcoin [Futures]</option><option value="WETH">WETH</option><option value="SCC">StockChain</option><option value="HLC">HalalChain</option><option value="IPC">IPChain</option><option value="ATC">Arbitracoin</option><option value="AMLT">AMLT Token</option><option value="FID">Fidelium</option><option value="EARTH">Earth Token</option><option value="PRS">PressOne</option><option value="EOSDAC">eosDAC</option><option value="QUBE">Qube</option><option value="BIG">BigONE Token</option><option value="DIG">Dignity</option><option value="MRK">MARK.SPACE</option><option value="UIP">UnlimitedIP</option><option value="ADK">Aidos Kuneen</option><option value="ADI">Aditus</option><option value="CFUN">CFun</option><option value="AVH">Animation Vision Cash</option><option value="READ">Read</option><option value="BBI">BelugaPay</option><option value="WC">WINCOIN</option><option value="XIN*">Infinity Economics</option><option value="CVH">Curriculum Vitae</option><option value="SBC">StrikeBitClub</option><option value="BRM">BrahmaOS</option><option value="TDS">TokenDesk</option><option value="CHX">Chainium</option><option value="CROP">Cropcoin</option><option value="XTL">Stellite</option><option value="XOT">Internet of Things</option><option value="SEN">Consensus</option><option value="CANDY">Candy</option><option value="IDT">InvestDigital</option><option value="GCS">GameChain System</option><option value="XID">Sphre AIR </option><option value="ECH">Etherecash</option><option value="BT2">BT2 [CST]</option><option value="SWTC">Jingtum Tech</option><option value="HPY">Hyper Pay</option><option value="GBG">Golos Gold</option><option value="DERO">Dero</option><option value="WIN">WCOIN</option><option value="GOD">Bitcoin God</option><option value="ANI">Animecoin</option><option value="B2X">SegWit2x</option><option value="SNIP">SnipCoin</option><option value="MLM">MktCoin</option><option value="BUBO">Budbo</option><option value="BELA">Bela</option><option value="SIC">Swisscoin</option><option value="ABC">Alphabit</option><option value="PCS">Pabyosi Coin (Special)</option><option value="BSR">BitSoar</option><option value="MSD">MSD</option><option value="XSTC">Safe Trade Coin</option><option value="FDZ">Friendz</option><option value="APC">AlpaCoin</option><option value="IFC">Infinitecoin</option><option value="GRMD">GreenMed</option><option value="EMB">EmberCoin</option><option value="PHI">PHI Token</option><option value="PCL">Peculium</option><option value="ACC**">ACChain</option><option value="MFG">SyncFab</option><option value="LST">Lendroid Support Token</option><option value="BAR">Titanium Blockchain</option><option value="W3C">W3Coin</option><option value="ENT*">ENTCash</option><option value="XID*">International Diamond</option><option value="CLUB">ClubCoin</option><option value="DUTCH">Dutch Coin</option><option value="CEFS">CryptopiaFeeShares</option><option value="OX">OX Fina</option><option value="SPK">Sparks</option><option value="EDRC">EDRCoin</option><option value="WA">WA Space</option><option value="NOX">Nitro</option><option value="HDLB">HODL Bucks</option><option value="UTT">United Traders Token</option><option value="EDT">EtherDelta Token</option><option value="CLD">Cloud</option><option value="MCR">Macro</option><option value="SLOTH">Slothcoin</option><option value="COR">CORION</option><option value="MARX">MarxCoin</option><option value="PRES">President Trump</option><option value="RBBT">RabbitCoin</option><option value="NAMO">NamoCoin</option><option value="MCI">Musiconomi</option><option value="ERA">ERA</option><option value="SONO">SONO</option><option value="HIGH">High Gain</option><option value="XRY">Royalties</option><option value="BET">BetaCoin</option><option value="SIGMA">SIGMAcoin</option><option value="HC">Harvest Masternode Coin</option><option value="INDI">Indicoin</option><option value="ZBC">Zilbercoin</option><option value="TLE">Tattoocoin (Limited Edition)</option><option value="EAG">EA Coin</option><option value="ZENGOLD">ZenGold</option><option value="TESLA">TeslaCoilCoin</option><option value="FUTC">FutCoin</option><option value="FRN">Francs</option><option value="BTCM">BTCMoon</option><option value="ROYAL">RoyalCoin</option><option value="NUMUS">NumusCash</option><option value="DON">Donationcoin</option><option value="PRN">Protean</option><option value="TER">TerraNova</option><option value="RYZ">ANRYZE</option><option value="LDCN">LandCoin</option><option value="SJW">SJWCoin</option><option value="GDC">GrandCoin</option><option value="CYDER">Cyder</option><option value="MBL">MobileCash</option><option value="BITCF">First Bitcoin Capital</option><option value="GAIN">UGAIN</option><option value="DAV">DavorCoin</option><option value="PLX">PlexCoin</option><option value="ELITE">Ethereum Lite</option><option value="CHEAP">Cheapcoin</option><option value="UNRC">UniversalRoyalCoin</option><option value="SJCX">Storjcoin X</option><option value="SKR">Sakuracoin</option><option value="HYPER">Hyper</option><option value="AV">AvatarCoin</option><option value="TURBO">TurboCoin</option><option value="TOPAZ">Topaz Coin</option><option value="ETT*">EncryptoTel [ETH]</option><option value="BLAZR">BlazerCoin</option><option value="TELL">Tellurion</option><option value="TCOIN">T-coin</option><option value="DMC">DynamicCoin</option><option value="WINK">Wink</option><option value="QBT">Cubits</option><option value="BIT">First Bitcoin</option><option value="MINEX">Minex</option><option value="GAY">GAY Money</option><option value="CME">Cashme</option><option value="HNC*">Huncoin</option><option value="GRX">GOLD Reward Token</option><option value="BTE">BitSerial</option><option value="BUB">Bubble</option><option value="SHA">SHACoin</option><option value="BEST">BestChain</option><option value="GMX">GoldMaxCoin</option><option value="POKE">PokeCoin</option><option value="SUP">Superior Coin</option><option value="XTD">XTD Coin</option><option value="HALLO">Halloween Coin</option><option value="RUNNERS">Runners</option><option value="ANTX">Antimatter</option><option value="KDC">KlondikeCoin</option><option value="WIC">Wi Coin</option><option value="LEVO">Levocoin</option><option value="UNITY">SuperNET</option><option value="SMOKE">Smoke</option><option value="UNC">UNCoin</option><option value="PRIMU">Primulon</option><option value="NEOG">NEO GOLD</option><option value="CFC">CoffeeCoin</option><option value="RICHX">RichCoin</option><option value="BAT*">BatCoin</option><option value="OP">Operand</option><option value="GARY">President Johnson</option><option value="RHFC">RHFCoin</option><option value="MAGN">Magnetcoin</option><option value="INDIA">India Coin</option><option value="UR">UR</option><option value="WSX">WeAreSatoshi</option><option value="AKY">Akuya Coin</option><option value="ZSE">ZSEcoin</option><option value="BTBc">Bitbase</option><option value="KARMA">Karmacoin</option><option value="XQN">Quotient</option><option value="TODAY">TodayCoin</option><option value="AXIOM">Axiom</option><option value="RCN*">Rcoin</option><option value="STEX">STEX</option><option value="CC">CyberCoin</option><option value="BSN">Bastonet</option><option value="NBIT">netBit</option><option value="ACES">Aces</option><option value="RUBIT">RubleBit</option><option value="DASHS">Dashs</option><option value="FONZ">Fonziecoin</option><option value="DBG">Digital Bullion Gold</option><option value="LEPEN">LePen</option><option value="SKULL">Pirate Blocks</option><option value="SISA">SISA</option><option value="LKC">LinkedCoin</option><option value="MONETA">Moneta</option><option value="SAK">Sharkcoin</option><option value="PSY">Psilocybin</option><option value="FAP">FAPcoin</option><option value="FAZZ">Fazzcoin</option><option value="REGA">Regacoin</option><option value="CYC">Cycling Coin</option><option value="DCRE">DeltaCredits</option><option value="SPORT">SportsCoin</option><option value="TRICK">TrickyCoin</option><option value="X2">X2</option><option value="SHELL">ShellCoin</option><option value="OPES">Opescoin</option><option value="PAYP">PayPeer</option><option value="HCC">Happy Creator Coin</option><option value="FRWC">FrankyWillCoin</option><option value="KASHH">KashhCoin</option><option value="BITOK">Bitok</option><option value="TCR">TheCreed</option><option value="DISK">DarkLisk</option><option value="OMC">Omicron</option><option value="EGG">EggCoin</option><option value="LAZ">Lazaruscoin</option><option value="GML">GameLeagueCoin</option><option value="PRM">PrismChain</option><option value="BIRDS">Birds</option><option value="THS">TechShares</option><option value="ACN">Avoncoin</option><option value="QORA">Qora</option><option value="TOP*">TopCoin</option><option value="CRYPT">CryptCoin</option><option value="ASN">Aseancoin</option><option value="EREAL">eREAL</option><option value="XVC">Vcash</option><option value="UGT">UG Token</option><option value="FRCT">Farstcoin</option></select>            </div>
        </div>

    </nav>

<div class="pusher">

    <div id="stats" class="ui basic segment">
        <div class="ui mini statistics">
            <div class="yellow statistic">
                <div class="value">1587</div>
                <div class="label">Total Cryptocurrencies</div>
            </div>
            <div class="yellow statistic">
                <div class="value">10,409</div>
                <div class="label">Markets</div>
            </div>
            <div class="yellow statistic">
                <div class="value">407,510,746,675</div>
                <div class="label">Total Market Cap</div>
            </div>
            <div class="yellow statistic">
                <div class="value">26,365,761,598</div>
                <div class="label">Volume 24H</div>
            </div>
            <div class="yellow statistic">
                <div class="value">37.7 %</div>
                <div class="label">Bitcoin Dominance</div>
            </div>
        </div>
    </div>


    <main id="content">

        <div class="ui container">

    
    <div class="ui basic  segment">
        <h1 class="ui centered header">
            ICOs            <div class="sub header">ICOs List</div>
        </h1>
    </div>

    

    <div class="ui stackable secondary menu">
        <a href="icos/finished.php" class="item  button">
            <i class="hourglass end icon"></i>
            Finished        </a>
        <a href="icos/live.php" class="item active button">
            <i class="clock icon"></i>
            Live        </a>
        <a href="icos/upcoming.php" class="item  button">
            <i class="calendar plus outline icon"></i>
            Upcoming        </a>
    </div>

    <table id="icos-list" class="ui basic fluid table">
        <tbody>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/shivom" class="ui small image">
                        <img src="../icowatchlist.com/logos/shivom.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/shivom">Shivom</a>
                    </h3>
                    The Global BlockchainGenomics Ecosystem Powering the Next Era of Precision Medicine                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/shivom" class="ui green button">
                            16/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/shivom" class="ui red button">
                            27/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dapcash" class="ui small image">
                        <img src="../icowatchlist.com/logos/dapcash.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dapcash">DapCash</a>
                    </h3>
                    First postquantum crypto currency with multiple blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dapcash" class="ui green button">
                            20/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dapcash" class="ui red button">
                            27/04/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/astorgame" class="ui small image">
                        <img src="../icowatchlist.com/logos/astorgame.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/astorgame">AstorGame</a>
                    </h3>
                    eSport  Online Gaming platform  Decentralized games Sports Betting and Casino using blockchain smart contracts  Provably Fair                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/astorgame" class="ui green button">
                            29/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/astorgame" class="ui red button">
                            29/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blocside-sports" class="ui small image">
                        <img src="../icowatchlist.com/logos/blocside-sports.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blocside-sports">BlocSide Sports</a>
                    </h3>
                    Innovating Optimizing  Reimagining the Fan Experience with the infusion of Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blocside-sports" class="ui green button">
                            29/03/2018 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blocside-sports" class="ui red button">
                            29/04/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/streamity" class="ui small image">
                        <img src="../icowatchlist.com/logos/streamity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/streamity">Streamity</a>
                    </h3>
                    The key element of STREAMITY is StreamDesk decentralized application for exchange of cryptocurrency to fiat                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/streamity" class="ui green button">
                            16/04/2018 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/streamity" class="ui red button">
                            29/04/2018 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/connectjob" class="ui small image">
                        <img src="../icowatchlist.com/logos/connectjob.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/connectjob">Connectjob</a>
                    </h3>
                    ConnectJob ultimately connects jobs to people and people to jobs using the power of blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/connectjob" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/connectjob" class="ui red button">
                            30/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/galaxis" class="ui small image">
                        <img src="../icowatchlist.com/logos/galaxis.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxis">Galaxis</a>
                    </h3>
                    A platform with optional private  smart contracts and feeless transactions                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxis" class="ui green button">
                            01/03/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxis" class="ui red button">
                            30/04/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/realcasino" class="ui small image">
                        <img src="../icowatchlist.com/logos/realcasino.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/realcasino">RealCasino</a>
                    </h3>
                    RealCasino is a decentralized distributed casino gaming platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/realcasino" class="ui green button">
                            10/02/2018 06:34                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/realcasino" class="ui red button">
                            30/04/2018 06:34                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/corl" class="ui small image">
                        <img src="../icowatchlist.com/logos/corl.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/corl">Corl</a>
                    </h3>
                    Revenue sharing on the blockchain A regular stream of quarterly profit payments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/corl" class="ui green button">
                            01/04/2018 06:56                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/corl" class="ui red button">
                            30/04/2018 06:56                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/etheera" class="ui small image">
                        <img src="../icowatchlist.com/logos/etheera.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/etheera">Etheera</a>
                    </h3>
                    The Future of Real Estate with decentralized Portal  All in One Software Solution for the Agents                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/etheera" class="ui green button">
                            10/02/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/etheera" class="ui red button">
                            30/04/2018 09:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/florafic" class="ui small image">
                        <img src="../icowatchlist.com/logos/florafic.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/florafic">FloraFIC</a>
                    </h3>
                    Applied technology of AI and blockchain to work together via the smart FIC application                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/florafic" class="ui green button">
                            08/03/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/florafic" class="ui red button">
                            30/04/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/essentia" class="ui small image">
                        <img src="../icowatchlist.com/logos/essentia.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/essentia">Essentia</a>
                    </h3>
                    Essentia is the interoperations and data management framework forged by a whole new set of protocols                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/essentia" class="ui green button">
                            15/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/essentia" class="ui red button">
                            30/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/robotina" class="ui small image">
                        <img src="../icowatchlist.com/logos/robotina.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/robotina">Robotina</a>
                    </h3>
                    Internet Of Things Artificial Intelligence  Blockchain empowering energy consumers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/robotina" class="ui green button">
                            21/03/2018 14:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/robotina" class="ui red button">
                            30/04/2018 13:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fox-trading" class="ui small image">
                        <img src="../icowatchlist.com/logos/fox-trading.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fox-trading">Fox Trading</a>
                    </h3>
                    Exclusive Trading Service for Forex and Cryptocurrencies for maximized earnings                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fox-trading" class="ui green button">
                            10/03/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fox-trading" class="ui red button">
                            30/04/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptelo" class="ui small image">
                        <img src="../icowatchlist.com/logos/cryptelo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptelo">Cryptelo</a>
                    </h3>
                    Platform for encrypted data sharing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptelo" class="ui green button">
                            15/03/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptelo" class="ui red button">
                            30/04/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cartel-chain" class="ui small image">
                        <img src="../icowatchlist.com/logos/cartel-chain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cartel-chain">Cartel Chain</a>
                    </h3>
                    A seamless ecommerce continuum Eliminating middle men reducing global carbon emissions and more                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cartel-chain" class="ui green button">
                            10/03/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cartel-chain" class="ui red button">
                            30/04/2018 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/medichainonline" class="ui small image">
                        <img src="../icowatchlist.com/logos/medichainonline.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/medichainonline">MediChain.Online</a>
                    </h3>
                    MediChain will bring better health to patients with the help of blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/medichainonline" class="ui green button">
                            01/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/medichainonline" class="ui red button">
                            30/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/thinkcoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/thinkcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/thinkcoin">ThinkCoin</a>
                    </h3>
                    ThinkCoin is a Multi Asset Trading which leverages blockhain technology to ensure that investors get optimal returns                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/thinkcoin" class="ui green button">
                            17/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/thinkcoin" class="ui red button">
                            30/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/trueplay" class="ui small image">
                        <img src="../icowatchlist.com/logos/trueplay.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/trueplay">TruePlay</a>
                    </h3>
                    Fully functioning platform created for integration of blockchain tech into online gambling projects                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/trueplay" class="ui green button">
                            14/04/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/trueplay" class="ui red button">
                            30/04/2018 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/all-stocks-network" class="ui small image">
                        <img src="../icowatchlist.com/logos/all-stocks-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/all-stocks-network">All-Stocks Network</a>
                    </h3>
                    The ALLSTOCKS Network is a distributed global stock exchange platform which aims to interface with all major stock exchanges and stock brokers around the world                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/all-stocks-network" class="ui green button">
                            14/04/2018 22:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/all-stocks-network" class="ui red button">
                            30/04/2018 21:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/zufloio" class="ui small image">
                        <img src="../icowatchlist.com/logos/zufloio.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/zufloio">Zuflo.IO</a>
                    </h3>
                    Trading and Finance all on one platform It is a onestopshop for cryptocurrency and cryptoasset trading                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/zufloio" class="ui green button">
                            21/02/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/zufloio" class="ui red button">
                            30/04/2018 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/delphi-technologies-token" class="ui small image">
                        <img src="../icowatchlist.com/logos/delphi-technologies-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/delphi-technologies-token">Delphi Technologies Token.</a>
                    </h3>
                    Smart wallet  Currency for Delphi Intelligent carsThis is a token used in Delphi intelligent  driverless cars for use by car                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/delphi-technologies-token" class="ui green button">
                            13/04/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/delphi-technologies-token" class="ui red button">
                            30/04/2018 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wiix" class="ui small image">
                        <img src="../icowatchlist.com/logos/wiix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wiix">WIIX</a>
                    </h3>
                    Innovations Global Opportunites and a new World with Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wiix" class="ui green button">
                            01/04/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wiix" class="ui red button">
                            01/05/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/etherty" class="ui small image">
                        <img src="../icowatchlist.com/logos/etherty.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/etherty">Etherty</a>
                    </h3>
                    Platform that utilizes blockchain technology to provide a onestop solution for the purchase sale and crowdsale of real estate globally                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/etherty" class="ui green button">
                            15/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/etherty" class="ui red button">
                            30/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ipstock" class="ui small image">
                        <img src="../icowatchlist.com/logos/ipstock.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ipstock">IPStock</a>
                    </h3>
                    IPStock implements visual digital content registry on blockchain and license management through smartcontracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ipstock" class="ui green button">
                            31/03/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ipstock" class="ui red button">
                            30/04/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/elementh" class="ui small image">
                        <img src="../icowatchlist.com/logos/elementh.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/elementh">Elementh</a>
                    </h3>
                    Elementh is a blockchain designed for the ecommerce market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/elementh" class="ui green button">
                            01/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/elementh" class="ui red button">
                            01/05/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/decentralized-news-network" class="ui small image">
                        <img src="../icowatchlist.com/logos/decentralized-news-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralized-news-network">Decentralized News Network</a>
                    </h3>
                    DNN is a Political News Platform Fighting Fake News and Combating Censorship                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralized-news-network" class="ui green button">
                            03/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralized-news-network" class="ui red button">
                            01/05/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/adamant-messenger" class="ui small image">
                        <img src="../icowatchlist.com/logos/adamant-messenger.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/adamant-messenger">ADAMANT Messenger</a>
                    </h3>
                    The most secure and anonymous messenger encrypted with Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/adamant-messenger" class="ui green button">
                            30/01/2018 03:18                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/adamant-messenger" class="ui red button">
                            01/05/2018 03:19                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kerberos-coin" class="ui small image">
                        <img src="../icowatchlist.com/logos/kerberos-coin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kerberos-coin">Kerberos Coin</a>
                    </h3>
                    Altcoin Mining Operation Using Smart Contracts  Based On the Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kerberos-coin" class="ui green button">
                            01/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kerberos-coin" class="ui red button">
                            01/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/moneytoken" class="ui small image">
                        <img src="../icowatchlist.com/logos/moneytoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytoken">MoneyToken</a>
                    </h3>
                    MoneyToken provides cryptobacked loans stablecoin MTC and a decentralized exchange service                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytoken" class="ui green button">
                            22/03/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytoken" class="ui red button">
                            01/05/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/airchain-network" class="ui small image">
                        <img src="../icowatchlist.com/logos/airchain-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/airchain-network">Airchain Network</a>
                    </h3>
                    Airchain is the next revolution in Freight Industry for unrivaled transparency and efficiency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/airchain-network" class="ui green button">
                            23/04/2018 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/airchain-network" class="ui red button">
                            01/05/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/pr-network" class="ui small image">
                        <img src="../icowatchlist.com/logos/pr-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/pr-network">PR Network</a>
                    </h3>
                    PRnetwork is an incentivebased voting protocol designed to decentralized the reputation and value of everything                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/pr-network" class="ui green button">
                            20/04/2018 12:12                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/pr-network" class="ui red button">
                            02/05/2018 12:12                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/paymon" class="ui small image">
                        <img src="../icowatchlist.com/logos/paymon.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/paymon">Paymon</a>
                    </h3>
                    Paymon is a blockchain platform that connect all market participants through new scalable blockchain  Hive                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/paymon" class="ui green button">
                            30/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/paymon" class="ui red button">
                            03/05/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ceek" class="ui small image">
                        <img src="../icowatchlist.com/logos/ceek.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ceek">CEEK</a>
                    </h3>
                    Virtual Reality platform for streamed live events and productions making use of Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ceek" class="ui green button">
                            16/04/2018 05:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ceek" class="ui red button">
                            04/05/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/globatalent" class="ui small image">
                        <img src="../icowatchlist.com/logos/globatalent.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/globatalent">Globatalent</a>
                    </h3>
                    The sports marketplace where you can invest in your worldwide idols                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/globatalent" class="ui green button">
                            15/04/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/globatalent" class="ui red button">
                            06/05/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryde" class="ui small image">
                        <img src="../icowatchlist.com/logos/cryde.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryde">CRYDE</a>
                    </h3>
                    A blockchain based car raffle platform with profit dividend paid out to token holders                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryde" class="ui green button">
                            23/04/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryde" class="ui red button">
                            07/05/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nickelcoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/nickelcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nickelcoin">Nickelcoin</a>
                    </h3>
                    Deploying Blockchain tehnology to Customers Loyalty Rewards                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nickelcoin" class="ui green button">
                            26/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nickelcoin" class="ui red button">
                            07/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mydfs" class="ui small image">
                        <img src="../icowatchlist.com/logos/mydfs.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mydfs">MyDFS</a>
                    </h3>
                    Blockchainpowered daily fantasy sports which brings more efficiency for optimal user experience                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mydfs" class="ui green button">
                            16/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mydfs" class="ui red button">
                            07/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eligma" class="ui small image">
                        <img src="../icowatchlist.com/logos/eligma.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eligma">ELIGMA</a>
                    </h3>
                    AIdriven and blockchainbased cognitive commerce platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eligma" class="ui green button">
                            17/04/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eligma" class="ui red button">
                            08/05/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/patron" class="ui small image">
                        <img src="../icowatchlist.com/logos/patron.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/patron">PATRON</a>
                    </h3>
                    PATRON is a one stop shop for social media influencers worldwide whiles using blockchain technology and cryptocurrency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/patron" class="ui green button">
                            27/03/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/patron" class="ui red button">
                            09/05/2018 08:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nexusless" class="ui small image">
                        <img src="../icowatchlist.com/logos/nexusless.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nexusless">Nexusless</a>
                    </h3>
                    Peertopeer content delivery network where anyone can monetize the unused capacity of their computers and smartphones                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nexusless" class="ui green button">
                            18/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nexusless" class="ui red button">
                            09/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ligercoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/ligercoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ligercoin">Ligercoin</a>
                    </h3>
                    LIGER is here with best processes swifter transactions and smartest thinking Its advanced features of safety and anonymity are ready to win hearts and games                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ligercoin" class="ui green button">
                            18/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ligercoin" class="ui red button">
                            10/05/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mandala" class="ui small image">
                        <img src="../icowatchlist.com/logos/mandala.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mandala">Mandala</a>
                    </h3>
                    A revolutionary digital asset exchange which is simple secure and sustainable                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mandala" class="ui green button">
                            21/04/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mandala" class="ui red button">
                            11/05/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitguild" class="ui small image">
                        <img src="../icowatchlist.com/logos/bitguild.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitguild">BitGuild</a>
                    </h3>
                    BitGuild will disrupt the gaming industry by creating a platform for games that live on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitguild" class="ui green button">
                            11/04/2018 20:11                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitguild" class="ui red button">
                            11/05/2018 20:11                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lunes-platform" class="ui small image">
                        <img src="../icowatchlist.com/logos/lunes-platform.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lunes-platform">Lunes Platform</a>
                    </h3>
                    Lunes is a platform which provides a set of decentralized solutions through blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lunes-platform" class="ui green button">
                            15/04/2018 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lunes-platform" class="ui red button">
                            15/05/2018 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/arcona" class="ui small image">
                        <img src="../icowatchlist.com/logos/arcona.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/arcona">Arcona</a>
                    </h3>
                    Blockchain powered augmented reality ecosystem merging real and virtual worlds worldwide creating augmented reality layer  the Digital Land                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/arcona" class="ui green button">
                            14/04/2018 22:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/arcona" class="ui red button">
                            14/05/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/well" class="ui small image">
                        <img src="../icowatchlist.com/logos/well.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/well">WELL</a>
                    </h3>
                    Healthcare Delivered WELL                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/well" class="ui green button">
                            16/04/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/well" class="ui red button">
                            15/05/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/odyfund" class="ui small image">
                        <img src="../icowatchlist.com/logos/odyfund.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/odyfund">Odyfund</a>
                    </h3>
                    Fundraising platform linked to a humanitarian crypto emergency fund                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/odyfund" class="ui green button">
                            15/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/odyfund" class="ui red button">
                            15/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ficnetwork" class="ui small image">
                        <img src="../icowatchlist.com/logos/ficnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ficnetwork">FIC Network</a>
                    </h3>
                    Earn and Pay Interest on Your Crypto Assets Fixed Income Infrastructure on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ficnetwork" class="ui green button">
                            18/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ficnetwork" class="ui red button">
                            15/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/emarketchain" class="ui small image">
                        <img src="../icowatchlist.com/logos/emarketchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/emarketchain">eMarketChain</a>
                    </h3>
                    The blockchainpowered ecommerce platform with 0 commissions on every purchase                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/emarketchain" class="ui green button">
                            15/04/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/emarketchain" class="ui red button">
                            15/05/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cargocoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/cargocoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cargocoin">CargoCoin</a>
                    </h3>
                    Revolutionaising Global Trade and Transport through Decentralisation with a focus on the shipping industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cargocoin" class="ui green button">
                            16/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cargocoin" class="ui red button">
                            15/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/beat" class="ui small image">
                        <img src="../icowatchlist.com/logos/beat.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/beat">BEAT</a>
                    </h3>
                    BEAT is a SportAlliance project to help promote Sporting and Healthy activities                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/beat" class="ui green button">
                            19/02/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/beat" class="ui red button">
                            15/05/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/smartrealty" class="ui small image">
                        <img src="../icowatchlist.com/logos/smartrealty.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/smartrealty">SMARTRealty</a>
                    </h3>
                    SMARTRealty is revolutionizing the real estate industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/smartrealty" class="ui green button">
                            15/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/smartrealty" class="ui red button">
                            15/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/friendup" class="ui small image">
                        <img src="../icowatchlist.com/logos/friendup.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/friendup">FriendUP</a>
                    </h3>
                    The ultimate digital ecosystem platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/friendup" class="ui green button">
                            16/04/2018 18:47                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/friendup" class="ui red button">
                            16/05/2018 18:48                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bounty-angels" class="ui small image">
                        <img src="../icowatchlist.com/logos/bounty-angels.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bounty-angels">Bounty Angels</a>
                    </h3>
                    A solution for Bounty hunters For ICO For blockchain community For everyone                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bounty-angels" class="ui green button">
                            16/04/2018 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bounty-angels" class="ui red button">
                            16/05/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/worldopoly" class="ui small image">
                        <img src="../icowatchlist.com/logos/worldopoly.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldopoly">Worldopoly</a>
                    </h3>
                    Mobile gaming combined with Augmented Reality                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldopoly" class="ui green button">
                            26/04/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/worldopoly" class="ui red button">
                            18/05/2018 07:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/synthestech" class="ui small image">
                        <img src="../icowatchlist.com/logos/synthestech.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/synthestech">Synthestech</a>
                    </h3>
                    Synthestech is a scientific research center engaged in technology development for synthesis of precious metals and valuable isotopes                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/synthestech" class="ui green button">
                            18/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/synthestech" class="ui red button">
                            18/05/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/worldwifi" class="ui small image">
                        <img src="../icowatchlist.com/logos/worldwifi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldwifi">WorldWiFi</a>
                    </h3>
                    Decentralized free wifi network powered by blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldwifi" class="ui green button">
                            17/04/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/worldwifi" class="ui red button">
                            17/05/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/goldiam" class="ui small image">
                        <img src="../icowatchlist.com/logos/goldiam.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/goldiam">Goldiam</a>
                    </h3>
                    The Future of Gold and Diamond mining                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/goldiam" class="ui green button">
                            09/04/2018 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/goldiam" class="ui red button">
                            18/05/2018 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dreamteam" class="ui small image">
                        <img src="../icowatchlist.com/logos/dreamteam.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dreamteam">DreamTeam</a>
                    </h3>
                    DreamTeam  the first Esports and Gaming recruitment and management network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dreamteam" class="ui green button">
                            12/04/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dreamteam" class="ui red button">
                            19/05/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mira" class="ui small image">
                        <img src="../icowatchlist.com/logos/mira.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mira">Mira</a>
                    </h3>
                    Mira is a software suite for buying storing and sending cryptocurrencies in an easy and convenient way                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mira" class="ui green button">
                            20/04/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mira" class="ui red button">
                            20/05/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/windenergymining" class="ui small image">
                        <img src="../icowatchlist.com/logos/windenergymining.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/windenergymining">WindEnergyMining</a>
                    </h3>
                    Green Energy Green Mining Cryptocurrency mining in an ecofriendly environment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/windenergymining" class="ui green button">
                            20/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/windenergymining" class="ui red button">
                            20/05/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/unibright" class="ui small image">
                        <img src="../icowatchlist.com/logos/unibright.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/unibright">Unibright</a>
                    </h3>
                    The unified framework for blockchain based business integration to maximize efficiency and profits                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/unibright" class="ui green button">
                            20/04/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/unibright" class="ui red button">
                            20/05/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iame-identity" class="ui small image">
                        <img src="../icowatchlist.com/logos/iame-identity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iame-identity">IAME Identity</a>
                    </h3>
                    Making compromised information hackworthless It makes use of distributed ledger system to ensure that peoples identifications are secure                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iame-identity" class="ui green button">
                            18/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iame-identity" class="ui red button">
                            20/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/koranetwork" class="ui small image">
                        <img src="../icowatchlist.com/logos/koranetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/koranetwork">Kora Network</a>
                    </h3>
                    Infrastructure for building inclusive financial systems for all and sundry using blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/koranetwork" class="ui green button">
                            23/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/koranetwork" class="ui red button">
                            21/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/robet" class="ui small image">
                        <img src="../icowatchlist.com/logos/robet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/robet">RoBET</a>
                    </h3>
                    RoBET is going to be the first platform for crypto sports betting and cryptocurrency exchange                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/robet" class="ui green button">
                            20/04/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/robet" class="ui red button">
                            21/05/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ftec" class="ui small image">
                        <img src="../icowatchlist.com/logos/ftec.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ftec">FTEC</a>
                    </h3>
                    FTEC is an ecosystem of intelligent services and neural networks for conducting effective trading activities on cryptocurrency markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ftec" class="ui green button">
                            24/04/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ftec" class="ui red button">
                            22/05/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crowd-machine" class="ui small image">
                        <img src="../icowatchlist.com/logos/crowd-machine.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowd-machine">Crowd Machine</a>
                    </h3>
                    Crowd Machine is powering the next generation of decentralized blockchain applications                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowd-machine" class="ui green button">
                            01/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crowd-machine" class="ui red button">
                            22/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/renything" class="ui small image">
                        <img src="../icowatchlist.com/logos/renything.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/renything">Rentything</a>
                    </h3>
                    Rentything  Worlds 1st Decentralized P2P Renting Platform Airbnb for Everything RentGetPaid                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/renything" class="ui green button">
                            25/04/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/renything" class="ui red button">
                            23/05/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/graphgrail-ai" class="ui small image">
                        <img src="../icowatchlist.com/logos/graphgrail-ai.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/graphgrail-ai">GraphGrail AI</a>
                    </h3>
                    Artificial intelligence platform for blockchain built on the basis of natural language processing technologies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/graphgrail-ai" class="ui green button">
                            19/02/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/graphgrail-ai" class="ui red button">
                            25/05/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/smoke" class="ui small image">
                        <img src="../icowatchlist.com/logos/smoke.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/smoke">SMOKE</a>
                    </h3>
                    SMOKE is the cryptocurrency of the SmokeNetwork The first cannabis community to combine blockchain technology with soc                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/smoke" class="ui green button">
                            20/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/smoke" class="ui red button">
                            25/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bunnytoken" class="ui small image">
                        <img src="../icowatchlist.com/logos/bunnytoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bunnytoken">BunnyToken</a>
                    </h3>
                    BunnyToken is a payment solution for the 103 billion adult industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bunnytoken" class="ui green button">
                            25/04/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bunnytoken" class="ui red button">
                            25/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mobilebridge" class="ui small image">
                        <img src="../icowatchlist.com/logos/mobilebridge.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilebridge">MobileBridge</a>
                    </h3>
                    The blockchain and cryptotoken based marketing automation platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilebridge" class="ui green button">
                            26/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilebridge" class="ui red button">
                            25/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/databroker-dao" class="ui small image">
                        <img src="../icowatchlist.com/logos/databroker-dao.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/databroker-dao">DataBroker DAO</a>
                    </h3>
                    DataBroker DAO is the first marketplace to sell  buy sensor data                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/databroker-dao" class="ui green button">
                            26/04/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/databroker-dao" class="ui red button">
                            26/05/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/one1" class="ui small image">
                        <img src="../icowatchlist.com/logos/one1.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/one1">One+1</a>
                    </h3>
                    A token that integrates business and charity into a single effective ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/one1" class="ui green button">
                            10/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/one1" class="ui red button">
                            27/05/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coinadvisor" class="ui small image">
                        <img src="../icowatchlist.com/logos/coinadvisor.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinadvisor">Coinadvisor</a>
                    </h3>
                    Coinadvisor is a trading platform for arbitrage bot and a multi accounts management tool                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinadvisor" class="ui green button">
                            26/04/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coinadvisor" class="ui red button">
                            27/05/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/datecoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/datecoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/datecoin">DateCoin</a>
                    </h3>
                    The fastest successful match                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/datecoin" class="ui green button">
                            30/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/datecoin" class="ui red button">
                            30/05/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/xsearch" class="ui small image">
                        <img src="../icowatchlist.com/logos/xsearch.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/xsearch">XSEARCH</a>
                    </h3>
                    XSEARCH  Innovating Research System using the power of blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/xsearch" class="ui green button">
                            20/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/xsearch" class="ui red button">
                            30/05/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/jointedu" class="ui small image">
                        <img src="../icowatchlist.com/logos/jointedu.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/jointedu">Jointedu</a>
                    </h3>
                    Educational investment on Blockchain Enable everybody to share their knowledge and skills through our future online learning system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/jointedu" class="ui green button">
                            16/04/2018 02:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/jointedu" class="ui red button">
                            31/05/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitrust" class="ui small image">
                        <img src="../icowatchlist.com/logos/bitrust.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrust">BITRUST</a>
                    </h3>
                    A decentralized easy to use peer2peer cryptocurrency insurance platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrust" class="ui green button">
                            02/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrust" class="ui red button">
                            31/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ubcoin-market" class="ui small image">
                        <img src="../icowatchlist.com/logos/ubcoin-market.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ubcoin-market">Ubcoin Market</a>
                    </h3>
                    Exchange Cryptocurrency for Real Goods and Vice Versa                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ubcoin-market" class="ui green button">
                            02/04/2018 00:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ubcoin-market" class="ui red button">
                            31/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitproperty" class="ui small image">
                        <img src="../icowatchlist.com/logos/bitproperty.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitproperty">BitProperty</a>
                    </h3>
                    Tokenizing and digitalizing Real Estate Investments through the application of Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitproperty" class="ui green button">
                            15/04/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitproperty" class="ui red button">
                            31/05/2018 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/likecoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/likecoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/likecoin">LikeCoin</a>
                    </h3>
                    LikeCoin aims to reinvent the Like by realigning creativity and reward                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/likecoin" class="ui green button">
                            22/04/2018 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/likecoin" class="ui red button">
                            31/05/2018 15:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fcfl" class="ui small image">
                        <img src="../icowatchlist.com/logos/fcfl.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fcfl">FCFL</a>
                    </h3>
                    The first professional sports league built on the blockchain and controlled by the fans                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fcfl" class="ui green button">
                            20/03/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fcfl" class="ui red button">
                            01/06/2018 07:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/virtonomics" class="ui small image">
                        <img src="../icowatchlist.com/logos/virtonomics.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/virtonomics">Virtonomics</a>
                    </h3>
                    Ecosystem capable of meeting the million people needs in an affordable interesting creative and wellpaid online job                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/virtonomics" class="ui green button">
                            28/02/2018 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/virtonomics" class="ui red button">
                            31/05/2018 19:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/transcodium" class="ui small image">
                        <img src="../icowatchlist.com/logos/transcodium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/transcodium">Transcodium</a>
                    </h3>
                    Transcodium aims to provide the first peertopeer blockchain based and decentralized media transcoding editing and distribution platform with high quality and reliable computational power at a very affordable price                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/transcodium" class="ui green button">
                            28/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/transcodium" class="ui red button">
                            31/05/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gamblica" class="ui small image">
                        <img src="../icowatchlist.com/logos/gamblica.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gamblica">Gamblica</a>
                    </h3>
                    Gamblica is an international gambling platform based on innovative digital solutions and blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gamblica" class="ui green button">
                            01/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gamblica" class="ui red button">
                            01/06/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eos" class="ui small image">
                        <img src="../icowatchlist.com/logos/eos.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eos">EOS</a>
                    </h3>
                    A powerful infrastructure for decentralized apps                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eos" class="ui green button">
                            26/06/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eos" class="ui red button">
                            01/06/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cultural-places" class="ui small image">
                        <img src="../icowatchlist.com/logos/cultural-places.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cultural-places">Cultural Places</a>
                    </h3>
                    Blockchain meets culture connect visitors institutions and artists                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cultural-places" class="ui green button">
                            05/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cultural-places" class="ui red button">
                            04/06/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/stasyq" class="ui small image">
                        <img src="../icowatchlist.com/logos/stasyq.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/stasyq">StasyQ</a>
                    </h3>
                    StasyQ brings crypto revolution to the adult industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/stasyq" class="ui green button">
                            06/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/stasyq" class="ui red button">
                            05/06/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hybrid-betting" class="ui small image">
                        <img src="../icowatchlist.com/logos/hybrid-betting.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hybrid-betting">Hybrid Betting</a>
                    </h3>
                    The unique platform in the world where betting is a different game                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hybrid-betting" class="ui green button">
                            03/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hybrid-betting" class="ui red button">
                            08/06/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coinoil" class="ui small image">
                        <img src="../icowatchlist.com/logos/coinoil.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinoil">CoinOil</a>
                    </h3>
                    Oil Backed Coin CoinOil will be supported by assets in physical oil  oil futures                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinoil" class="ui green button">
                            24/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coinoil" class="ui red button">
                            09/06/2018 07:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/smart-trip-platform" class="ui small image">
                        <img src="../icowatchlist.com/logos/smart-trip-platform.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/smart-trip-platform">Smart Trip Platform</a>
                    </h3>
                    A blockchainenabled ecosystem that connects travelers and travel service providers to create unforgettable trips                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/smart-trip-platform" class="ui green button">
                            16/04/2018 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/smart-trip-platform" class="ui red button">
                            10/06/2018 01:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/multiversum" class="ui small image">
                        <img src="../icowatchlist.com/logos/multiversum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/multiversum">Multiversum</a>
                    </h3>
                    4th Generation Blockchain with a Multidimensional Structure POS                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/multiversum" class="ui green button">
                            15/04/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/multiversum" class="ui red button">
                            10/06/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gifcoin" class="ui small image">
                        <img src="../icowatchlist.com/logos/gifcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gifcoin">GIFcoin</a>
                    </h3>
                    The GIF in GIFcoin stands for Gambling Investment Fund Gamers get to make winning in a provably fair gambling system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gifcoin" class="ui green button">
                            16/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gifcoin" class="ui red button">
                            12/06/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/binkd" class="ui small image">
                        <img src="../icowatchlist.com/logos/binkd.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/binkd">BINKD</a>
                    </h3>
                    Decentralized Cryptocurrency Exchange with Fiat onboarding                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/binkd" class="ui green button">
                            15/04/2018 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/binkd" class="ui red button">
                            15/06/2018 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bioritmai" class="ui small image">
                        <img src="../icowatchlist.com/logos/bioritmai.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bioritmai">BIORITMAI</a>
                    </h3>
                    A PERSONALIZED MEDICINE OF THE FUTURE A modern system of biorhythm monitoring with the most sophisticated tools for analysis and realtime diagnostics                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bioritmai" class="ui green button">
                            15/04/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bioritmai" class="ui red button">
                            15/06/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/earthmedz" class="ui small image">
                        <img src="../icowatchlist.com/logos/earthmedz.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/earthmedz">Earthmedz</a>
                    </h3>
                    Ensuring the accessibility of efficient healthcare globally using blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/earthmedz" class="ui green button">
                            20/04/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/earthmedz" class="ui red button">
                            18/06/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/weevocity" class="ui small image">
                        <img src="../icowatchlist.com/logos/weevocity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/weevocity">WeevoCity</a>
                    </h3>
                    Decentralized Social Urban Network for Online Marketing Focused on Local Business                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/weevocity" class="ui green button">
                            25/04/2018 22:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/weevocity" class="ui red button">
                            24/06/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coin-mine-australia" class="ui small image">
                        <img src="../icowatchlist.com/logos/coin-mine-australia.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coin-mine-australia">Coin Mine Australia</a>
                    </h3>
                    Australias First  Largest Crowd Funded Mining Operation                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coin-mine-australia" class="ui green button">
                            16/04/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coin-mine-australia" class="ui red button">
                            25/06/2018 15:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/savage-token" class="ui small image">
                        <img src="../icowatchlist.com/logos/savage-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/savage-token">Savage Token</a>
                    </h3>
                    The Savage Token project is a  democratized tokenized reputationbased stock media platform that rewards millions of digital content creators without the need for any central middlemen                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/savage-token" class="ui green button">
                            26/03/2018 00:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/savage-token" class="ui red button">
                            26/06/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/b21" class="ui small image">
                        <img src="../icowatchlist.com/logos/b21.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/b21">B21</a>
                    </h3>
                    Your personal wealth manager for cryptoassets to help maximize profits                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/b21" class="ui green button">
                            27/04/2018 17:13                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/b21" class="ui red button">
                            27/06/2018 17:14                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eotrade" class="ui small image">
                        <img src="../icowatchlist.com/logos/eotrade.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eotrade">EO.Trade</a>
                    </h3>
                    Leading Online Broker ExpertOption introduces the EO ecosystem EOTrade cryptoexchange EOFinance wallet and EONews portal                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eotrade" class="ui green button">
                            16/04/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eotrade" class="ui red button">
                            29/06/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/playtness" class="ui small image">
                        <img src="../icowatchlist.com/logos/playtness.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/playtness">Playtness</a>
                    </h3>
                    Tokenizing the world of fitness to create healthier lives for all around the globe using the power of blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/playtness" class="ui green button">
                            15/03/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/playtness" class="ui red button">
                            30/06/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/equi" class="ui small image">
                        <img src="../icowatchlist.com/logos/equi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/equi">EQUI</a>
                    </h3>
                    EQUI disrupts the traditional venture investment market by empowering the crypto community to join the next generation of venture capital investors                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/equi" class="ui green button">
                            15/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/equi" class="ui red button">
                            30/06/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/paygine" class="ui small image">
                        <img src="../icowatchlist.com/logos/paygine.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/paygine">Paygine</a>
                    </h3>
                    Paygine is an open financial platform designed to operate within its own proprietary banking structure and designed to serve cryptobusiness needs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/paygine" class="ui green button">
                            01/04/2018 05:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/paygine" class="ui red button">
                            01/07/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iac-autounit" class="ui small image">
                        <img src="../icowatchlist.com/logos/iac-autounit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iac-autounit">IAC AutoUnit</a>
                    </h3>
                    Decentralized marketplace with multilevel cashback                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iac-autounit" class="ui green button">
                            26/03/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iac-autounit" class="ui red button">
                            22/07/2018 09:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/valoremfoundation" class="ui small image">
                        <img src="../icowatchlist.com/logos/valoremfoundation.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/valoremfoundation">Valorem Foundation</a>
                    </h3>
                    Valorem Foundation is building a niche ecommerce platform for 99 of the market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/valoremfoundation" class="ui green button">
                            15/12/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/valoremfoundation" class="ui red button">
                            28/07/2018 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/darico" class="ui small image">
                        <img src="../icowatchlist.com/logos/darico.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/darico">Darico</a>
                    </h3>
                    Monitor Trade Invest Spend                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/darico" class="ui green button">
                            29/01/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/darico" class="ui red button">
                            30/07/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/multiven-mom" class="ui small image">
                        <img src="../icowatchlist.com/logos/multiven-mom.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/multiven-mom">Multiven MOM</a>
                    </h3>
                    Manage maintain and trade all your network and IT hardware and software in one place                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/multiven-mom" class="ui green button">
                            07/03/2018 23:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/multiven-mom" class="ui red button">
                            09/08/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lantah" class="ui small image">
                        <img src="../icowatchlist.com/logos/lantah.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lantah">Lantah</a>
                    </h3>
                    Borderless marketplace connecting global trade and disrupting commerce giants through the implementation of Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lantah" class="ui green button">
                            09/03/2018 10:44                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lantah" class="ui red button">
                            31/08/2018 10:44                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/techrod" class="ui small image">
                        <img src="../icowatchlist.com/logos/techrod.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/techrod">Techrod</a>
                    </h3>
                    Revolutionizing ElectionsConsensus decision making Process                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/techrod" class="ui green button">
                            12/03/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/techrod" class="ui red button">
                            30/09/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/provoco" class="ui small image">
                        <img src="../icowatchlist.com/logos/provoco.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/provoco">Provoco</a>
                    </h3>
                    Provoco is the new generation of blockchainempowered social challenge network for mass users                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/provoco" class="ui green button">
                            01/04/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/provoco" class="ui red button">
                            01/10/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                </tbody>
    </table>


    
</div>

    </main>

    <footer id="footer">
        <div class="ui stackable grid">

            <div id="footer-main" class="centered row">
                <div class="middle aligned five wide column">
                    <h3 class="ui header">
                        Mize Market                        <br>
                                                    <img class="ui image" src="images/1524688786.png">
                                            </h3>
                </div>

                                                            <div class="center aligned five wide column">
                            <h3 class="ui header">Social</h3>
                            <div class="ui large list">
                                <a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/">Facebook&nbsp;<i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg">Youtube&nbsp;<i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/">Instagram&nbsp;<i class="instagram icon"></i></a>                            </div>
                        </div>
                                                                                <div class="center aligned five wide column">
                            <h3 class="ui header">Official Websites</h3>
                            <div class="ui large list">
                                <a class="item menu-item" href="go/footer_2/0.php">Mize Network</a><a class="item menu-item" href="go/footer_2/1.php">Mize Academy</a>                            </div>
                        </div>
                                                                                    </div>

            <div id="footer-bottom-bar" class="centered row">
                <div class="center aligned sixteen wide column">
                    2018 @ Mize Market -                     Powered By <a href="https://www.cryptocompare.com/" target="_blank">CryptoCompare</a>
                </div>
            </div>
        </div>
    </footer>
    <br>
</div>

<div id="donation-box" class="ui modal">
    <div class="scrolling content">
        <div class="ui icon huge message">
            <i class="hand peace icon"></i>
            <div class="content">
                <div class="header"></div>
                <div></div>
            </div>
        </div>
                    </div>
    <div class="actions">
        <div class="ui ok green button"></div>
    </div>
</div>

<div id="slide-up" class="ui yellow icon button" style="z-index: 9999; display: none;"><i class="arrow up icon"></i></div>

<script>
    //<![CDATA[
    window.CoinTableConstants = {"site_url":"http:\/\/mize.market\/","currency_page":"http:\/\/mize.market\/currency\/","price_currency":"USD"};
    //]]>
</script>
    <script src="../cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.js"></script>
    <script src="../cdnjs.cloudflare.com/ajax/libs/money.js/0.2.0/money.min.js"></script>
    <script src="assets/frontend/js/frontend.min.js"></script>


</body>

<!-- Mirrored from mize.market/icos by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Apr 2018 20:59:39 GMT -->
</html>