<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from mize.market/icos/finished by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Apr 2018 21:00:06 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">

        <link rel="shorcut icon" type="image/png" href="../images/1524688798.png">
    
    <title>Mize Market - CryptoCurrency Markets</title>
    <meta name="description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <link rel="canonical" href="finished.html" />


    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="finished.html"/>
    <meta property="og:title" content="CryptoCurrency Markets"/>
    <meta property="og:description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <meta property="og:site_name" content="Mize Market"/>
    

    <meta name="twitter:card" content="summary"/>
    <meta name="twitter:description" content="MizeMarket is a Cryptocurrency Markets Platform."/>
    <meta name="twitter:title" content="CryptoCurrency Markets"/>
    <meta name="twitter:url" content="finished.html"/>
            
    <meta name="theme-color" content="#FFD700">

            <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.css">
            <link rel="stylesheet" href="../assets/frontend/css/frontend.css">
    
    <style>
        #top-menu {background-color: #ffffff;}
        #top-menu .item {color: #333333;}
        
        @media only screen and (max-width: 1024px) {
            #top-menu .price-currency-item, #top-menu .menu-item  {
                display: none;
            }
        }

        @media only screen and (min-width: 1024px) {
            #sidebar-menu-toggle  {
                display: none;
            }
        }

                #sidebar-menu {background-color: #ffffff;}
        #sidebar-menu .item {color: #333333;}
        #header-logo {height: 50px; }
        #stats {padding-top: 130px;}
        #footer {background-color: #f3f3f3;}
        #footer-main h1, #footer-main h1 .sub.header {color: #333333;}
        #footer-main h3 {color: #222222;}
        #footer-main .item, #footer-main .item i {color: #333333;}
        #footer-bottom-bar, #footer-bottom-bar a {
            background-color: #f0f0f0;
            color: #333333;
        }
    </style>

    <style></style>
</head>
<body>

<div id="sidebar-menu" class="ui big vertical sidebar menu left">
    <a class="item menu-item" href="../market.html">Market</a><a class="item menu-item" href="../converter.html">Converter</a><a class="item menu-item" href="../icos.html">ICOs</a><a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/">Facebook&nbsp;<i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg">Youtube&nbsp;<i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/">Instagram&nbsp;<i class="instagram icon"></i></a>    <div class="item">
        <select class="price-currency fluid ui search dropdown"><option value="BTC">Bitcoin</option><option selected value="USD">US Dollar</option><option value="EUR">Eurozone Euro</option><option value="GBP">Pound Sterling</option><option value="JPY">Japanese Yen</option><option value="CAD">Canadian Dollar</option><option value="AUD">Australian Dollar</option><option value="CNY">Chinese Yuan</option><option value="CHF">Swiss Franc</option><option value="SEK">Swedish Krona</option><option value="NZD">New Zealand Dollar</option><option value="KRW">South Korean Won</option><option value="AED">UAE Dirham</option><option value="AFN">Afghan Afghani</option><option value="ALL">Albanian Lek</option><option value="AMD">Armenian Dram</option><option value="ANG">Netherlands Antillean Guilder</option><option value="AOA">Angolan Kwanza</option><option value="ARS">Argentine Peso</option><option value="AWG">Aruban Florin</option><option value="AZN">Azerbaijani Manat</option><option value="BAM">Bosnia-Herzegovina Convertible Mark</option><option value="BBD">Barbadian Dollar</option><option value="BDT">Bangladeshi Taka</option><option value="BGN">Bulgarian Lev</option><option value="BHD">Bahraini Dinar</option><option value="BIF">Burundian Franc</option><option value="BMD">Bermudan Dollar</option><option value="BND">Brunei Dollar</option><option value="BOB">Bolivian Boliviano</option><option value="BRL">Brazilian Real</option><option value="BSD">Bahamian Dollar</option><option value="BTN">Bhutanese Ngultrum</option><option value="BWP">Botswanan Pula</option><option value="BZD">Belize Dollar</option><option value="CDF">Congolese Franc</option><option value="CLF">Chilean Unit of Account (UF)</option><option value="CLP">Chilean Peso</option><option value="COP">Colombian Peso</option><option value="CRC">Costa Rican Colón</option><option value="CUP">Cuban Peso</option><option value="CVE">Cape Verdean Escudo</option><option value="CZK">Czech Koruna</option><option value="DJF">Djiboutian Franc</option><option value="DKK">Danish Krone</option><option value="DOP">Dominican Peso</option><option value="DZD">Algerian Dinar</option><option value="EGP">Egyptian Pound</option><option value="ETB">Ethiopian Birr</option><option value="FJD">Fijian Dollar</option><option value="FKP">Falkland Islands Pound</option><option value="GEL">Georgian Lari</option><option value="GHS">Ghanaian Cedi</option><option value="GIP">Gibraltar Pound</option><option value="GMD">Gambian Dalasi</option><option value="GNF">Guinean Franc</option><option value="GTQ">Guatemalan Quetzal</option><option value="GYD">Guyanaese Dollar</option><option value="HKD">Hong Kong Dollar</option><option value="HNL">Honduran Lempira</option><option value="HRK">Croatian Kuna</option><option value="HTG">Haitian Gourde</option><option value="HUF">Hungarian Forint</option><option value="IDR">Indonesian Rupiah</option><option value="ILS">Israeli Shekel</option><option value="INR">Indian Rupee</option><option value="IQD">Iraqi Dinar</option><option value="IRR">Iranian Rial</option><option value="ISK">Icelandic Króna</option><option value="JEP">Jersey Pound</option><option value="JMD">Jamaican Dollar</option><option value="JOD">Jordanian Dinar</option><option value="KES">Kenyan Shilling</option><option value="KGS">Kyrgystani Som</option><option value="KHR">Cambodian Riel</option><option value="KMF">Comorian Franc</option><option value="KPW">North Korean Won</option><option value="KWD">Kuwaiti Dinar</option><option value="KYD">Cayman Islands Dollar</option><option value="KZT">Kazakhstani Tenge</option><option value="LAK">Laotian Kip</option><option value="LBP">Lebanese Pound</option><option value="LKR">Sri Lankan Rupee</option><option value="LRD">Liberian Dollar</option><option value="LSL">Lesotho Loti</option><option value="LYD">Libyan Dinar</option><option value="MAD">Moroccan Dirham</option><option value="MDL">Moldovan Leu</option><option value="MGA">Malagasy Ariary</option><option value="MKD">Macedonian Denar</option><option value="MMK">Myanma Kyat</option><option value="MNT">Mongolian Tugrik</option><option value="MOP">Macanese Pataca</option><option value="MRU">Mauritanian Ouguiya</option><option value="MUR">Mauritian Rupee</option><option value="MVR">Maldivian Rufiyaa</option><option value="MWK">Malawian Kwacha</option><option value="MXN">Mexican Peso</option><option value="MYR">Malaysian Ringgit</option><option value="MZN">Mozambican Metical</option><option value="NAD">Namibian Dollar</option><option value="NGN">Nigerian Naira</option><option value="NIO">Nicaraguan Córdoba</option><option value="NOK">Norwegian Krone</option><option value="NPR">Nepalese Rupee</option><option value="OMR">Omani Rial</option><option value="PAB">Panamanian Balboa</option><option value="PEN">Peruvian Nuevo Sol</option><option value="PGK">Papua New Guinean Kina</option><option value="PHP">Philippine Peso</option><option value="PKR">Pakistani Rupee</option><option value="PLN">Polish Zloty</option><option value="PYG">Paraguayan Guarani</option><option value="QAR">Qatari Rial</option><option value="RON">Romanian Leu</option><option value="RSD">Serbian Dinar</option><option value="RUB">Russian Ruble</option><option value="RWF">Rwandan Franc</option><option value="SAR">Saudi Riyal</option><option value="SBD">Solomon Islands Dollar</option><option value="SCR">Seychellois Rupee</option><option value="SDG">Sudanese Pound</option><option value="SGD">Singapore Dollar</option><option value="SHP">Saint Helena Pound</option><option value="SLL">Sierra Leonean Leone</option><option value="SOS">Somali Shilling</option><option value="SRD">Surinamese Dollar</option><option value="STN">São Tomé and Príncipe Dobra</option><option value="SVC">Salvadoran Colón</option><option value="SYP">Syrian Pound</option><option value="SZL">Swazi Lilangeni</option><option value="THB">Thai Baht</option><option value="TJS">Tajikistani Somoni</option><option value="TMT">Turkmenistani Manat</option><option value="TND">Tunisian Dinar</option><option value="TOP">Tongan Paʻanga</option><option value="TRY">Turkish Lira</option><option value="TTD">Trinidad and Tobago Dollar</option><option value="TWD">New Taiwan Dollar</option><option value="TZS">Tanzanian Shilling</option><option value="UAH">Ukrainian Hryvnia</option><option value="UGX">Ugandan Shilling</option><option value="UYU">Uruguayan Peso</option><option value="UZS">Uzbekistan Som</option><option value="VEF">Venezuelan Bolívar Fuerte</option><option value="VND">Vietnamese Dong</option><option value="VUV">Vanuatu Vatu</option><option value="WST">Samoan Tala</option><option value="XAF">CFA Franc BEAC</option><option value="XCD">East Caribbean Dollar</option><option value="XOF">CFA Franc BCEAO</option><option value="XPF">CFP Franc</option><option value="YER">Yemeni Rial</option><option value="ZAR">South African Rand</option><option value="ZMW">Zambian Kwacha</option><option value="ZWL">Zimbabwean Dollar</option><option value="XAG">Silver (troy ounce)</option><option value="XAU">Gold (troy ounce)</option><option value="ETH">Ethereum</option><option value="XRP">Ripple</option><option value="BCH">Bitcoin Cash</option><option value="EOS">EOS</option><option value="LTC">Litecoin</option><option value="ADA">Cardano</option><option value="XLM">Stellar</option><option value="MIOTA">IOTA</option><option value="TRX">TRON</option><option value="NEO">NEO</option><option value="XMR">Monero</option><option value="DASH">Dash</option><option value="XEM">NEM</option><option value="USDT">Tether</option><option value="ETC">Ethereum Classic</option><option value="VEN">VeChain</option><option value="OMG">OmiseGO</option><option value="QTUM">Qtum</option><option value="ICX">ICON</option><option value="BNB">Binance Coin</option><option value="BTG">Bitcoin Gold</option><option value="LSK">Lisk</option><option value="STEEM">Steem</option><option value="ZEC">Zcash</option><option value="XVG">Verge</option><option value="SC">Siacoin</option><option value="BCN">Bytecoin</option><option value="BTM*">Bytom</option><option value="NANO">Nano</option><option value="BCD">Bitcoin Diamond</option><option value="WAN">Wanchain</option><option value="BTCP">Bitcoin Private</option><option value="PPT">Populous</option><option value="BTS">BitShares</option><option value="ZIL">Zilliqa</option><option value="AE">Aeternity</option><option value="DOGE">Dogecoin</option><option value="MKR">Maker</option><option value="DCR">Decred</option><option value="STRAT">Stratis</option><option value="ONT">Ontology</option><option value="XIN">Mixin</option><option value="ZRX">0x</option><option value="WAVES">Waves</option><option value="DGD">DigixDAO</option><option value="HSR">Hshare</option><option value="RHOC">RChain</option><option value="GNT">Golem</option><option value="SNT">Status</option><option value="AION">Aion</option><option value="WTC">Waltonchain</option><option value="REP">Augur</option><option value="LRC">Loopring</option><option value="DGB">DigiByte</option><option value="BAT">Basic Attention Token</option><option value="IOST">IOStoken</option><option value="KMD">Komodo</option><option value="ARDR">Ardor</option><option value="MITH">Mithril</option><option value="KNC">Kyber Network</option><option value="ARK">Ark</option><option value="MONA">MonaCoin</option><option value="KCS">KuCoin Shares</option><option value="CENNZ">Centrality</option><option value="PIVX">PIVX</option><option value="ELF">aelf</option><option value="SYS">Syscoin</option><option value="CNX">Cryptonex</option><option value="DRGN">Dragonchain</option><option value="SUB">Substratum</option><option value="DCN">Dentacoin</option><option value="GAS">Gas</option><option value="NPXS">Pundi X</option><option value="STORM">Storm</option><option value="QASH">QASH</option><option value="ETHOS">Ethos</option><option value="FCT">Factom</option><option value="NAS">Nebulas</option><option value="GTO">Gifto</option><option value="RDD">ReddCoin</option><option value="CTXC">Cortex</option><option value="BNT">Bancor</option><option value="VERI">Veritaseum</option><option value="SALT">SALT</option><option value="FUN">FunFair</option><option value="GXS">GXChain</option><option value="ELA">Elastos</option><option value="WAX">WAX</option><option value="XZC">ZCoin</option><option value="NXT">Nxt</option><option value="POWR">Power Ledger</option><option value="ENG">Enigma</option><option value="MCO">Monaco</option><option value="KIN">Kin</option><option value="R">Revain</option><option value="LOOM">Loom Network</option><option value="ETN">Electroneum</option><option value="NCASH">Nucleus Vision</option><option value="REQ">Request Network</option><option value="GBYTE">Byteball Bytes</option><option value="MAID">MaidSafeCoin</option><option value="FSN">Fusion</option><option value="NEBL">Neblio</option><option value="LINK">ChainLink</option><option value="PAY">TenX</option><option value="SMT">SmartMesh</option><option value="DBC">DeepBrain Chain</option><option value="ZEN">ZenCash</option><option value="SMART">SmartCash</option><option value="STORJ">Storj</option><option value="PART">Particl</option><option value="SKY">Skycoin</option><option value="CND">Cindicator</option><option value="MANA">Decentraland</option><option value="ICN">Iconomi</option><option value="ACT">Achain</option><option value="MAN">Matrix AI Network</option><option value="GTC">Game.com</option><option value="POA">POA Network</option><option value="CVC">Civic</option><option value="EMC">Emercoin</option><option value="NXS">Nexus</option><option value="BOS">BOScoin</option><option value="NULS">Nuls</option><option value="TPAY">TokenPay</option><option value="PAYX">Paypex</option><option value="DENT">Dent</option><option value="POLY">Polymath</option><option value="POE">Po.et</option><option value="LCC">Litecoin Cash</option><option value="DTR">Dynamic Trading Rights</option><option value="GNO">Gnosis</option><option value="BTCD">BitcoinDark</option><option value="RLC">iExec RLC</option><option value="MTL">Metal</option><option value="VTC">Vertcoin</option><option value="DEW">DEW</option><option value="TNB">Time New Bank</option><option value="QSP">Quantstamp</option><option value="ANT">Aragon</option><option value="CMT">CyberMiles</option><option value="GAME">GameCredits</option><option value="BTX">Bitcore</option><option value="HT">Huobi Token</option><option value="SAN">Santiment Network Token</option><option value="ENJ">Enjin Coin</option><option value="SPHTX">SophiaTX</option><option value="RDN">Raiden Network Token</option><option value="ABT">Arcblock</option><option value="AGI">SingularityNET</option><option value="MED">MediBloc</option><option value="HPB">High Performance Blockchain</option><option value="PPP">PayPie</option><option value="GRS">Groestlcoin</option><option value="CPX">Apex</option><option value="AUTO">Cube</option><option value="GNX">Genaro Network</option><option value="XDN">DigitalNote</option><option value="BLOCK">Blocknet</option><option value="AMB">Ambrosus</option><option value="SRN">SIRIN LABS Token</option><option value="UBQ">Ubiq</option><option value="DROP">Dropil</option><option value="DTA">DATA</option><option value="RUFF">Ruff</option><option value="CS">Credits</option><option value="TKY">THEKEY</option><option value="VEE">BLOCKv</option><option value="RPX">Red Pulse</option><option value="THETA">Theta Token</option><option value="BLZ">Bluzelle</option><option value="SNM">SONM</option><option value="IGNIS">Ignis</option><option value="NAV">NavCoin</option><option value="PLR">Pillar</option><option value="ZCL">ZClassic</option><option value="INK">Ink</option><option value="GVT">Genesis Vision</option><option value="LEND">ETHLend</option><option value="CLOAK">CloakCoin</option><option value="AST">AirSwap</option><option value="TOMO">TomoChain</option><option value="XAS">Asch</option><option value="DDD">Scry.info</option><option value="BAY">BitBay</option><option value="EMC2">Einsteinium</option><option value="BIX">Bibox Token</option><option value="OST">OST</option><option value="C20">CRYPTO20</option><option value="ADX">AdEx</option><option value="QRL">Quantum Resistant Ledger</option><option value="RCN">Ripio Credit Network</option><option value="IHT">IHT Real Estate Protocol</option><option value="EDO">Eidoo</option><option value="DATA">Streamr DATAcoin</option><option value="TEL">Telcoin</option><option value="ITC">IoT Chain</option><option value="BTO">Bottos</option><option value="CRPT">Crypterium</option><option value="ION">ION</option><option value="BRD">Bread</option><option value="MNX">MinexCoin</option><option value="WPR">WePower</option><option value="PPC">Peercoin</option><option value="ELEC">Electrify.Asia</option><option value="INS">INS Ecosystem</option><option value="SLS">SaluS</option><option value="VIBE">VIBE</option><option value="VIA">Viacoin</option><option value="NANJ">NANJCOIN</option><option value="BCO">BridgeCoin</option><option value="INT">Internet Node Token</option><option value="WABI">WaBi</option><option value="EDG">Edgeless</option><option value="SNGLS">SingularDTV</option><option value="JNT">Jibrel Network</option><option value="APPC">AppCoins</option><option value="DNT">district0x</option><option value="RNTB">BitRent</option><option value="SPANK">SpankChain</option><option value="UTK">UTRUST</option><option value="MDS">MediShares</option><option value="WINGS">Wings</option><option value="PURA">Pura</option><option value="TNT">Tierion</option><option value="LBC">LBRY Credits</option><option value="TRAC">OriginTrail</option><option value="MOD">Modum</option><option value="OCN">Odyssey</option><option value="EVN">Envion</option><option value="QLC">QLINK</option><option value="XCP">Counterparty</option><option value="WGR">Wagerr</option><option value="BURST">Burst</option><option value="PRL">Oyster</option><option value="FTC">Feathercoin</option><option value="TRIG">Triggers</option><option value="DPY">Delphy</option><option value="FUEL">Etherparty</option><option value="ECA">Electra</option><option value="NLG">Gulden</option><option value="MLN">Melon</option><option value="DCT">DECENT</option><option value="SBD*">Steem Dollars</option><option value="MOBI">Mobius</option><option value="DAT">Datum</option><option value="PRE">Presearch</option><option value="XP">Experience Points</option><option value="TNC">Trinity Network Credit</option><option value="ZOI">Zoin</option><option value="TKN">TokenCard</option><option value="SOAR">Soarcoin</option><option value="ADT">adToken</option><option value="BCPT">BlockMason Credit Protocol</option><option value="TAAS">TaaS</option><option value="NGC">NAGA</option><option value="SXDT">Spectre.ai Dividend Token</option><option value="XBY">XTRABYTES</option><option value="CDT">Blox</option><option value="UTNP">Universa</option><option value="RKT">Rock</option><option value="ETP">Metaverse ETP</option><option value="SOC">All Sports</option><option value="COSS">COSS</option><option value="BITCNY">bitCNY</option><option value="SAFEX">Safe Exchange Coin</option><option value="BAX">BABB</option><option value="LET">LinkEye</option><option value="LGO">Legolas Exchange</option><option value="REN">Republic Protocol</option><option value="ZPT">Zeepin</option><option value="BKX">Bankex</option><option value="CSC">CasinoCoin</option><option value="QUN">QunQun</option><option value="XEL">Elastic</option><option value="KICK">KickCoin</option><option value="DATX">DATx</option><option value="UKG">Unikoin Gold</option><option value="BANCA">Banca</option><option value="ODE">ODEM</option><option value="RFR">Refereum</option><option value="TEN">Tokenomy</option><option value="VIB">Viberate</option><option value="GUP">Matchpool</option><option value="SHIFT">Shift</option><option value="XDCE">XinFin Network</option><option value="STK">STK</option><option value="YOYOW">YOYOW</option><option value="SHIP">ShipChain</option><option value="RVN">Ravencoin</option><option value="HAV">Havven</option><option value="XSH">SHIELD</option><option value="PRO">Propy</option><option value="DIME">Dimecoin</option><option value="HTML">HTMLCOIN</option><option value="CFI">Cofound.it</option><option value="TAU">Lamden</option><option value="PHR">Phore</option><option value="MER">Mercury</option><option value="AEON">Aeon</option><option value="CPC*">CPChain</option><option value="DAI">Dai</option><option value="HMQ">Humaniq</option><option value="ACAT">Alphacat</option><option value="ONION">DeepOnion</option><option value="AMP">Synereo</option><option value="LUN">Lunyr</option><option value="HST">Decision Token</option><option value="1ST">FirstBlood</option><option value="TIO">Trade Token</option><option value="SENT">Sentinel</option><option value="DMT">DMarket</option><option value="EKT">EDUCare</option><option value="UP">UpToken</option><option value="UGC">ugChain</option><option value="POT">PotCoin</option><option value="PEPECASH">Pepe Cash</option><option value="NMC">Namecoin</option><option value="TRST">WeTrust</option><option value="SENC">Sentinel Chain</option><option value="CRW">Crown</option><option value="UNO">Unobtanium</option><option value="DOCK">Dock</option><option value="AIDOC">AI Doctor</option><option value="FOTA">Fortuna</option><option value="COB">Cobinhood</option><option value="UUU">U Network</option><option value="ECC">ECC</option><option value="TIX">Blocktix</option><option value="MGO">MobileGo</option><option value="ZSC">Zeusshield</option><option value="EVX">Everex</option><option value="HMC">Hi Mutual Society</option><option value="IOC">I/O Coin</option><option value="SWFTC">SwftCoin</option><option value="MTH">Monetha</option><option value="XSN">StakeNet</option><option value="MSP">Mothership</option><option value="MWAT">Restart Energy MWAT</option><option value="BITB">Bean Cash</option><option value="SWH">Switcheo</option><option value="THC">HempCoin</option><option value="KEY">Selfkey</option><option value="LYM">Lympo</option><option value="BCA">Bitcoin Atom</option><option value="SNC">SunContract</option><option value="NMR">Numeraire</option><option value="TRUE">True Chain</option><option value="TSL">Energo</option><option value="ARN">Aeron</option><option value="MTN">Medicalchain</option><option value="DADI">DADI</option><option value="AIT">AICHAIN</option><option value="CAPP">Cappasity</option><option value="$PAC">PACcoin</option><option value="ORME">Ormeus Coin</option><option value="RNT">OneRoot Network</option><option value="DLT">Agrello</option><option value="PPY">Peerplays</option><option value="SPC">SpaceChain</option><option value="BLK">BlackCoin</option><option value="YEE">YEE</option><option value="DXT">Datawallet</option><option value="KRM">Karma</option><option value="ALQO">ALQO</option><option value="XPM">Primecoin</option><option value="CV">carVertical</option><option value="LEO">LEOcoin</option><option value="BOT">Bodhi</option><option value="MDA">Moeda Loyalty Points</option><option value="PASC">Pascal Coin</option><option value="BLT">Bloom</option><option value="DMD">Diamond</option><option value="RADS">Radium</option><option value="VRC">VeriCoin</option><option value="QBT*">Qbao</option><option value="OCT">OracleChain</option><option value="ATM">ATMChain</option><option value="OMNI">Omni</option><option value="GRID">Grid+</option><option value="MDT">Measurable Data Token</option><option value="RVR">RevolutionVR</option><option value="HOT">Hydro Protocol</option><option value="FLASH">Flash</option><option value="AXP">aXpire</option><option value="SIB">SIBCoin</option><option value="COV">Covesting</option><option value="FAIR">FairCoin</option><option value="GRC">GridCoin</option><option value="MTX">Matryx</option><option value="STQ">Storiqa</option><option value="LKK">Lykke</option><option value="POSW">PoSW Coin</option><option value="HVN">Hive Project</option><option value="CAT*">BitClave</option><option value="EDR">E-Dinar Coin</option><option value="OAX">OAX</option><option value="IDH">indaHash</option><option value="UQC">Uquid Coin</option><option value="PARETO">Pareto Network</option><option value="BBN">Banyan Network</option><option value="MEDIC">MedicCoin</option><option value="XWC">WhiteCoin</option><option value="LA">LATOKEN</option><option value="EVE">Devery</option><option value="TCT">TokenClub</option><option value="LUX">LUXCoin</option><option value="BPT">Blockport</option><option value="RMT">SureRemit</option><option value="ICOS">ICOS</option><option value="PRA">ProChain</option><option value="HKN">Hacken</option><option value="EXP">Expanse</option><option value="IXT">iXledger</option><option value="INCNT">Incent</option><option value="AURA">Aurora DAO</option><option value="TFD">TE-FOOD</option><option value="CHSB">SwissBorg</option><option value="PZM">PRIZM</option><option value="BMC">Blackmoon</option><option value="BIS">Bismuth</option><option value="TBAR">Titanium BAR</option><option value="SLT">Smartlands</option><option value="EKO">EchoLink</option><option value="FLO">FlorinCoin</option><option value="PLBT">Polybius</option><option value="NCT">PolySwarm</option><option value="SLR">SolarCoin</option><option value="SRCOIN">SRCOIN</option><option value="MUE">MonetaryUnit</option><option value="BERRY">Rentberry</option><option value="DIVX">Divi</option><option value="BBR">Boolberry</option><option value="BEE">Bee Token</option><option value="MOT">Olympus Labs</option><option value="COLX">ColossusXT</option><option value="STX">Stox</option><option value="ZAP">Zap</option><option value="BDG">BitDegree</option><option value="XMY">Myriad</option><option value="ARY">Block Array</option><option value="LMC">LoMoCoin</option><option value="SNOV">Snovio</option><option value="LINDA">Linda</option><option value="RISE">Rise</option><option value="RBY">Rubycoin</option><option value="SWM">Swarm</option><option value="BITUSD">bitUSD</option><option value="OK">OKCash</option><option value="XRL">Rialto</option><option value="BSD*">BitSend</option><option value="NLC2">NoLimitCoin</option><option value="DNA">EncrypGen</option><option value="DTB">Databits</option><option value="BITG">Bitcoin Green</option><option value="CLAM">Clams</option><option value="DEB">Debitum</option><option value="ENRG">Energycoin</option><option value="AUC">Auctus</option><option value="NEOS">NeosCoin</option><option value="IPBC">Interplanetary Broadcast Coin</option><option value="CAS">Cashaa</option><option value="XSPEC">Spectrecoin</option><option value="SWT">Swarm City</option><option value="XPA">XPA</option><option value="CXO">CargoX</option><option value="DICE">Etheroll</option><option value="FLDC">FoldingCoin</option><option value="PRG">Paragon</option><option value="NET*">Nimiq Exchange Token</option><option value="DIM">DIMCOIN</option><option value="ALIS">ALIS</option><option value="CVT">CyberVein</option><option value="FLUZ">Fluz Fluz</option><option value="PTOY">Patientory</option><option value="DRT">DomRaider</option><option value="GBX">GoByte</option><option value="NEU">Neumark</option><option value="DBET">DecentBet</option><option value="NXC">Nexium</option><option value="MOON">Mooncoin</option><option value="FLIXX">Flixxo</option><option value="MUSIC">Musicoin</option><option value="EVR">Everus</option><option value="CREDO">Credo</option><option value="QAU">Quantum</option><option value="HAT">Hat.Exchange</option><option value="GOLOS">Golos</option><option value="LALA">LALA World</option><option value="LOC">LockTrip</option><option value="TUSD">True USD</option><option value="BCC">BitConnect</option><option value="REM">Remme</option><option value="EFX">Effect.AI</option><option value="AIR">AirToken</option><option value="ART">Maecenas</option><option value="NYC">NewYorkCoin</option><option value="SYNX">Syndicate</option><option value="CAN">CanYaCoin</option><option value="IPSX">IP Exchange</option><option value="CHP">CoinPoker</option><option value="PST">Primas</option><option value="FTX">FintruX Network</option><option value="NPX">NaPoleonX</option><option value="BNTY">Bounty0x</option><option value="LDC">Leadcoin</option><option value="DBIX">DubaiCoin</option><option value="WRC">Worldcore</option><option value="GAM">Gambit</option><option value="WCT">Waves Community Token</option><option value="HWC">HollyWoodCoin</option><option value="OXY">Oxycoin</option><option value="COFI">CoinFi</option><option value="AUR">Auroracoin</option><option value="DTH">Dether</option><option value="MYST">Mysterium</option><option value="XLR">Solaris</option><option value="ATN">ATN</option><option value="CBT">CommerceBlock</option><option value="TCC">The ChampCoin</option><option value="HEAT">HEAT</option><option value="SIG">Spectiv</option><option value="DYN">Dynamic</option><option value="XST">Stealthcoin</option><option value="PLU">Pluton</option><option value="BQ">bitqy</option><option value="FDX">FidentiaX</option><option value="POLIS">Polis</option><option value="PFR">Payfair</option><option value="TX">TransferCoin</option><option value="AVT">Aventus</option><option value="INSTAR">Insights Network</option><option value="HXX">Hexx</option><option value="IFT">InvestFeed</option><option value="ESP">Espers</option><option value="ADB">adbank</option><option value="TIME">Chronobank</option><option value="IPL">InsurePal</option><option value="SPHR">Sphere</option><option value="GETX">Guaranteed Ethurance Token Extra</option><option value="TIPS">FedoraCoin</option><option value="CVCOIN">CVCoin</option><option value="PURE">Pure</option><option value="TOA">ToaCoin</option><option value="SEQ">Sequence</option><option value="ELIX">Elixir</option><option value="MINT">Mintcoin</option><option value="ATL">ATLANT</option><option value="PINK">PinkCoin</option><option value="DAN">Daneel</option><option value="ZLA">Zilla</option><option value="COVAL">Circuits of Value</option><option value="PUT*">Profile Utility Token</option><option value="PND">Pandacoin</option><option value="CLR">ClearCoin</option><option value="MYB">MyBit Token</option><option value="ATB">ATBCoin</option><option value="OPT">Opus</option><option value="BCY">Bitcrystals</option><option value="RVT">Rivetz</option><option value="TKS">Tokes</option><option value="EBST">eBoost</option><option value="XAUR">Xaurum</option><option value="IOP">Internet of People</option><option value="BLUE">BLUE</option><option value="XNK">Ink Protocol</option><option value="CURE">Curecoin</option><option value="BWK">Bulwark</option><option value="VOISE">Voise</option><option value="PKT">Playkey</option><option value="PBL">Publica</option><option value="HGT">HelloGold</option><option value="CAG">Change</option><option value="DOVU">Dovu</option><option value="GEO">GeoCoin</option><option value="LIFE">LIFE</option><option value="B2B">B2BX</option><option value="POLL">ClearPoll</option><option value="REBL">REBL</option><option value="ADH">AdHive</option><option value="UCASH">U.CASH</option><option value="NVC">Novacoin</option><option value="ABY">ArtByte</option><option value="GLA">Gladius Token</option><option value="GET">GET Protocol</option><option value="TRF">Travelflex</option><option value="HAC">Hackspace Capital</option><option value="KORE">Kore</option><option value="HQX">HOQU</option><option value="MSR">Masari</option><option value="ERO">Eroscoin</option><option value="XHV">Haven Protocol</option><option value="PRIX">Privatix</option><option value="VIT">Vice Industry Token</option><option value="SXUT">Spectre.ai Utility Token</option><option value="DOPE">DopeCoin</option><option value="SPF">SportyCo</option><option value="BRX">Breakout Stake</option><option value="CHIPS">CHIPS</option><option value="OBITS">OBITS</option><option value="NVST">NVO</option><option value="CSNO">BitDice</option><option value="LEV">Leverj</option><option value="GAT">Gatcoin</option><option value="VIU">Viuly</option><option value="EXRN">EXRNchain</option><option value="PIRL">Pirl</option><option value="PING">CryptoPing</option><option value="XBC">Bitcoin Plus</option><option value="IDXM">IDEX Membership</option><option value="DOT">Dotcoin</option><option value="BTCZ">BitcoinZ</option><option value="LOCI">LOCIcoin</option><option value="PTC">Pesetacoin</option><option value="MEME">Memetic / PepeCoin</option><option value="TFL">TrueFlip</option><option value="SPD">Stipend</option><option value="AID">AidCoin</option><option value="NKC">Nework</option><option value="NIO*">Autonio</option><option value="SEXC">ShareX</option><option value="APX">APX</option><option value="GLD">GoldCoin</option><option value="CAT">BlockCAT</option><option value="EXCL">ExclusiveCoin</option><option value="HYP">HyperStake</option><option value="ASTRO">Astro</option><option value="QWARK">Qwark</option><option value="ERC">EuropeCoin</option><option value="KB3">B3Coin</option><option value="MAX">MaxCoin</option><option value="TRCT">Tracto</option><option value="J8T">JET8</option><option value="INXT">Internxt</option><option value="DEV">DeviantCoin</option><option value="USNBT">NuBits</option><option value="HUSH">Hush</option><option value="SUMO">Sumokoin</option><option value="1WO">1World</option><option value="XNN">Xenon</option><option value="PLAY">HEROcoin</option><option value="SPR">SpreadCoin</option><option value="SPRTS">Sprouts</option><option value="SEND">Social Send</option><option value="LEDU">Education Ecosystem</option><option value="VTR">vTorrent</option><option value="ING">Iungo</option><option value="WISH">MyWish</option><option value="BTM">Bitmark</option><option value="UNIT">Universal Currency</option><option value="CANN">CannabisCoin</option><option value="AIX">Aigang</option><option value="BON">Bonpay</option><option value="VRM">VeriumReserve</option><option value="NTRN">Neutron</option><option value="CPAY">Cryptopay</option><option value="2GIVE">2GIVE</option><option value="MONK">Monkey Project</option><option value="EXY">Experty</option><option value="MNTP">GoldMint</option><option value="STAC">StarterCoin</option><option value="DNR">Denarius</option><option value="UFR">Upfiring</option><option value="BIO">BioCoin</option><option value="ADST">AdShares</option><option value="HORSE">Ethorse</option><option value="DRP">DCORP</option><option value="BTDX">Bitcloud</option><option value="CPY">COPYTRACK</option><option value="ZEIT">Zeitcoin</option><option value="BRK">Breakout</option><option value="PIX">Lampix</option><option value="OTN">Open Trading Network</option><option value="SETH">Sether</option><option value="FLAP">FlappyCoin</option><option value="RC">RussiaCoin</option><option value="ZRC">ZrCoin</option><option value="GCR">Global Currency Reserve</option><option value="CRB">Creditbit</option><option value="REF">RefToken</option><option value="BLITZ">Blitzcash</option><option value="RIC">Riecoin</option><option value="EZT">EZToken</option><option value="SWIFT">Bitswift</option><option value="STAR">Starbase</option><option value="MVC">Maverick Chain</option><option value="BET*">DAO.Casino</option><option value="KRB">Karbo</option><option value="SSS">Sharechain</option><option value="BPL">Blockpool</option><option value="UFO">Uniform Fiscal Object</option><option value="TRC">Terracoin</option><option value="SHP*">Sharpe Platform Token</option><option value="RUPX">Rupaya</option><option value="PBT">Primalbase Token</option><option value="XMCC">Monoeci</option><option value="EGC">EverGreenCoin</option><option value="ZER">Zero</option><option value="ADC">AudioCoin</option><option value="QRK">Quark</option><option value="AU">AurumCoin</option><option value="ODN">Obsidian</option><option value="REAL">REAL</option><option value="SCL">Sociall</option><option value="DGPT">DigiPulse</option><option value="CMPCO">CampusCoin</option><option value="BEZ">Bezop</option><option value="HUC">HunterCoin</option><option value="TRUST">TrustPlus</option><option value="PIPL">PiplCoin</option><option value="XGOX">XGOX</option><option value="BASH">LuckChain</option><option value="PYLNT">Pylon Network</option><option value="ZEPH">Zephyr</option><option value="FOR">FORCE</option><option value="CRED">Verify</option><option value="TIE">Ties.DB</option><option value="RUP">Rupee</option><option value="VZT">Vezt</option><option value="1337">Elite</option><option value="JIYO">Jiyo</option><option value="AMM">MicroMoney</option><option value="SXC">Sexcoin</option><option value="HIRE">HireMatch</option><option value="EVC">EventChain</option><option value="EFL">e-Gulden</option><option value="PUT">PutinCoin</option><option value="VSX">Vsync</option><option value="TZC">TrezarCoin</option><option value="ZNY">Bitzeny</option><option value="XMG">Magi</option><option value="CRAVE">Crave</option><option value="EQT">EquiTrader</option><option value="LINX">Linx</option><option value="ACE">Ace</option><option value="CHC">ChainCoin</option><option value="808">808Coin</option><option value="GCN">GCN Coin</option><option value="QVT">Qvolta</option><option value="GRFT">Graft</option><option value="ARG">Argentum</option><option value="UIS">Unitus</option><option value="GMT">Mercury Protocol</option><option value="MAG">Magnet</option><option value="SENSE">Sense</option><option value="FRD">Farad</option><option value="MTNC">Masternodecoin</option><option value="TBX">Tokenbox</option><option value="NOBL">NobleCoin</option><option value="TES">TeslaCoin</option><option value="CREA">Creativecoin</option><option value="XBP">BlitzPredict</option><option value="ITNS">IntenseCoin</option><option value="ESZ">EtherSportz</option><option value="CPC">Capricoin</option><option value="LDOGE">LiteDoge</option><option value="SMS">Speed Mining Service</option><option value="INN">Innova</option><option value="MXT">MarteXcoin</option><option value="EFYT">Ergo</option><option value="ELLA">Ellaism</option><option value="DP">DigitalPrice</option><option value="DAY">Chronologic</option><option value="SMLY">SmileyCoin</option><option value="FYN">FundYourselfNow</option><option value="KZC">Kzcash</option><option value="WAND">WandX</option><option value="NKA">IncaKoin</option><option value="CDN">Canada eCoin</option><option value="HOLD">Interstellar Holdings</option><option value="EMV">Ethereum Movie Venture</option><option value="CL">Coinlancer</option><option value="EBTC">eBitcoin</option><option value="RAIN">Condensate</option><option value="UNB">UnbreakableCoin</option><option value="BTW">BitWhite</option><option value="BUN">BunnyCoin</option><option value="KEK">KekCoin</option><option value="STAK">STRAKS</option><option value="BBP">BiblePay</option><option value="IC">Ignition</option><option value="ANC">Anoncoin</option><option value="LNC">Blocklancer</option><option value="ALT">Altcoin</option><option value="ORB">Orbitcoin</option><option value="YOC">Yocoin</option><option value="ONG">onG.social</option><option value="BUZZ">BuzzCoin</option><option value="AHT">Bowhead</option><option value="KOBO">Kobocoin</option><option value="ETBS">Ethbits</option><option value="IND">Indorse Token</option><option value="SAGA">SagaCoin</option><option value="TIG">Tigereum</option><option value="LATX">LatiumX</option><option value="XFT">Footy Cash</option><option value="OCC">Octoin Coin</option><option value="SKIN">SkinCoin</option><option value="ELTCOIN">ELTCOIN</option><option value="TDX">Tidex Token</option><option value="FRST">FirstCoin</option><option value="ACC*">Accelerator Network</option><option value="GPU">GPU Coin</option><option value="MRJA">GanjaCoin</option><option value="OCL">Oceanlab</option><option value="ARC">ArcticCoin</option><option value="CARBON">Carboncoin</option><option value="DEM">Deutsche eMark</option><option value="BYC">Bytecent</option><option value="MCAP">MCAP</option><option value="NMS">Numus</option><option value="LGD">Legends Room</option><option value="42">42-coin</option><option value="DFS">DFSCoin</option><option value="LOG">Woodcoin</option><option value="SNRG">Synergy</option><option value="MOIN">Moin</option><option value="VULC">Vulcano</option><option value="MRT">Miners' Reward Token</option><option value="VIVO">VIVO</option><option value="JEW">Shekel</option><option value="SKC">Skeincoin</option><option value="GCC*">Global Cryptocurrency</option><option value="ADZ">Adzcoin</option><option value="FUNK">The Cypherfunks</option><option value="GJC">Global Jobcoin</option><option value="MZC">MAZA</option><option value="CTR">Centra</option><option value="MEC">Megacoin</option><option value="ORE">Galactrum</option><option value="XPTX">PlatinumBAR</option><option value="DEUS">DeusCoin</option><option value="DFT">DraftCoin</option><option value="PCN">PeepCoin</option><option value="BRIT">BritCoin</option><option value="BTA">Bata</option><option value="UNIFY">Unify</option><option value="ZET">Zetacoin</option><option value="EPY">Emphy</option><option value="STU">bitJob</option><option value="DCY">Dinastycoin</option><option value="NETKO">Netko</option><option value="GUN">Guncoin</option><option value="MAGE">MagicCoin</option><option value="XLC">LeviarCoin</option><option value="NSR">NuShares</option><option value="FCN">Fantomcoin</option><option value="CRC*">CrowdCoin</option><option value="DRPU">DRP Utility</option><option value="FJC">FujiCoin</option><option value="ECASH">Ethereum Cash</option><option value="KLN">Kolion</option><option value="MBRS">Embers</option><option value="PROC">ProCurrency</option><option value="REC">Regalcoin</option><option value="BSM">Bitsum</option><option value="ICOO">ICO OpenLedger</option><option value="START">Startcoin</option><option value="EQL">Equal</option><option value="XPD">PetroDollar</option><option value="WILD">Wild Crypto</option><option value="QBIC">Qbic</option><option value="MBI">Monster Byte</option><option value="CCRB">CryptoCarbon</option><option value="HERO">Sovereign Hero</option><option value="ATS">Authorship</option><option value="IFLT">InflationCoin</option><option value="GRWI">Growers International</option><option value="BTWTY">Bit20</option><option value="MAC">Machinecoin</option><option value="HBN">HoboNickels</option><option value="SCT">Soma</option><option value="CCT">Crystal Clear </option><option value="ESC">Escroco</option><option value="IETH">iEthereum</option><option value="HPC">Happycoin</option><option value="SUR">Suretly</option><option value="CRM">Cream</option><option value="ACC">AdCoin</option><option value="JET">Jetcoin</option><option value="INSN">InsaneCoin</option><option value="ARCT">ArbitrageCT</option><option value="LCP">Litecoin Plus</option><option value="ITI">iTicoin</option><option value="PHO">Photon</option><option value="VOT">VoteCoin</option><option value="EBET">EthBet</option><option value="MNE">Minereum</option><option value="BTB">BitBar</option><option value="RBT">Rimbit</option><option value="FST">Fastcoin</option><option value="XCPO">Copico</option><option value="BTG*">Bitgem</option><option value="PXC">Phoenixcoin</option><option value="TTC">TittieCoin</option><option value="LANA">LanaCoin</option><option value="ARCO">AquariusCoin</option><option value="GRLC">Garlicoin</option><option value="WHL">WhaleCoin</option><option value="XCN">Cryptonite</option><option value="ERC20">ERC20</option><option value="BDL">Bitdeal</option><option value="KUSH">KushCoin</option><option value="VRS">Veros</option><option value="SCORE">Scorecoin</option><option value="DRXNE">DROXNE</option><option value="ITT">Intelligent Trading Foundation</option><option value="SGR">Sugar Exchange</option><option value="TOK">Tokugawa</option><option value="SDRN">Senderon</option><option value="MOJO">MojoCoin</option><option value="MAO">Mao Zedong</option><option value="VIDZ">PureVidz</option><option value="IRL">IrishCoin</option><option value="RLT">RouletteToken</option><option value="XBL">Billionaire Token</option><option value="PLC">PlusCoin</option><option value="ELE">Elementrem</option><option value="SLG">Sterlingcoin</option><option value="KBR">Kubera Coin</option><option value="SCS">Speedcash</option><option value="BITSILVER">bitSilver</option><option value="BLC">Blakecoin</option><option value="MANNA">Manna</option><option value="TRUMP">TrumpCoin</option><option value="TEK">TEKcoin</option><option value="DAXX">DaxxCoin</option><option value="PAK">Pakcoin</option><option value="BTCA">Bitair</option><option value="STN*">Steneum Coin</option><option value="CJ">Cryptojacks</option><option value="CTX">CarTaxi Token</option><option value="BTCRED">Bitcoin Red</option><option value="CAB">Cabbage</option><option value="MNM">Mineum</option><option value="GRN">Granite</option><option value="AERM">Aerium</option><option value="GOLF">Golfcoin</option><option value="GUESS">Peerguess</option><option value="SRC">SecureCoin</option><option value="OPC">OP Coin</option><option value="WGO">WavesGo</option><option value="POST">PostCoin</option><option value="BCF">Bitcoin Fast</option><option value="XCXT">CoinonatX</option><option value="DMB">Digital Money Bits</option><option value="ZCG">Zlancer</option><option value="ONX">Onix</option><option value="CNT">Centurion</option><option value="GAP">Gapcoin</option><option value="DIX">Dix Asset</option><option value="CESC">CryptoEscudo</option><option value="ETG">Ethereum Gold</option><option value="BITGOLD">bitGold</option><option value="HNC">Helleniccoin</option><option value="CCN">CannaCoin</option><option value="TOKC">TOKYO</option><option value="ATOM">Atomic Coin</option><option value="OTX">Octanox</option><option value="PASL">Pascal Lite</option><option value="BIGUP">BigUp</option><option value="PLC*">Polcoin</option><option value="LTB">LiteBar</option><option value="LEA">LeaCoin</option><option value="SHND">StrongHands</option><option value="IMX">Impact</option><option value="ABJ">Abjcoin</option><option value="NRO">Neuro</option><option value="300">300 Token</option><option value="NUKO">Nekonium</option><option value="CUBE">DigiCube</option><option value="BTPL">Bitcoin Planet</option><option value="RED">RedCoin</option><option value="PXI">Prime-XI</option><option value="ECO">EcoCoin</option><option value="SWING">Swing</option><option value="MCRN">MACRON</option><option value="C2">Coin2.1</option><option value="XRE">RevolverCoin</option><option value="SHDW">Shadow Token</option><option value="XCO">X-Coin</option><option value="NTO">Fujinto</option><option value="REE">ReeCoin</option><option value="BOST">BoostCoin</option><option value="LBTC">LiteBitcoin</option><option value="HVCO">High Voltage</option><option value="611">SixEleven</option><option value="ETHD">Ethereum Dark</option><option value="SFC">Solarflarecoin</option><option value="FUNC">FUNCoin</option><option value="TAJ">TajCoin</option><option value="VPRC">VapersCoin</option><option value="MAY">Theresa May Coin</option><option value="GTC*">Global Tour Coin</option><option value="HBC">HomeBlockCoin</option><option value="SOON">SoonCoin</option><option value="DSR">Desire</option><option value="TRDT">Trident Group</option><option value="BITEUR">bitEUR</option><option value="BRAT">BROTHER</option><option value="NEWB">Newbium</option><option value="EAGLE">EagleCoin</option><option value="COAL">BitCoal</option><option value="CMT*">Comet</option><option value="VUC">Virta Unique Coin</option><option value="XHI">HiCoin</option><option value="FLAX">Flaxscript</option><option value="CRX">Chronos</option><option value="PCOIN">Pioneer Coin</option><option value="ERY">Eryllium</option><option value="BIP">BipCoin</option><option value="GP">GoldPieces</option><option value="ITZ">Interzone</option><option value="KRONE">Kronecoin</option><option value="CNNC">Cannation</option><option value="ADCN">Asiadigicoin</option><option value="UET">Useless Ethereum Token</option><option value="QCN">QuazarCoin</option><option value="ZMC">ZetaMicron</option><option value="MSCN">Master Swiscoin</option><option value="LTCU">LiteCoin Ultra</option><option value="RKC">Royal Kingdom Coin</option><option value="LUNA">Luna Coin</option><option value="GBC">GBCGoldCoin</option><option value="SANDG">Save and Gain</option><option value="CRDNC">Credence Coin</option><option value="PRC">PRCoin</option><option value="ACP">AnarchistsPrime</option><option value="WOMEN">WomenCoin</option><option value="NANOX">Project-X</option><option value="COUPE">Coupecoin</option><option value="HMC*">HarmonyCoin</option><option value="PIZZA">PizzaCoin</option><option value="CALC">CaliphCoin</option><option value="GRE">Greencoin</option><option value="XTO">Tao</option><option value="HDG">Hedge</option><option value="MUSE">MUSE</option><option value="TGT">Target Coin</option><option value="ECOB">Ecobit</option><option value="RMC">Russian Miner Coin</option><option value="HBT">Hubii Network</option><option value="AC">AsiaCoin</option><option value="KLC">KiloCoin</option><option value="GOOD">Goodomy</option><option value="ECN">E-coin</option><option value="ETT">EncryptoTel [WAVES]</option><option value="VSL">vSlice</option><option value="IXC">Ixcoin</option><option value="STA">Starta</option><option value="REX">imbrex</option><option value="CBX">Bullion</option><option value="DAR">Darcrus</option><option value="TRIA">Triaconta</option><option value="NOTE">DNotes</option><option value="INPAY">InPay</option><option value="BLU">BlueCoin</option><option value="LEAF">LeafCoin</option><option value="FLIK">FLiK</option><option value="BBT">BitBoost</option><option value="WDC">WorldCoin</option><option value="FYP">FlypMe</option><option value="JC">Jesus Coin</option><option value="UNIC">UniCoin</option><option value="SHORTY">Shorty</option><option value="FLT">FlutterCoin</option><option value="V">Version</option><option value="UNI">Universe</option><option value="POP">PopularCoin</option><option value="I0C">I0Coin</option><option value="NDC">NEVERDIE</option><option value="FUCK">FuckToken</option><option value="ZENI">Zennies</option><option value="HTC">HitCoin</option><option value="SDC">ShadowCash</option><option value="CDX">Commodity Ad Network</option><option value="RNS">Renos</option><option value="STRC">StarCredits</option><option value="METAL">MetalCoin</option><option value="RIYA">Etheriya</option><option value="BPC">Bitpark Coin</option><option value="NET">NetCoin</option><option value="BXT">BitTokens</option><option value="PIGGY">Piggycoin</option><option value="DGC">Digitalcoin</option><option value="BRO">Bitradio</option><option value="BITS">Bitstar</option><option value="TRI">Triangles</option><option value="OPAL">Opal</option><option value="USC">Ultimate Secure Cash</option><option value="TROLL">Trollcoin</option><option value="Q2C">QubitCoin</option><option value="VTA">Virtacoin</option><option value="BLZ*">BlazeCoin</option><option value="BTCS">Bitcoin Scrypt</option><option value="HODL">HOdlcoin</option><option value="TIT">Titcoin</option><option value="BITBTC">bitBTC</option><option value="KURT">Kurrent</option><option value="GAIA">GAIA</option><option value="NYAN">Nyancoin</option><option value="TAG">TagCoin</option><option value="TALK">BTCtalkcoin</option><option value="ARI">Aricoin</option><option value="DSH">Dashcoin</option><option value="HAL">Halcyon</option><option value="MOTO">Motocoin</option><option value="EBCH">eBitcoinCash</option><option value="BUCKS">SwagBucks</option><option value="UTC">UltraCoin</option><option value="FLY">Flycoin</option><option value="SMC">SmartCoin</option><option value="TRK">Truckcoin</option><option value="XPY">PayCoin</option><option value="RPC">RonPaulCoin</option><option value="NXX">Nexxus</option><option value="ISL">IslaCoin</option><option value="SUPER">SuperCoin</option><option value="XJO">Joulecoin</option><option value="GB">GoldBlocks</option><option value="PR">Prototanium</option><option value="CASH">Cashcoin</option><option value="EVIL">Evil Coin</option><option value="8BIT">8Bit</option><option value="BLOCKPAY">BlockPay</option><option value="MAD*">SatoshiMadness</option><option value="BOLI">Bolivarcoin</option><option value="TSE">Tattoocoin (Standard Edition)</option><option value="DDF">DigitalDevelopersFund</option><option value="TKR">CryptoInsight</option><option value="PHS">Philosopher Stones</option><option value="VISIO">Visio</option><option value="TGC">Tigercoin</option><option value="CHESS">ChessCoin</option><option value="AMBER">AmberCoin</option><option value="ENT">Eternity</option><option value="CNO">Coin(O)</option><option value="BITZ">Bitz</option><option value="CYP">Cypher</option><option value="FRC">Freicoin</option><option value="XRA">Ratecoin</option><option value="GRIM">Grimcoin</option><option value="XCT">C-Bit</option><option value="EMD">Emerald Crypto</option><option value="MARS">Marscoin</option><option value="ICN*">iCoin</option><option value="NEVA">NevaCoin</option><option value="SPEX">SproutsExtreme</option><option value="INFX">Influxcoin</option><option value="CHAN">ChanCoin</option><option value="AMMO">Ammo Reloaded</option><option value="PX">PX</option><option value="BTCR">Bitcurrency</option><option value="SPACE">SpaceCoin</option><option value="BERN">BERNcash</option><option value="888">OctoCoin</option><option value="DTC">Datacoin</option><option value="QBC">Quebecoin</option><option value="KED">Darsek</option><option value="CTO">Crypto</option><option value="LCT">LendConnect</option><option value="SIGT">Signatum</option><option value="XIOS">Xios</option><option value="GLT">GlobalToken</option><option value="UNITS">GameUnits</option><option value="B@">Bankcoin</option><option value="RBIES">Rubies</option><option value="IMS">Independent Money System</option><option value="VC">VirtualCoin</option><option value="GLC">GlobalCoin</option><option value="ZUR">Zurcoin</option><option value="FNC">FinCoin</option><option value="AMS">AmsterdamCoin</option><option value="QTL">Quatloo</option><option value="PNX">Phantomx</option><option value="CAT**">Catcoin</option><option value="CCO">Ccore</option><option value="DUO">ParallelCoin</option><option value="MST">MustangCoin</option><option value="PKB">ParkByte</option><option value="BSTY">GlobalBoost-Y</option><option value="FIRE">Firecoin</option><option value="STV">Sativacoin</option><option value="YAC">Yacoin</option><option value="BUMBA">BumbaCoin</option><option value="AIB">Advanced Internet Blocks</option><option value="JIN">Jin Coin</option><option value="HONEY">Honey</option><option value="SCRT">SecretCoin</option><option value="XVP">Virtacoinplus</option><option value="DRS">Digital Rupees</option><option value="EVO">Evotion</option><option value="ELC">Elacoin</option><option value="ICOB">ICOBID</option><option value="EL">Elcoin</option><option value="CON">PayCon</option><option value="XBTS">Beatcoin</option><option value="GCC">GuccioneCoin</option><option value="XNG">Enigma</option><option value="HMP">HempCoin</option><option value="XBTC21">Bitcoin 21</option><option value="DLC">Dollarcoin</option><option value="BRIA">BriaCoin</option><option value="$$$">Money</option><option value="BTQ">BitQuark</option><option value="YTN">YENTEN</option><option value="XCRE">Creatio</option><option value="DALC">Dalecoin</option><option value="EUC">Eurocoin</option><option value="ACOIN">Acoin</option><option value="FUZZ">FuzzBalls</option><option value="GLS">GlassCoin</option><option value="CACH">CacheCoin</option><option value="MNC">Mincoin</option><option value="SOIL">SOILcoin</option><option value="BLN">Bolenum</option><option value="BENJI">BenjiRolls</option><option value="NTWK">Network Token</option><option value="MDC">Madcoin</option><option value="AGLC">AgrolifeCoin</option><option value="BLRY">BillaryCoin</option><option value="J">Joincoin</option><option value="CPN">CompuCoin</option><option value="STARS">StarCash Network</option><option value="CXT">Coinonat</option><option value="DBTC">Debitcoin</option><option value="ALL*">Allion</option><option value="ROOFS">Roofs</option><option value="ASAFE2">AllSafe</option><option value="CF">Californium</option><option value="BAS">BitAsean</option><option value="MAR">Marijuanacoin</option><option value="RIDE">Ride My Car</option><option value="MTLMC3">Metal Music Coin</option><option value="GPL">Gold Pressed Latinum</option><option value="SONG">SongCoin</option><option value="ZZC">ZoZoCoin</option><option value="WARP">WARP</option><option value="SH">Shilling</option><option value="BNX">BnrtxCoin</option><option value="MND">MindCoin</option><option value="RBX">Ripto Bux</option><option value="BXC">Bitcedi</option><option value="BSTAR">Blackstar</option><option value="ZYD">Zayedcoin</option><option value="URO">Uro</option><option value="PRX">Printerium</option><option value="VIP">VIP Tokens</option><option value="ATX">Artex Coin</option><option value="WORM">HealthyWormCoin</option><option value="KNC*">KingN Coin</option><option value="JWL">Jewels</option><option value="SLEVIN">Slevin</option><option value="POS">PoSToken</option><option value="DRM">Dreamcoin</option><option value="MILO">MiloCoin</option><option value="ICON">Iconic</option><option value="PONZI">PonziCoin</option><option value="DLISK">DAPPSTER</option><option value="EXN">ExchangeN</option><option value="PIE">PIECoin</option><option value="BSC">BowsCoin</option><option value="LTCR">Litecred</option><option value="GEERT">GeertCoin</option><option value="VLT">Veltor</option><option value="BIOS">BiosCrypto</option><option value="PULSE">Pulse</option><option value="STEPS">Steps</option><option value="LIR">LetItRide</option><option value="ARB">ARbit</option><option value="IMPS">ImpulseCoin</option><option value="BOAT">BOAT</option><option value="ZNE">Zonecoin</option><option value="JS">JavaScript Token</option><option value="PLACO">PlayerCoin</option><option value="VEC2">VectorAI</option><option value="WBB">Wild Beast Block</option><option value="CWXT">CryptoWorldX Token</option><option value="OFF">Cthulhu Offerings</option><option value="SDP">SydPak</option><option value="DES">Destiny</option><option value="RSGP">RSGPcoin</option><option value="TAGR">TAGRcoin</option><option value="OS76">OsmiumCoin</option><option value="PLNC">PLNcoin</option><option value="TOR">Torcoin</option><option value="VOLT">Bitvolt</option><option value="PEX">PosEx</option><option value="JOBS">JobsCoin</option><option value="ARGUS">Argus</option><option value="DOLLAR">Dollar Online</option><option value="CTIC3">Coimatic 3.0</option><option value="XRC">Rawcoin</option><option value="P7C">P7Coin</option><option value="BIOB">BioBar</option><option value="IBANK">iBank</option><option value="CREVA">CrevaCoin</option><option value="ELS">Elysium</option><option value="SOCC">SocialCoin</option><option value="CONX">Concoin</option><option value="SLFI">Selfiecoin</option><option value="NODC">NodeCoin</option><option value="MGM">Magnum</option><option value="GSR">GeyserCoin</option><option value="CTIC2">Coimatic 2.0</option><option value="ULA">Ulatech</option><option value="VLTC">Vault Coin</option><option value="LVPS">LevoPlus</option><option value="TSTR">Tristar Coin</option><option value="FXE">FuturXe</option><option value="DGCS">Digital Credits</option><option value="EBT">Ebittree Coin</option><option value="AI">POLY AI</option><option value="CKUSD">CK USD</option><option value="OC">OceanChain</option><option value="WIC*">WaykiChain</option><option value="XMC">Monero Classic</option><option value="MOAC">MOAC</option><option value="IQT">iQuant</option><option value="SBTC">Super Bitcoin</option><option value="KCASH">Kcash</option><option value="CAN*">Content and AD Network</option><option value="STC">StarChain</option><option value="NOAH">Noah Coin</option><option value="MEET">CoinMeet</option><option value="EPC">Electronic PK Chain</option><option value="BCX">BitcoinX</option><option value="CHAT">ChatCoin</option><option value="AAC">Acute Angle Cloud</option><option value="ATMC">ATMCoin</option><option value="DRG">Dragon Coins</option><option value="MOF">Molecular Future</option><option value="XMO">Monero Original</option><option value="SHOW">Show</option><option value="FAIR*">FairGame</option><option value="CMS">COMSA [ETH]</option><option value="RCT">RealChain</option><option value="BFT">BnkToTheFuture</option><option value="BSTN">BitStation</option><option value="GEM">Gems </option><option value="TOPC">TopChain</option><option value="FIL">Filecoin [Futures]</option><option value="OF">OFCOIN</option><option value="UBTC">United Bitcoin</option><option value="LIGHT">LightChain</option><option value="AWR">AWARE</option><option value="KST">StarCoin</option><option value="XUC">Exchange Union</option><option value="NTK">Neurotoken</option><option value="VLC">ValueChain</option><option value="CMS*">COMSA [XEM]</option><option value="FRGC">Fargocoin</option><option value="XTZ">Tezos (Pre-Launch)</option><option value="MAG*">Maggie</option><option value="SSC">SelfSell</option><option value="BCDN">BlockCDN</option><option value="LBTC*">Lightning Bitcoin [Futures]</option><option value="WETH">WETH</option><option value="SCC">StockChain</option><option value="HLC">HalalChain</option><option value="IPC">IPChain</option><option value="ATC">Arbitracoin</option><option value="AMLT">AMLT Token</option><option value="FID">Fidelium</option><option value="EARTH">Earth Token</option><option value="PRS">PressOne</option><option value="EOSDAC">eosDAC</option><option value="QUBE">Qube</option><option value="BIG">BigONE Token</option><option value="DIG">Dignity</option><option value="MRK">MARK.SPACE</option><option value="UIP">UnlimitedIP</option><option value="ADK">Aidos Kuneen</option><option value="ADI">Aditus</option><option value="CFUN">CFun</option><option value="AVH">Animation Vision Cash</option><option value="READ">Read</option><option value="BBI">BelugaPay</option><option value="WC">WINCOIN</option><option value="XIN*">Infinity Economics</option><option value="CVH">Curriculum Vitae</option><option value="SBC">StrikeBitClub</option><option value="BRM">BrahmaOS</option><option value="TDS">TokenDesk</option><option value="CHX">Chainium</option><option value="CROP">Cropcoin</option><option value="XTL">Stellite</option><option value="XOT">Internet of Things</option><option value="SEN">Consensus</option><option value="CANDY">Candy</option><option value="IDT">InvestDigital</option><option value="GCS">GameChain System</option><option value="XID">Sphre AIR </option><option value="ECH">Etherecash</option><option value="BT2">BT2 [CST]</option><option value="SWTC">Jingtum Tech</option><option value="HPY">Hyper Pay</option><option value="GBG">Golos Gold</option><option value="DERO">Dero</option><option value="WIN">WCOIN</option><option value="GOD">Bitcoin God</option><option value="ANI">Animecoin</option><option value="B2X">SegWit2x</option><option value="SNIP">SnipCoin</option><option value="MLM">MktCoin</option><option value="BUBO">Budbo</option><option value="BELA">Bela</option><option value="SIC">Swisscoin</option><option value="ABC">Alphabit</option><option value="PCS">Pabyosi Coin (Special)</option><option value="BSR">BitSoar</option><option value="MSD">MSD</option><option value="XSTC">Safe Trade Coin</option><option value="FDZ">Friendz</option><option value="APC">AlpaCoin</option><option value="IFC">Infinitecoin</option><option value="GRMD">GreenMed</option><option value="EMB">EmberCoin</option><option value="PHI">PHI Token</option><option value="PCL">Peculium</option><option value="ACC**">ACChain</option><option value="MFG">SyncFab</option><option value="LST">Lendroid Support Token</option><option value="BAR">Titanium Blockchain</option><option value="W3C">W3Coin</option><option value="ENT*">ENTCash</option><option value="XID*">International Diamond</option><option value="CLUB">ClubCoin</option><option value="DUTCH">Dutch Coin</option><option value="CEFS">CryptopiaFeeShares</option><option value="OX">OX Fina</option><option value="SPK">Sparks</option><option value="EDRC">EDRCoin</option><option value="WA">WA Space</option><option value="NOX">Nitro</option><option value="HDLB">HODL Bucks</option><option value="UTT">United Traders Token</option><option value="EDT">EtherDelta Token</option><option value="CLD">Cloud</option><option value="MCR">Macro</option><option value="SLOTH">Slothcoin</option><option value="COR">CORION</option><option value="MARX">MarxCoin</option><option value="PRES">President Trump</option><option value="RBBT">RabbitCoin</option><option value="NAMO">NamoCoin</option><option value="MCI">Musiconomi</option><option value="ERA">ERA</option><option value="SONO">SONO</option><option value="HIGH">High Gain</option><option value="XRY">Royalties</option><option value="BET">BetaCoin</option><option value="SIGMA">SIGMAcoin</option><option value="HC">Harvest Masternode Coin</option><option value="INDI">Indicoin</option><option value="ZBC">Zilbercoin</option><option value="TLE">Tattoocoin (Limited Edition)</option><option value="EAG">EA Coin</option><option value="ZENGOLD">ZenGold</option><option value="TESLA">TeslaCoilCoin</option><option value="FUTC">FutCoin</option><option value="FRN">Francs</option><option value="BTCM">BTCMoon</option><option value="ROYAL">RoyalCoin</option><option value="NUMUS">NumusCash</option><option value="DON">Donationcoin</option><option value="PRN">Protean</option><option value="TER">TerraNova</option><option value="RYZ">ANRYZE</option><option value="LDCN">LandCoin</option><option value="SJW">SJWCoin</option><option value="GDC">GrandCoin</option><option value="CYDER">Cyder</option><option value="MBL">MobileCash</option><option value="BITCF">First Bitcoin Capital</option><option value="GAIN">UGAIN</option><option value="DAV">DavorCoin</option><option value="PLX">PlexCoin</option><option value="ELITE">Ethereum Lite</option><option value="CHEAP">Cheapcoin</option><option value="UNRC">UniversalRoyalCoin</option><option value="SJCX">Storjcoin X</option><option value="SKR">Sakuracoin</option><option value="HYPER">Hyper</option><option value="AV">AvatarCoin</option><option value="TURBO">TurboCoin</option><option value="TOPAZ">Topaz Coin</option><option value="ETT*">EncryptoTel [ETH]</option><option value="BLAZR">BlazerCoin</option><option value="TELL">Tellurion</option><option value="TCOIN">T-coin</option><option value="DMC">DynamicCoin</option><option value="WINK">Wink</option><option value="QBT">Cubits</option><option value="BIT">First Bitcoin</option><option value="MINEX">Minex</option><option value="GAY">GAY Money</option><option value="CME">Cashme</option><option value="HNC*">Huncoin</option><option value="GRX">GOLD Reward Token</option><option value="BTE">BitSerial</option><option value="BUB">Bubble</option><option value="SHA">SHACoin</option><option value="BEST">BestChain</option><option value="GMX">GoldMaxCoin</option><option value="POKE">PokeCoin</option><option value="SUP">Superior Coin</option><option value="XTD">XTD Coin</option><option value="HALLO">Halloween Coin</option><option value="RUNNERS">Runners</option><option value="ANTX">Antimatter</option><option value="KDC">KlondikeCoin</option><option value="WIC">Wi Coin</option><option value="LEVO">Levocoin</option><option value="UNITY">SuperNET</option><option value="SMOKE">Smoke</option><option value="UNC">UNCoin</option><option value="PRIMU">Primulon</option><option value="NEOG">NEO GOLD</option><option value="CFC">CoffeeCoin</option><option value="RICHX">RichCoin</option><option value="BAT*">BatCoin</option><option value="OP">Operand</option><option value="GARY">President Johnson</option><option value="RHFC">RHFCoin</option><option value="MAGN">Magnetcoin</option><option value="INDIA">India Coin</option><option value="UR">UR</option><option value="WSX">WeAreSatoshi</option><option value="AKY">Akuya Coin</option><option value="ZSE">ZSEcoin</option><option value="BTBc">Bitbase</option><option value="KARMA">Karmacoin</option><option value="XQN">Quotient</option><option value="TODAY">TodayCoin</option><option value="AXIOM">Axiom</option><option value="RCN*">Rcoin</option><option value="STEX">STEX</option><option value="CC">CyberCoin</option><option value="BSN">Bastonet</option><option value="NBIT">netBit</option><option value="ACES">Aces</option><option value="RUBIT">RubleBit</option><option value="DASHS">Dashs</option><option value="FONZ">Fonziecoin</option><option value="DBG">Digital Bullion Gold</option><option value="LEPEN">LePen</option><option value="SKULL">Pirate Blocks</option><option value="SISA">SISA</option><option value="LKC">LinkedCoin</option><option value="MONETA">Moneta</option><option value="SAK">Sharkcoin</option><option value="PSY">Psilocybin</option><option value="FAP">FAPcoin</option><option value="FAZZ">Fazzcoin</option><option value="REGA">Regacoin</option><option value="CYC">Cycling Coin</option><option value="DCRE">DeltaCredits</option><option value="SPORT">SportsCoin</option><option value="TRICK">TrickyCoin</option><option value="X2">X2</option><option value="SHELL">ShellCoin</option><option value="OPES">Opescoin</option><option value="PAYP">PayPeer</option><option value="HCC">Happy Creator Coin</option><option value="FRWC">FrankyWillCoin</option><option value="KASHH">KashhCoin</option><option value="BITOK">Bitok</option><option value="TCR">TheCreed</option><option value="DISK">DarkLisk</option><option value="OMC">Omicron</option><option value="EGG">EggCoin</option><option value="LAZ">Lazaruscoin</option><option value="GML">GameLeagueCoin</option><option value="PRM">PrismChain</option><option value="BIRDS">Birds</option><option value="THS">TechShares</option><option value="ACN">Avoncoin</option><option value="QORA">Qora</option><option value="TOP*">TopCoin</option><option value="CRYPT">CryptCoin</option><option value="ASN">Aseancoin</option><option value="EREAL">eREAL</option><option value="XVC">Vcash</option><option value="UGT">UG Token</option><option value="FRCT">Farstcoin</option></select>    </div>
</div>

<nav id="top-menu" class="ui borderless fluid fixed menu">
    
        <a id="sidebar-menu-toggle" class="item"><i class="sidebar icon"></i></a>
        <a href="../index.html" class="brand item"><img id="header-logo" src="../images/1524688786.png"></a>        <div class="right menu">
            <a class="item menu-item" href="../market.html">Market</a><a class="item menu-item" href="../converter.html">Converter</a><a class="item menu-item" href="../icos.html">ICOs</a><a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/"><i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg"><i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/"><i class="instagram icon"></i></a>            <div class="price-currency-item item">
                <select class="price-currency  ui search dropdown"><option value="BTC">Bitcoin</option><option selected value="USD">US Dollar</option><option value="EUR">Eurozone Euro</option><option value="GBP">Pound Sterling</option><option value="JPY">Japanese Yen</option><option value="CAD">Canadian Dollar</option><option value="AUD">Australian Dollar</option><option value="CNY">Chinese Yuan</option><option value="CHF">Swiss Franc</option><option value="SEK">Swedish Krona</option><option value="NZD">New Zealand Dollar</option><option value="KRW">South Korean Won</option><option value="AED">UAE Dirham</option><option value="AFN">Afghan Afghani</option><option value="ALL">Albanian Lek</option><option value="AMD">Armenian Dram</option><option value="ANG">Netherlands Antillean Guilder</option><option value="AOA">Angolan Kwanza</option><option value="ARS">Argentine Peso</option><option value="AWG">Aruban Florin</option><option value="AZN">Azerbaijani Manat</option><option value="BAM">Bosnia-Herzegovina Convertible Mark</option><option value="BBD">Barbadian Dollar</option><option value="BDT">Bangladeshi Taka</option><option value="BGN">Bulgarian Lev</option><option value="BHD">Bahraini Dinar</option><option value="BIF">Burundian Franc</option><option value="BMD">Bermudan Dollar</option><option value="BND">Brunei Dollar</option><option value="BOB">Bolivian Boliviano</option><option value="BRL">Brazilian Real</option><option value="BSD">Bahamian Dollar</option><option value="BTN">Bhutanese Ngultrum</option><option value="BWP">Botswanan Pula</option><option value="BZD">Belize Dollar</option><option value="CDF">Congolese Franc</option><option value="CLF">Chilean Unit of Account (UF)</option><option value="CLP">Chilean Peso</option><option value="COP">Colombian Peso</option><option value="CRC">Costa Rican Colón</option><option value="CUP">Cuban Peso</option><option value="CVE">Cape Verdean Escudo</option><option value="CZK">Czech Koruna</option><option value="DJF">Djiboutian Franc</option><option value="DKK">Danish Krone</option><option value="DOP">Dominican Peso</option><option value="DZD">Algerian Dinar</option><option value="EGP">Egyptian Pound</option><option value="ETB">Ethiopian Birr</option><option value="FJD">Fijian Dollar</option><option value="FKP">Falkland Islands Pound</option><option value="GEL">Georgian Lari</option><option value="GHS">Ghanaian Cedi</option><option value="GIP">Gibraltar Pound</option><option value="GMD">Gambian Dalasi</option><option value="GNF">Guinean Franc</option><option value="GTQ">Guatemalan Quetzal</option><option value="GYD">Guyanaese Dollar</option><option value="HKD">Hong Kong Dollar</option><option value="HNL">Honduran Lempira</option><option value="HRK">Croatian Kuna</option><option value="HTG">Haitian Gourde</option><option value="HUF">Hungarian Forint</option><option value="IDR">Indonesian Rupiah</option><option value="ILS">Israeli Shekel</option><option value="INR">Indian Rupee</option><option value="IQD">Iraqi Dinar</option><option value="IRR">Iranian Rial</option><option value="ISK">Icelandic Króna</option><option value="JEP">Jersey Pound</option><option value="JMD">Jamaican Dollar</option><option value="JOD">Jordanian Dinar</option><option value="KES">Kenyan Shilling</option><option value="KGS">Kyrgystani Som</option><option value="KHR">Cambodian Riel</option><option value="KMF">Comorian Franc</option><option value="KPW">North Korean Won</option><option value="KWD">Kuwaiti Dinar</option><option value="KYD">Cayman Islands Dollar</option><option value="KZT">Kazakhstani Tenge</option><option value="LAK">Laotian Kip</option><option value="LBP">Lebanese Pound</option><option value="LKR">Sri Lankan Rupee</option><option value="LRD">Liberian Dollar</option><option value="LSL">Lesotho Loti</option><option value="LYD">Libyan Dinar</option><option value="MAD">Moroccan Dirham</option><option value="MDL">Moldovan Leu</option><option value="MGA">Malagasy Ariary</option><option value="MKD">Macedonian Denar</option><option value="MMK">Myanma Kyat</option><option value="MNT">Mongolian Tugrik</option><option value="MOP">Macanese Pataca</option><option value="MRU">Mauritanian Ouguiya</option><option value="MUR">Mauritian Rupee</option><option value="MVR">Maldivian Rufiyaa</option><option value="MWK">Malawian Kwacha</option><option value="MXN">Mexican Peso</option><option value="MYR">Malaysian Ringgit</option><option value="MZN">Mozambican Metical</option><option value="NAD">Namibian Dollar</option><option value="NGN">Nigerian Naira</option><option value="NIO">Nicaraguan Córdoba</option><option value="NOK">Norwegian Krone</option><option value="NPR">Nepalese Rupee</option><option value="OMR">Omani Rial</option><option value="PAB">Panamanian Balboa</option><option value="PEN">Peruvian Nuevo Sol</option><option value="PGK">Papua New Guinean Kina</option><option value="PHP">Philippine Peso</option><option value="PKR">Pakistani Rupee</option><option value="PLN">Polish Zloty</option><option value="PYG">Paraguayan Guarani</option><option value="QAR">Qatari Rial</option><option value="RON">Romanian Leu</option><option value="RSD">Serbian Dinar</option><option value="RUB">Russian Ruble</option><option value="RWF">Rwandan Franc</option><option value="SAR">Saudi Riyal</option><option value="SBD">Solomon Islands Dollar</option><option value="SCR">Seychellois Rupee</option><option value="SDG">Sudanese Pound</option><option value="SGD">Singapore Dollar</option><option value="SHP">Saint Helena Pound</option><option value="SLL">Sierra Leonean Leone</option><option value="SOS">Somali Shilling</option><option value="SRD">Surinamese Dollar</option><option value="STN">São Tomé and Príncipe Dobra</option><option value="SVC">Salvadoran Colón</option><option value="SYP">Syrian Pound</option><option value="SZL">Swazi Lilangeni</option><option value="THB">Thai Baht</option><option value="TJS">Tajikistani Somoni</option><option value="TMT">Turkmenistani Manat</option><option value="TND">Tunisian Dinar</option><option value="TOP">Tongan Paʻanga</option><option value="TRY">Turkish Lira</option><option value="TTD">Trinidad and Tobago Dollar</option><option value="TWD">New Taiwan Dollar</option><option value="TZS">Tanzanian Shilling</option><option value="UAH">Ukrainian Hryvnia</option><option value="UGX">Ugandan Shilling</option><option value="UYU">Uruguayan Peso</option><option value="UZS">Uzbekistan Som</option><option value="VEF">Venezuelan Bolívar Fuerte</option><option value="VND">Vietnamese Dong</option><option value="VUV">Vanuatu Vatu</option><option value="WST">Samoan Tala</option><option value="XAF">CFA Franc BEAC</option><option value="XCD">East Caribbean Dollar</option><option value="XOF">CFA Franc BCEAO</option><option value="XPF">CFP Franc</option><option value="YER">Yemeni Rial</option><option value="ZAR">South African Rand</option><option value="ZMW">Zambian Kwacha</option><option value="ZWL">Zimbabwean Dollar</option><option value="XAG">Silver (troy ounce)</option><option value="XAU">Gold (troy ounce)</option><option value="ETH">Ethereum</option><option value="XRP">Ripple</option><option value="BCH">Bitcoin Cash</option><option value="EOS">EOS</option><option value="LTC">Litecoin</option><option value="ADA">Cardano</option><option value="XLM">Stellar</option><option value="MIOTA">IOTA</option><option value="TRX">TRON</option><option value="NEO">NEO</option><option value="XMR">Monero</option><option value="DASH">Dash</option><option value="XEM">NEM</option><option value="USDT">Tether</option><option value="ETC">Ethereum Classic</option><option value="VEN">VeChain</option><option value="OMG">OmiseGO</option><option value="QTUM">Qtum</option><option value="ICX">ICON</option><option value="BNB">Binance Coin</option><option value="BTG">Bitcoin Gold</option><option value="LSK">Lisk</option><option value="STEEM">Steem</option><option value="ZEC">Zcash</option><option value="XVG">Verge</option><option value="SC">Siacoin</option><option value="BCN">Bytecoin</option><option value="BTM*">Bytom</option><option value="NANO">Nano</option><option value="BCD">Bitcoin Diamond</option><option value="WAN">Wanchain</option><option value="BTCP">Bitcoin Private</option><option value="PPT">Populous</option><option value="BTS">BitShares</option><option value="ZIL">Zilliqa</option><option value="AE">Aeternity</option><option value="DOGE">Dogecoin</option><option value="MKR">Maker</option><option value="DCR">Decred</option><option value="STRAT">Stratis</option><option value="ONT">Ontology</option><option value="XIN">Mixin</option><option value="ZRX">0x</option><option value="WAVES">Waves</option><option value="DGD">DigixDAO</option><option value="HSR">Hshare</option><option value="RHOC">RChain</option><option value="GNT">Golem</option><option value="SNT">Status</option><option value="AION">Aion</option><option value="WTC">Waltonchain</option><option value="REP">Augur</option><option value="LRC">Loopring</option><option value="DGB">DigiByte</option><option value="BAT">Basic Attention Token</option><option value="IOST">IOStoken</option><option value="KMD">Komodo</option><option value="ARDR">Ardor</option><option value="MITH">Mithril</option><option value="KNC">Kyber Network</option><option value="ARK">Ark</option><option value="MONA">MonaCoin</option><option value="KCS">KuCoin Shares</option><option value="CENNZ">Centrality</option><option value="PIVX">PIVX</option><option value="ELF">aelf</option><option value="SYS">Syscoin</option><option value="CNX">Cryptonex</option><option value="DRGN">Dragonchain</option><option value="SUB">Substratum</option><option value="DCN">Dentacoin</option><option value="GAS">Gas</option><option value="NPXS">Pundi X</option><option value="STORM">Storm</option><option value="QASH">QASH</option><option value="ETHOS">Ethos</option><option value="FCT">Factom</option><option value="NAS">Nebulas</option><option value="GTO">Gifto</option><option value="RDD">ReddCoin</option><option value="CTXC">Cortex</option><option value="BNT">Bancor</option><option value="VERI">Veritaseum</option><option value="SALT">SALT</option><option value="FUN">FunFair</option><option value="GXS">GXChain</option><option value="ELA">Elastos</option><option value="WAX">WAX</option><option value="XZC">ZCoin</option><option value="NXT">Nxt</option><option value="POWR">Power Ledger</option><option value="ENG">Enigma</option><option value="MCO">Monaco</option><option value="KIN">Kin</option><option value="R">Revain</option><option value="LOOM">Loom Network</option><option value="ETN">Electroneum</option><option value="NCASH">Nucleus Vision</option><option value="REQ">Request Network</option><option value="GBYTE">Byteball Bytes</option><option value="MAID">MaidSafeCoin</option><option value="FSN">Fusion</option><option value="NEBL">Neblio</option><option value="LINK">ChainLink</option><option value="PAY">TenX</option><option value="SMT">SmartMesh</option><option value="DBC">DeepBrain Chain</option><option value="ZEN">ZenCash</option><option value="SMART">SmartCash</option><option value="STORJ">Storj</option><option value="PART">Particl</option><option value="SKY">Skycoin</option><option value="CND">Cindicator</option><option value="MANA">Decentraland</option><option value="ICN">Iconomi</option><option value="ACT">Achain</option><option value="MAN">Matrix AI Network</option><option value="GTC">Game.com</option><option value="POA">POA Network</option><option value="CVC">Civic</option><option value="EMC">Emercoin</option><option value="NXS">Nexus</option><option value="BOS">BOScoin</option><option value="NULS">Nuls</option><option value="TPAY">TokenPay</option><option value="PAYX">Paypex</option><option value="DENT">Dent</option><option value="POLY">Polymath</option><option value="POE">Po.et</option><option value="LCC">Litecoin Cash</option><option value="DTR">Dynamic Trading Rights</option><option value="GNO">Gnosis</option><option value="BTCD">BitcoinDark</option><option value="RLC">iExec RLC</option><option value="MTL">Metal</option><option value="VTC">Vertcoin</option><option value="DEW">DEW</option><option value="TNB">Time New Bank</option><option value="QSP">Quantstamp</option><option value="ANT">Aragon</option><option value="CMT">CyberMiles</option><option value="GAME">GameCredits</option><option value="BTX">Bitcore</option><option value="HT">Huobi Token</option><option value="SAN">Santiment Network Token</option><option value="ENJ">Enjin Coin</option><option value="SPHTX">SophiaTX</option><option value="RDN">Raiden Network Token</option><option value="ABT">Arcblock</option><option value="AGI">SingularityNET</option><option value="MED">MediBloc</option><option value="HPB">High Performance Blockchain</option><option value="PPP">PayPie</option><option value="GRS">Groestlcoin</option><option value="CPX">Apex</option><option value="AUTO">Cube</option><option value="GNX">Genaro Network</option><option value="XDN">DigitalNote</option><option value="BLOCK">Blocknet</option><option value="AMB">Ambrosus</option><option value="SRN">SIRIN LABS Token</option><option value="UBQ">Ubiq</option><option value="DROP">Dropil</option><option value="DTA">DATA</option><option value="RUFF">Ruff</option><option value="CS">Credits</option><option value="TKY">THEKEY</option><option value="VEE">BLOCKv</option><option value="RPX">Red Pulse</option><option value="THETA">Theta Token</option><option value="BLZ">Bluzelle</option><option value="SNM">SONM</option><option value="IGNIS">Ignis</option><option value="NAV">NavCoin</option><option value="PLR">Pillar</option><option value="ZCL">ZClassic</option><option value="INK">Ink</option><option value="GVT">Genesis Vision</option><option value="LEND">ETHLend</option><option value="CLOAK">CloakCoin</option><option value="AST">AirSwap</option><option value="TOMO">TomoChain</option><option value="XAS">Asch</option><option value="DDD">Scry.info</option><option value="BAY">BitBay</option><option value="EMC2">Einsteinium</option><option value="BIX">Bibox Token</option><option value="OST">OST</option><option value="C20">CRYPTO20</option><option value="ADX">AdEx</option><option value="QRL">Quantum Resistant Ledger</option><option value="RCN">Ripio Credit Network</option><option value="IHT">IHT Real Estate Protocol</option><option value="EDO">Eidoo</option><option value="DATA">Streamr DATAcoin</option><option value="TEL">Telcoin</option><option value="ITC">IoT Chain</option><option value="BTO">Bottos</option><option value="CRPT">Crypterium</option><option value="ION">ION</option><option value="BRD">Bread</option><option value="MNX">MinexCoin</option><option value="WPR">WePower</option><option value="PPC">Peercoin</option><option value="ELEC">Electrify.Asia</option><option value="INS">INS Ecosystem</option><option value="SLS">SaluS</option><option value="VIBE">VIBE</option><option value="VIA">Viacoin</option><option value="NANJ">NANJCOIN</option><option value="BCO">BridgeCoin</option><option value="INT">Internet Node Token</option><option value="WABI">WaBi</option><option value="EDG">Edgeless</option><option value="SNGLS">SingularDTV</option><option value="JNT">Jibrel Network</option><option value="APPC">AppCoins</option><option value="DNT">district0x</option><option value="RNTB">BitRent</option><option value="SPANK">SpankChain</option><option value="UTK">UTRUST</option><option value="MDS">MediShares</option><option value="WINGS">Wings</option><option value="PURA">Pura</option><option value="TNT">Tierion</option><option value="LBC">LBRY Credits</option><option value="TRAC">OriginTrail</option><option value="MOD">Modum</option><option value="OCN">Odyssey</option><option value="EVN">Envion</option><option value="QLC">QLINK</option><option value="XCP">Counterparty</option><option value="WGR">Wagerr</option><option value="BURST">Burst</option><option value="PRL">Oyster</option><option value="FTC">Feathercoin</option><option value="TRIG">Triggers</option><option value="DPY">Delphy</option><option value="FUEL">Etherparty</option><option value="ECA">Electra</option><option value="NLG">Gulden</option><option value="MLN">Melon</option><option value="DCT">DECENT</option><option value="SBD*">Steem Dollars</option><option value="MOBI">Mobius</option><option value="DAT">Datum</option><option value="PRE">Presearch</option><option value="XP">Experience Points</option><option value="TNC">Trinity Network Credit</option><option value="ZOI">Zoin</option><option value="TKN">TokenCard</option><option value="SOAR">Soarcoin</option><option value="ADT">adToken</option><option value="BCPT">BlockMason Credit Protocol</option><option value="TAAS">TaaS</option><option value="NGC">NAGA</option><option value="SXDT">Spectre.ai Dividend Token</option><option value="XBY">XTRABYTES</option><option value="CDT">Blox</option><option value="UTNP">Universa</option><option value="RKT">Rock</option><option value="ETP">Metaverse ETP</option><option value="SOC">All Sports</option><option value="COSS">COSS</option><option value="BITCNY">bitCNY</option><option value="SAFEX">Safe Exchange Coin</option><option value="BAX">BABB</option><option value="LET">LinkEye</option><option value="LGO">Legolas Exchange</option><option value="REN">Republic Protocol</option><option value="ZPT">Zeepin</option><option value="BKX">Bankex</option><option value="CSC">CasinoCoin</option><option value="QUN">QunQun</option><option value="XEL">Elastic</option><option value="KICK">KickCoin</option><option value="DATX">DATx</option><option value="UKG">Unikoin Gold</option><option value="BANCA">Banca</option><option value="ODE">ODEM</option><option value="RFR">Refereum</option><option value="TEN">Tokenomy</option><option value="VIB">Viberate</option><option value="GUP">Matchpool</option><option value="SHIFT">Shift</option><option value="XDCE">XinFin Network</option><option value="STK">STK</option><option value="YOYOW">YOYOW</option><option value="SHIP">ShipChain</option><option value="RVN">Ravencoin</option><option value="HAV">Havven</option><option value="XSH">SHIELD</option><option value="PRO">Propy</option><option value="DIME">Dimecoin</option><option value="HTML">HTMLCOIN</option><option value="CFI">Cofound.it</option><option value="TAU">Lamden</option><option value="PHR">Phore</option><option value="MER">Mercury</option><option value="AEON">Aeon</option><option value="CPC*">CPChain</option><option value="DAI">Dai</option><option value="HMQ">Humaniq</option><option value="ACAT">Alphacat</option><option value="ONION">DeepOnion</option><option value="AMP">Synereo</option><option value="LUN">Lunyr</option><option value="HST">Decision Token</option><option value="1ST">FirstBlood</option><option value="TIO">Trade Token</option><option value="SENT">Sentinel</option><option value="DMT">DMarket</option><option value="EKT">EDUCare</option><option value="UP">UpToken</option><option value="UGC">ugChain</option><option value="POT">PotCoin</option><option value="PEPECASH">Pepe Cash</option><option value="NMC">Namecoin</option><option value="TRST">WeTrust</option><option value="SENC">Sentinel Chain</option><option value="CRW">Crown</option><option value="UNO">Unobtanium</option><option value="DOCK">Dock</option><option value="AIDOC">AI Doctor</option><option value="FOTA">Fortuna</option><option value="COB">Cobinhood</option><option value="UUU">U Network</option><option value="ECC">ECC</option><option value="TIX">Blocktix</option><option value="MGO">MobileGo</option><option value="ZSC">Zeusshield</option><option value="EVX">Everex</option><option value="HMC">Hi Mutual Society</option><option value="IOC">I/O Coin</option><option value="SWFTC">SwftCoin</option><option value="MTH">Monetha</option><option value="XSN">StakeNet</option><option value="MSP">Mothership</option><option value="MWAT">Restart Energy MWAT</option><option value="BITB">Bean Cash</option><option value="SWH">Switcheo</option><option value="THC">HempCoin</option><option value="KEY">Selfkey</option><option value="LYM">Lympo</option><option value="BCA">Bitcoin Atom</option><option value="SNC">SunContract</option><option value="NMR">Numeraire</option><option value="TRUE">True Chain</option><option value="TSL">Energo</option><option value="ARN">Aeron</option><option value="MTN">Medicalchain</option><option value="DADI">DADI</option><option value="AIT">AICHAIN</option><option value="CAPP">Cappasity</option><option value="$PAC">PACcoin</option><option value="ORME">Ormeus Coin</option><option value="RNT">OneRoot Network</option><option value="DLT">Agrello</option><option value="PPY">Peerplays</option><option value="SPC">SpaceChain</option><option value="BLK">BlackCoin</option><option value="YEE">YEE</option><option value="DXT">Datawallet</option><option value="KRM">Karma</option><option value="ALQO">ALQO</option><option value="XPM">Primecoin</option><option value="CV">carVertical</option><option value="LEO">LEOcoin</option><option value="BOT">Bodhi</option><option value="MDA">Moeda Loyalty Points</option><option value="PASC">Pascal Coin</option><option value="BLT">Bloom</option><option value="DMD">Diamond</option><option value="RADS">Radium</option><option value="VRC">VeriCoin</option><option value="QBT*">Qbao</option><option value="OCT">OracleChain</option><option value="ATM">ATMChain</option><option value="OMNI">Omni</option><option value="GRID">Grid+</option><option value="MDT">Measurable Data Token</option><option value="RVR">RevolutionVR</option><option value="HOT">Hydro Protocol</option><option value="FLASH">Flash</option><option value="AXP">aXpire</option><option value="SIB">SIBCoin</option><option value="COV">Covesting</option><option value="FAIR">FairCoin</option><option value="GRC">GridCoin</option><option value="MTX">Matryx</option><option value="STQ">Storiqa</option><option value="LKK">Lykke</option><option value="POSW">PoSW Coin</option><option value="HVN">Hive Project</option><option value="CAT*">BitClave</option><option value="EDR">E-Dinar Coin</option><option value="OAX">OAX</option><option value="IDH">indaHash</option><option value="UQC">Uquid Coin</option><option value="PARETO">Pareto Network</option><option value="BBN">Banyan Network</option><option value="MEDIC">MedicCoin</option><option value="XWC">WhiteCoin</option><option value="LA">LATOKEN</option><option value="EVE">Devery</option><option value="TCT">TokenClub</option><option value="LUX">LUXCoin</option><option value="BPT">Blockport</option><option value="RMT">SureRemit</option><option value="ICOS">ICOS</option><option value="PRA">ProChain</option><option value="HKN">Hacken</option><option value="EXP">Expanse</option><option value="IXT">iXledger</option><option value="INCNT">Incent</option><option value="AURA">Aurora DAO</option><option value="TFD">TE-FOOD</option><option value="CHSB">SwissBorg</option><option value="PZM">PRIZM</option><option value="BMC">Blackmoon</option><option value="BIS">Bismuth</option><option value="TBAR">Titanium BAR</option><option value="SLT">Smartlands</option><option value="EKO">EchoLink</option><option value="FLO">FlorinCoin</option><option value="PLBT">Polybius</option><option value="NCT">PolySwarm</option><option value="SLR">SolarCoin</option><option value="SRCOIN">SRCOIN</option><option value="MUE">MonetaryUnit</option><option value="BERRY">Rentberry</option><option value="DIVX">Divi</option><option value="BBR">Boolberry</option><option value="BEE">Bee Token</option><option value="MOT">Olympus Labs</option><option value="COLX">ColossusXT</option><option value="STX">Stox</option><option value="ZAP">Zap</option><option value="BDG">BitDegree</option><option value="XMY">Myriad</option><option value="ARY">Block Array</option><option value="LMC">LoMoCoin</option><option value="SNOV">Snovio</option><option value="LINDA">Linda</option><option value="RISE">Rise</option><option value="RBY">Rubycoin</option><option value="SWM">Swarm</option><option value="BITUSD">bitUSD</option><option value="OK">OKCash</option><option value="XRL">Rialto</option><option value="BSD*">BitSend</option><option value="NLC2">NoLimitCoin</option><option value="DNA">EncrypGen</option><option value="DTB">Databits</option><option value="BITG">Bitcoin Green</option><option value="CLAM">Clams</option><option value="DEB">Debitum</option><option value="ENRG">Energycoin</option><option value="AUC">Auctus</option><option value="NEOS">NeosCoin</option><option value="IPBC">Interplanetary Broadcast Coin</option><option value="CAS">Cashaa</option><option value="XSPEC">Spectrecoin</option><option value="SWT">Swarm City</option><option value="XPA">XPA</option><option value="CXO">CargoX</option><option value="DICE">Etheroll</option><option value="FLDC">FoldingCoin</option><option value="PRG">Paragon</option><option value="NET*">Nimiq Exchange Token</option><option value="DIM">DIMCOIN</option><option value="ALIS">ALIS</option><option value="CVT">CyberVein</option><option value="FLUZ">Fluz Fluz</option><option value="PTOY">Patientory</option><option value="DRT">DomRaider</option><option value="GBX">GoByte</option><option value="NEU">Neumark</option><option value="DBET">DecentBet</option><option value="NXC">Nexium</option><option value="MOON">Mooncoin</option><option value="FLIXX">Flixxo</option><option value="MUSIC">Musicoin</option><option value="EVR">Everus</option><option value="CREDO">Credo</option><option value="QAU">Quantum</option><option value="HAT">Hat.Exchange</option><option value="GOLOS">Golos</option><option value="LALA">LALA World</option><option value="LOC">LockTrip</option><option value="TUSD">True USD</option><option value="BCC">BitConnect</option><option value="REM">Remme</option><option value="EFX">Effect.AI</option><option value="AIR">AirToken</option><option value="ART">Maecenas</option><option value="NYC">NewYorkCoin</option><option value="SYNX">Syndicate</option><option value="CAN">CanYaCoin</option><option value="IPSX">IP Exchange</option><option value="CHP">CoinPoker</option><option value="PST">Primas</option><option value="FTX">FintruX Network</option><option value="NPX">NaPoleonX</option><option value="BNTY">Bounty0x</option><option value="LDC">Leadcoin</option><option value="DBIX">DubaiCoin</option><option value="WRC">Worldcore</option><option value="GAM">Gambit</option><option value="WCT">Waves Community Token</option><option value="HWC">HollyWoodCoin</option><option value="OXY">Oxycoin</option><option value="COFI">CoinFi</option><option value="AUR">Auroracoin</option><option value="DTH">Dether</option><option value="MYST">Mysterium</option><option value="XLR">Solaris</option><option value="ATN">ATN</option><option value="CBT">CommerceBlock</option><option value="TCC">The ChampCoin</option><option value="HEAT">HEAT</option><option value="SIG">Spectiv</option><option value="DYN">Dynamic</option><option value="XST">Stealthcoin</option><option value="PLU">Pluton</option><option value="BQ">bitqy</option><option value="FDX">FidentiaX</option><option value="POLIS">Polis</option><option value="PFR">Payfair</option><option value="TX">TransferCoin</option><option value="AVT">Aventus</option><option value="INSTAR">Insights Network</option><option value="HXX">Hexx</option><option value="IFT">InvestFeed</option><option value="ESP">Espers</option><option value="ADB">adbank</option><option value="TIME">Chronobank</option><option value="IPL">InsurePal</option><option value="SPHR">Sphere</option><option value="GETX">Guaranteed Ethurance Token Extra</option><option value="TIPS">FedoraCoin</option><option value="CVCOIN">CVCoin</option><option value="PURE">Pure</option><option value="TOA">ToaCoin</option><option value="SEQ">Sequence</option><option value="ELIX">Elixir</option><option value="MINT">Mintcoin</option><option value="ATL">ATLANT</option><option value="PINK">PinkCoin</option><option value="DAN">Daneel</option><option value="ZLA">Zilla</option><option value="COVAL">Circuits of Value</option><option value="PUT*">Profile Utility Token</option><option value="PND">Pandacoin</option><option value="CLR">ClearCoin</option><option value="MYB">MyBit Token</option><option value="ATB">ATBCoin</option><option value="OPT">Opus</option><option value="BCY">Bitcrystals</option><option value="RVT">Rivetz</option><option value="TKS">Tokes</option><option value="EBST">eBoost</option><option value="XAUR">Xaurum</option><option value="IOP">Internet of People</option><option value="BLUE">BLUE</option><option value="XNK">Ink Protocol</option><option value="CURE">Curecoin</option><option value="BWK">Bulwark</option><option value="VOISE">Voise</option><option value="PKT">Playkey</option><option value="PBL">Publica</option><option value="HGT">HelloGold</option><option value="CAG">Change</option><option value="DOVU">Dovu</option><option value="GEO">GeoCoin</option><option value="LIFE">LIFE</option><option value="B2B">B2BX</option><option value="POLL">ClearPoll</option><option value="REBL">REBL</option><option value="ADH">AdHive</option><option value="UCASH">U.CASH</option><option value="NVC">Novacoin</option><option value="ABY">ArtByte</option><option value="GLA">Gladius Token</option><option value="GET">GET Protocol</option><option value="TRF">Travelflex</option><option value="HAC">Hackspace Capital</option><option value="KORE">Kore</option><option value="HQX">HOQU</option><option value="MSR">Masari</option><option value="ERO">Eroscoin</option><option value="XHV">Haven Protocol</option><option value="PRIX">Privatix</option><option value="VIT">Vice Industry Token</option><option value="SXUT">Spectre.ai Utility Token</option><option value="DOPE">DopeCoin</option><option value="SPF">SportyCo</option><option value="BRX">Breakout Stake</option><option value="CHIPS">CHIPS</option><option value="OBITS">OBITS</option><option value="NVST">NVO</option><option value="CSNO">BitDice</option><option value="LEV">Leverj</option><option value="GAT">Gatcoin</option><option value="VIU">Viuly</option><option value="EXRN">EXRNchain</option><option value="PIRL">Pirl</option><option value="PING">CryptoPing</option><option value="XBC">Bitcoin Plus</option><option value="IDXM">IDEX Membership</option><option value="DOT">Dotcoin</option><option value="BTCZ">BitcoinZ</option><option value="LOCI">LOCIcoin</option><option value="PTC">Pesetacoin</option><option value="MEME">Memetic / PepeCoin</option><option value="TFL">TrueFlip</option><option value="SPD">Stipend</option><option value="AID">AidCoin</option><option value="NKC">Nework</option><option value="NIO*">Autonio</option><option value="SEXC">ShareX</option><option value="APX">APX</option><option value="GLD">GoldCoin</option><option value="CAT">BlockCAT</option><option value="EXCL">ExclusiveCoin</option><option value="HYP">HyperStake</option><option value="ASTRO">Astro</option><option value="QWARK">Qwark</option><option value="ERC">EuropeCoin</option><option value="KB3">B3Coin</option><option value="MAX">MaxCoin</option><option value="TRCT">Tracto</option><option value="J8T">JET8</option><option value="INXT">Internxt</option><option value="DEV">DeviantCoin</option><option value="USNBT">NuBits</option><option value="HUSH">Hush</option><option value="SUMO">Sumokoin</option><option value="1WO">1World</option><option value="XNN">Xenon</option><option value="PLAY">HEROcoin</option><option value="SPR">SpreadCoin</option><option value="SPRTS">Sprouts</option><option value="SEND">Social Send</option><option value="LEDU">Education Ecosystem</option><option value="VTR">vTorrent</option><option value="ING">Iungo</option><option value="WISH">MyWish</option><option value="BTM">Bitmark</option><option value="UNIT">Universal Currency</option><option value="CANN">CannabisCoin</option><option value="AIX">Aigang</option><option value="BON">Bonpay</option><option value="VRM">VeriumReserve</option><option value="NTRN">Neutron</option><option value="CPAY">Cryptopay</option><option value="2GIVE">2GIVE</option><option value="MONK">Monkey Project</option><option value="EXY">Experty</option><option value="MNTP">GoldMint</option><option value="STAC">StarterCoin</option><option value="DNR">Denarius</option><option value="UFR">Upfiring</option><option value="BIO">BioCoin</option><option value="ADST">AdShares</option><option value="HORSE">Ethorse</option><option value="DRP">DCORP</option><option value="BTDX">Bitcloud</option><option value="CPY">COPYTRACK</option><option value="ZEIT">Zeitcoin</option><option value="BRK">Breakout</option><option value="PIX">Lampix</option><option value="OTN">Open Trading Network</option><option value="SETH">Sether</option><option value="FLAP">FlappyCoin</option><option value="RC">RussiaCoin</option><option value="ZRC">ZrCoin</option><option value="GCR">Global Currency Reserve</option><option value="CRB">Creditbit</option><option value="REF">RefToken</option><option value="BLITZ">Blitzcash</option><option value="RIC">Riecoin</option><option value="EZT">EZToken</option><option value="SWIFT">Bitswift</option><option value="STAR">Starbase</option><option value="MVC">Maverick Chain</option><option value="BET*">DAO.Casino</option><option value="KRB">Karbo</option><option value="SSS">Sharechain</option><option value="BPL">Blockpool</option><option value="UFO">Uniform Fiscal Object</option><option value="TRC">Terracoin</option><option value="SHP*">Sharpe Platform Token</option><option value="RUPX">Rupaya</option><option value="PBT">Primalbase Token</option><option value="XMCC">Monoeci</option><option value="EGC">EverGreenCoin</option><option value="ZER">Zero</option><option value="ADC">AudioCoin</option><option value="QRK">Quark</option><option value="AU">AurumCoin</option><option value="ODN">Obsidian</option><option value="REAL">REAL</option><option value="SCL">Sociall</option><option value="DGPT">DigiPulse</option><option value="CMPCO">CampusCoin</option><option value="BEZ">Bezop</option><option value="HUC">HunterCoin</option><option value="TRUST">TrustPlus</option><option value="PIPL">PiplCoin</option><option value="XGOX">XGOX</option><option value="BASH">LuckChain</option><option value="PYLNT">Pylon Network</option><option value="ZEPH">Zephyr</option><option value="FOR">FORCE</option><option value="CRED">Verify</option><option value="TIE">Ties.DB</option><option value="RUP">Rupee</option><option value="VZT">Vezt</option><option value="1337">Elite</option><option value="JIYO">Jiyo</option><option value="AMM">MicroMoney</option><option value="SXC">Sexcoin</option><option value="HIRE">HireMatch</option><option value="EVC">EventChain</option><option value="EFL">e-Gulden</option><option value="PUT">PutinCoin</option><option value="VSX">Vsync</option><option value="TZC">TrezarCoin</option><option value="ZNY">Bitzeny</option><option value="XMG">Magi</option><option value="CRAVE">Crave</option><option value="EQT">EquiTrader</option><option value="LINX">Linx</option><option value="ACE">Ace</option><option value="CHC">ChainCoin</option><option value="808">808Coin</option><option value="GCN">GCN Coin</option><option value="QVT">Qvolta</option><option value="GRFT">Graft</option><option value="ARG">Argentum</option><option value="UIS">Unitus</option><option value="GMT">Mercury Protocol</option><option value="MAG">Magnet</option><option value="SENSE">Sense</option><option value="FRD">Farad</option><option value="MTNC">Masternodecoin</option><option value="TBX">Tokenbox</option><option value="NOBL">NobleCoin</option><option value="TES">TeslaCoin</option><option value="CREA">Creativecoin</option><option value="XBP">BlitzPredict</option><option value="ITNS">IntenseCoin</option><option value="ESZ">EtherSportz</option><option value="CPC">Capricoin</option><option value="LDOGE">LiteDoge</option><option value="SMS">Speed Mining Service</option><option value="INN">Innova</option><option value="MXT">MarteXcoin</option><option value="EFYT">Ergo</option><option value="ELLA">Ellaism</option><option value="DP">DigitalPrice</option><option value="DAY">Chronologic</option><option value="SMLY">SmileyCoin</option><option value="FYN">FundYourselfNow</option><option value="KZC">Kzcash</option><option value="WAND">WandX</option><option value="NKA">IncaKoin</option><option value="CDN">Canada eCoin</option><option value="HOLD">Interstellar Holdings</option><option value="EMV">Ethereum Movie Venture</option><option value="CL">Coinlancer</option><option value="EBTC">eBitcoin</option><option value="RAIN">Condensate</option><option value="UNB">UnbreakableCoin</option><option value="BTW">BitWhite</option><option value="BUN">BunnyCoin</option><option value="KEK">KekCoin</option><option value="STAK">STRAKS</option><option value="BBP">BiblePay</option><option value="IC">Ignition</option><option value="ANC">Anoncoin</option><option value="LNC">Blocklancer</option><option value="ALT">Altcoin</option><option value="ORB">Orbitcoin</option><option value="YOC">Yocoin</option><option value="ONG">onG.social</option><option value="BUZZ">BuzzCoin</option><option value="AHT">Bowhead</option><option value="KOBO">Kobocoin</option><option value="ETBS">Ethbits</option><option value="IND">Indorse Token</option><option value="SAGA">SagaCoin</option><option value="TIG">Tigereum</option><option value="LATX">LatiumX</option><option value="XFT">Footy Cash</option><option value="OCC">Octoin Coin</option><option value="SKIN">SkinCoin</option><option value="ELTCOIN">ELTCOIN</option><option value="TDX">Tidex Token</option><option value="FRST">FirstCoin</option><option value="ACC*">Accelerator Network</option><option value="GPU">GPU Coin</option><option value="MRJA">GanjaCoin</option><option value="OCL">Oceanlab</option><option value="ARC">ArcticCoin</option><option value="CARBON">Carboncoin</option><option value="DEM">Deutsche eMark</option><option value="BYC">Bytecent</option><option value="MCAP">MCAP</option><option value="NMS">Numus</option><option value="LGD">Legends Room</option><option value="42">42-coin</option><option value="DFS">DFSCoin</option><option value="LOG">Woodcoin</option><option value="SNRG">Synergy</option><option value="MOIN">Moin</option><option value="VULC">Vulcano</option><option value="MRT">Miners' Reward Token</option><option value="VIVO">VIVO</option><option value="JEW">Shekel</option><option value="SKC">Skeincoin</option><option value="GCC*">Global Cryptocurrency</option><option value="ADZ">Adzcoin</option><option value="FUNK">The Cypherfunks</option><option value="GJC">Global Jobcoin</option><option value="MZC">MAZA</option><option value="CTR">Centra</option><option value="MEC">Megacoin</option><option value="ORE">Galactrum</option><option value="XPTX">PlatinumBAR</option><option value="DEUS">DeusCoin</option><option value="DFT">DraftCoin</option><option value="PCN">PeepCoin</option><option value="BRIT">BritCoin</option><option value="BTA">Bata</option><option value="UNIFY">Unify</option><option value="ZET">Zetacoin</option><option value="EPY">Emphy</option><option value="STU">bitJob</option><option value="DCY">Dinastycoin</option><option value="NETKO">Netko</option><option value="GUN">Guncoin</option><option value="MAGE">MagicCoin</option><option value="XLC">LeviarCoin</option><option value="NSR">NuShares</option><option value="FCN">Fantomcoin</option><option value="CRC*">CrowdCoin</option><option value="DRPU">DRP Utility</option><option value="FJC">FujiCoin</option><option value="ECASH">Ethereum Cash</option><option value="KLN">Kolion</option><option value="MBRS">Embers</option><option value="PROC">ProCurrency</option><option value="REC">Regalcoin</option><option value="BSM">Bitsum</option><option value="ICOO">ICO OpenLedger</option><option value="START">Startcoin</option><option value="EQL">Equal</option><option value="XPD">PetroDollar</option><option value="WILD">Wild Crypto</option><option value="QBIC">Qbic</option><option value="MBI">Monster Byte</option><option value="CCRB">CryptoCarbon</option><option value="HERO">Sovereign Hero</option><option value="ATS">Authorship</option><option value="IFLT">InflationCoin</option><option value="GRWI">Growers International</option><option value="BTWTY">Bit20</option><option value="MAC">Machinecoin</option><option value="HBN">HoboNickels</option><option value="SCT">Soma</option><option value="CCT">Crystal Clear </option><option value="ESC">Escroco</option><option value="IETH">iEthereum</option><option value="HPC">Happycoin</option><option value="SUR">Suretly</option><option value="CRM">Cream</option><option value="ACC">AdCoin</option><option value="JET">Jetcoin</option><option value="INSN">InsaneCoin</option><option value="ARCT">ArbitrageCT</option><option value="LCP">Litecoin Plus</option><option value="ITI">iTicoin</option><option value="PHO">Photon</option><option value="VOT">VoteCoin</option><option value="EBET">EthBet</option><option value="MNE">Minereum</option><option value="BTB">BitBar</option><option value="RBT">Rimbit</option><option value="FST">Fastcoin</option><option value="XCPO">Copico</option><option value="BTG*">Bitgem</option><option value="PXC">Phoenixcoin</option><option value="TTC">TittieCoin</option><option value="LANA">LanaCoin</option><option value="ARCO">AquariusCoin</option><option value="GRLC">Garlicoin</option><option value="WHL">WhaleCoin</option><option value="XCN">Cryptonite</option><option value="ERC20">ERC20</option><option value="BDL">Bitdeal</option><option value="KUSH">KushCoin</option><option value="VRS">Veros</option><option value="SCORE">Scorecoin</option><option value="DRXNE">DROXNE</option><option value="ITT">Intelligent Trading Foundation</option><option value="SGR">Sugar Exchange</option><option value="TOK">Tokugawa</option><option value="SDRN">Senderon</option><option value="MOJO">MojoCoin</option><option value="MAO">Mao Zedong</option><option value="VIDZ">PureVidz</option><option value="IRL">IrishCoin</option><option value="RLT">RouletteToken</option><option value="XBL">Billionaire Token</option><option value="PLC">PlusCoin</option><option value="ELE">Elementrem</option><option value="SLG">Sterlingcoin</option><option value="KBR">Kubera Coin</option><option value="SCS">Speedcash</option><option value="BITSILVER">bitSilver</option><option value="BLC">Blakecoin</option><option value="MANNA">Manna</option><option value="TRUMP">TrumpCoin</option><option value="TEK">TEKcoin</option><option value="DAXX">DaxxCoin</option><option value="PAK">Pakcoin</option><option value="BTCA">Bitair</option><option value="STN*">Steneum Coin</option><option value="CJ">Cryptojacks</option><option value="CTX">CarTaxi Token</option><option value="BTCRED">Bitcoin Red</option><option value="CAB">Cabbage</option><option value="MNM">Mineum</option><option value="GRN">Granite</option><option value="AERM">Aerium</option><option value="GOLF">Golfcoin</option><option value="GUESS">Peerguess</option><option value="SRC">SecureCoin</option><option value="OPC">OP Coin</option><option value="WGO">WavesGo</option><option value="POST">PostCoin</option><option value="BCF">Bitcoin Fast</option><option value="XCXT">CoinonatX</option><option value="DMB">Digital Money Bits</option><option value="ZCG">Zlancer</option><option value="ONX">Onix</option><option value="CNT">Centurion</option><option value="GAP">Gapcoin</option><option value="DIX">Dix Asset</option><option value="CESC">CryptoEscudo</option><option value="ETG">Ethereum Gold</option><option value="BITGOLD">bitGold</option><option value="HNC">Helleniccoin</option><option value="CCN">CannaCoin</option><option value="TOKC">TOKYO</option><option value="ATOM">Atomic Coin</option><option value="OTX">Octanox</option><option value="PASL">Pascal Lite</option><option value="BIGUP">BigUp</option><option value="PLC*">Polcoin</option><option value="LTB">LiteBar</option><option value="LEA">LeaCoin</option><option value="SHND">StrongHands</option><option value="IMX">Impact</option><option value="ABJ">Abjcoin</option><option value="NRO">Neuro</option><option value="300">300 Token</option><option value="NUKO">Nekonium</option><option value="CUBE">DigiCube</option><option value="BTPL">Bitcoin Planet</option><option value="RED">RedCoin</option><option value="PXI">Prime-XI</option><option value="ECO">EcoCoin</option><option value="SWING">Swing</option><option value="MCRN">MACRON</option><option value="C2">Coin2.1</option><option value="XRE">RevolverCoin</option><option value="SHDW">Shadow Token</option><option value="XCO">X-Coin</option><option value="NTO">Fujinto</option><option value="REE">ReeCoin</option><option value="BOST">BoostCoin</option><option value="LBTC">LiteBitcoin</option><option value="HVCO">High Voltage</option><option value="611">SixEleven</option><option value="ETHD">Ethereum Dark</option><option value="SFC">Solarflarecoin</option><option value="FUNC">FUNCoin</option><option value="TAJ">TajCoin</option><option value="VPRC">VapersCoin</option><option value="MAY">Theresa May Coin</option><option value="GTC*">Global Tour Coin</option><option value="HBC">HomeBlockCoin</option><option value="SOON">SoonCoin</option><option value="DSR">Desire</option><option value="TRDT">Trident Group</option><option value="BITEUR">bitEUR</option><option value="BRAT">BROTHER</option><option value="NEWB">Newbium</option><option value="EAGLE">EagleCoin</option><option value="COAL">BitCoal</option><option value="CMT*">Comet</option><option value="VUC">Virta Unique Coin</option><option value="XHI">HiCoin</option><option value="FLAX">Flaxscript</option><option value="CRX">Chronos</option><option value="PCOIN">Pioneer Coin</option><option value="ERY">Eryllium</option><option value="BIP">BipCoin</option><option value="GP">GoldPieces</option><option value="ITZ">Interzone</option><option value="KRONE">Kronecoin</option><option value="CNNC">Cannation</option><option value="ADCN">Asiadigicoin</option><option value="UET">Useless Ethereum Token</option><option value="QCN">QuazarCoin</option><option value="ZMC">ZetaMicron</option><option value="MSCN">Master Swiscoin</option><option value="LTCU">LiteCoin Ultra</option><option value="RKC">Royal Kingdom Coin</option><option value="LUNA">Luna Coin</option><option value="GBC">GBCGoldCoin</option><option value="SANDG">Save and Gain</option><option value="CRDNC">Credence Coin</option><option value="PRC">PRCoin</option><option value="ACP">AnarchistsPrime</option><option value="WOMEN">WomenCoin</option><option value="NANOX">Project-X</option><option value="COUPE">Coupecoin</option><option value="HMC*">HarmonyCoin</option><option value="PIZZA">PizzaCoin</option><option value="CALC">CaliphCoin</option><option value="GRE">Greencoin</option><option value="XTO">Tao</option><option value="HDG">Hedge</option><option value="MUSE">MUSE</option><option value="TGT">Target Coin</option><option value="ECOB">Ecobit</option><option value="RMC">Russian Miner Coin</option><option value="HBT">Hubii Network</option><option value="AC">AsiaCoin</option><option value="KLC">KiloCoin</option><option value="GOOD">Goodomy</option><option value="ECN">E-coin</option><option value="ETT">EncryptoTel [WAVES]</option><option value="VSL">vSlice</option><option value="IXC">Ixcoin</option><option value="STA">Starta</option><option value="REX">imbrex</option><option value="CBX">Bullion</option><option value="DAR">Darcrus</option><option value="TRIA">Triaconta</option><option value="NOTE">DNotes</option><option value="INPAY">InPay</option><option value="BLU">BlueCoin</option><option value="LEAF">LeafCoin</option><option value="FLIK">FLiK</option><option value="BBT">BitBoost</option><option value="WDC">WorldCoin</option><option value="FYP">FlypMe</option><option value="JC">Jesus Coin</option><option value="UNIC">UniCoin</option><option value="SHORTY">Shorty</option><option value="FLT">FlutterCoin</option><option value="V">Version</option><option value="UNI">Universe</option><option value="POP">PopularCoin</option><option value="I0C">I0Coin</option><option value="NDC">NEVERDIE</option><option value="FUCK">FuckToken</option><option value="ZENI">Zennies</option><option value="HTC">HitCoin</option><option value="SDC">ShadowCash</option><option value="CDX">Commodity Ad Network</option><option value="RNS">Renos</option><option value="STRC">StarCredits</option><option value="METAL">MetalCoin</option><option value="RIYA">Etheriya</option><option value="BPC">Bitpark Coin</option><option value="NET">NetCoin</option><option value="BXT">BitTokens</option><option value="PIGGY">Piggycoin</option><option value="DGC">Digitalcoin</option><option value="BRO">Bitradio</option><option value="BITS">Bitstar</option><option value="TRI">Triangles</option><option value="OPAL">Opal</option><option value="USC">Ultimate Secure Cash</option><option value="TROLL">Trollcoin</option><option value="Q2C">QubitCoin</option><option value="VTA">Virtacoin</option><option value="BLZ*">BlazeCoin</option><option value="BTCS">Bitcoin Scrypt</option><option value="HODL">HOdlcoin</option><option value="TIT">Titcoin</option><option value="BITBTC">bitBTC</option><option value="KURT">Kurrent</option><option value="GAIA">GAIA</option><option value="NYAN">Nyancoin</option><option value="TAG">TagCoin</option><option value="TALK">BTCtalkcoin</option><option value="ARI">Aricoin</option><option value="DSH">Dashcoin</option><option value="HAL">Halcyon</option><option value="MOTO">Motocoin</option><option value="EBCH">eBitcoinCash</option><option value="BUCKS">SwagBucks</option><option value="UTC">UltraCoin</option><option value="FLY">Flycoin</option><option value="SMC">SmartCoin</option><option value="TRK">Truckcoin</option><option value="XPY">PayCoin</option><option value="RPC">RonPaulCoin</option><option value="NXX">Nexxus</option><option value="ISL">IslaCoin</option><option value="SUPER">SuperCoin</option><option value="XJO">Joulecoin</option><option value="GB">GoldBlocks</option><option value="PR">Prototanium</option><option value="CASH">Cashcoin</option><option value="EVIL">Evil Coin</option><option value="8BIT">8Bit</option><option value="BLOCKPAY">BlockPay</option><option value="MAD*">SatoshiMadness</option><option value="BOLI">Bolivarcoin</option><option value="TSE">Tattoocoin (Standard Edition)</option><option value="DDF">DigitalDevelopersFund</option><option value="TKR">CryptoInsight</option><option value="PHS">Philosopher Stones</option><option value="VISIO">Visio</option><option value="TGC">Tigercoin</option><option value="CHESS">ChessCoin</option><option value="AMBER">AmberCoin</option><option value="ENT">Eternity</option><option value="CNO">Coin(O)</option><option value="BITZ">Bitz</option><option value="CYP">Cypher</option><option value="FRC">Freicoin</option><option value="XRA">Ratecoin</option><option value="GRIM">Grimcoin</option><option value="XCT">C-Bit</option><option value="EMD">Emerald Crypto</option><option value="MARS">Marscoin</option><option value="ICN*">iCoin</option><option value="NEVA">NevaCoin</option><option value="SPEX">SproutsExtreme</option><option value="INFX">Influxcoin</option><option value="CHAN">ChanCoin</option><option value="AMMO">Ammo Reloaded</option><option value="PX">PX</option><option value="BTCR">Bitcurrency</option><option value="SPACE">SpaceCoin</option><option value="BERN">BERNcash</option><option value="888">OctoCoin</option><option value="DTC">Datacoin</option><option value="QBC">Quebecoin</option><option value="KED">Darsek</option><option value="CTO">Crypto</option><option value="LCT">LendConnect</option><option value="SIGT">Signatum</option><option value="XIOS">Xios</option><option value="GLT">GlobalToken</option><option value="UNITS">GameUnits</option><option value="B@">Bankcoin</option><option value="RBIES">Rubies</option><option value="IMS">Independent Money System</option><option value="VC">VirtualCoin</option><option value="GLC">GlobalCoin</option><option value="ZUR">Zurcoin</option><option value="FNC">FinCoin</option><option value="AMS">AmsterdamCoin</option><option value="QTL">Quatloo</option><option value="PNX">Phantomx</option><option value="CAT**">Catcoin</option><option value="CCO">Ccore</option><option value="DUO">ParallelCoin</option><option value="MST">MustangCoin</option><option value="PKB">ParkByte</option><option value="BSTY">GlobalBoost-Y</option><option value="FIRE">Firecoin</option><option value="STV">Sativacoin</option><option value="YAC">Yacoin</option><option value="BUMBA">BumbaCoin</option><option value="AIB">Advanced Internet Blocks</option><option value="JIN">Jin Coin</option><option value="HONEY">Honey</option><option value="SCRT">SecretCoin</option><option value="XVP">Virtacoinplus</option><option value="DRS">Digital Rupees</option><option value="EVO">Evotion</option><option value="ELC">Elacoin</option><option value="ICOB">ICOBID</option><option value="EL">Elcoin</option><option value="CON">PayCon</option><option value="XBTS">Beatcoin</option><option value="GCC">GuccioneCoin</option><option value="XNG">Enigma</option><option value="HMP">HempCoin</option><option value="XBTC21">Bitcoin 21</option><option value="DLC">Dollarcoin</option><option value="BRIA">BriaCoin</option><option value="$$$">Money</option><option value="BTQ">BitQuark</option><option value="YTN">YENTEN</option><option value="XCRE">Creatio</option><option value="DALC">Dalecoin</option><option value="EUC">Eurocoin</option><option value="ACOIN">Acoin</option><option value="FUZZ">FuzzBalls</option><option value="GLS">GlassCoin</option><option value="CACH">CacheCoin</option><option value="MNC">Mincoin</option><option value="SOIL">SOILcoin</option><option value="BLN">Bolenum</option><option value="BENJI">BenjiRolls</option><option value="NTWK">Network Token</option><option value="MDC">Madcoin</option><option value="AGLC">AgrolifeCoin</option><option value="BLRY">BillaryCoin</option><option value="J">Joincoin</option><option value="CPN">CompuCoin</option><option value="STARS">StarCash Network</option><option value="CXT">Coinonat</option><option value="DBTC">Debitcoin</option><option value="ALL*">Allion</option><option value="ROOFS">Roofs</option><option value="ASAFE2">AllSafe</option><option value="CF">Californium</option><option value="BAS">BitAsean</option><option value="MAR">Marijuanacoin</option><option value="RIDE">Ride My Car</option><option value="MTLMC3">Metal Music Coin</option><option value="GPL">Gold Pressed Latinum</option><option value="SONG">SongCoin</option><option value="ZZC">ZoZoCoin</option><option value="WARP">WARP</option><option value="SH">Shilling</option><option value="BNX">BnrtxCoin</option><option value="MND">MindCoin</option><option value="RBX">Ripto Bux</option><option value="BXC">Bitcedi</option><option value="BSTAR">Blackstar</option><option value="ZYD">Zayedcoin</option><option value="URO">Uro</option><option value="PRX">Printerium</option><option value="VIP">VIP Tokens</option><option value="ATX">Artex Coin</option><option value="WORM">HealthyWormCoin</option><option value="KNC*">KingN Coin</option><option value="JWL">Jewels</option><option value="SLEVIN">Slevin</option><option value="POS">PoSToken</option><option value="DRM">Dreamcoin</option><option value="MILO">MiloCoin</option><option value="ICON">Iconic</option><option value="PONZI">PonziCoin</option><option value="DLISK">DAPPSTER</option><option value="EXN">ExchangeN</option><option value="PIE">PIECoin</option><option value="BSC">BowsCoin</option><option value="LTCR">Litecred</option><option value="GEERT">GeertCoin</option><option value="VLT">Veltor</option><option value="BIOS">BiosCrypto</option><option value="PULSE">Pulse</option><option value="STEPS">Steps</option><option value="LIR">LetItRide</option><option value="ARB">ARbit</option><option value="IMPS">ImpulseCoin</option><option value="BOAT">BOAT</option><option value="ZNE">Zonecoin</option><option value="JS">JavaScript Token</option><option value="PLACO">PlayerCoin</option><option value="VEC2">VectorAI</option><option value="WBB">Wild Beast Block</option><option value="CWXT">CryptoWorldX Token</option><option value="OFF">Cthulhu Offerings</option><option value="SDP">SydPak</option><option value="DES">Destiny</option><option value="RSGP">RSGPcoin</option><option value="TAGR">TAGRcoin</option><option value="OS76">OsmiumCoin</option><option value="PLNC">PLNcoin</option><option value="TOR">Torcoin</option><option value="VOLT">Bitvolt</option><option value="PEX">PosEx</option><option value="JOBS">JobsCoin</option><option value="ARGUS">Argus</option><option value="DOLLAR">Dollar Online</option><option value="CTIC3">Coimatic 3.0</option><option value="XRC">Rawcoin</option><option value="P7C">P7Coin</option><option value="BIOB">BioBar</option><option value="IBANK">iBank</option><option value="CREVA">CrevaCoin</option><option value="ELS">Elysium</option><option value="SOCC">SocialCoin</option><option value="CONX">Concoin</option><option value="SLFI">Selfiecoin</option><option value="NODC">NodeCoin</option><option value="MGM">Magnum</option><option value="GSR">GeyserCoin</option><option value="CTIC2">Coimatic 2.0</option><option value="ULA">Ulatech</option><option value="VLTC">Vault Coin</option><option value="LVPS">LevoPlus</option><option value="TSTR">Tristar Coin</option><option value="FXE">FuturXe</option><option value="DGCS">Digital Credits</option><option value="EBT">Ebittree Coin</option><option value="AI">POLY AI</option><option value="CKUSD">CK USD</option><option value="OC">OceanChain</option><option value="WIC*">WaykiChain</option><option value="XMC">Monero Classic</option><option value="MOAC">MOAC</option><option value="IQT">iQuant</option><option value="SBTC">Super Bitcoin</option><option value="KCASH">Kcash</option><option value="CAN*">Content and AD Network</option><option value="STC">StarChain</option><option value="NOAH">Noah Coin</option><option value="MEET">CoinMeet</option><option value="EPC">Electronic PK Chain</option><option value="BCX">BitcoinX</option><option value="CHAT">ChatCoin</option><option value="AAC">Acute Angle Cloud</option><option value="ATMC">ATMCoin</option><option value="DRG">Dragon Coins</option><option value="MOF">Molecular Future</option><option value="XMO">Monero Original</option><option value="SHOW">Show</option><option value="FAIR*">FairGame</option><option value="CMS">COMSA [ETH]</option><option value="RCT">RealChain</option><option value="BFT">BnkToTheFuture</option><option value="BSTN">BitStation</option><option value="GEM">Gems </option><option value="TOPC">TopChain</option><option value="FIL">Filecoin [Futures]</option><option value="OF">OFCOIN</option><option value="UBTC">United Bitcoin</option><option value="LIGHT">LightChain</option><option value="AWR">AWARE</option><option value="KST">StarCoin</option><option value="XUC">Exchange Union</option><option value="NTK">Neurotoken</option><option value="VLC">ValueChain</option><option value="CMS*">COMSA [XEM]</option><option value="FRGC">Fargocoin</option><option value="XTZ">Tezos (Pre-Launch)</option><option value="MAG*">Maggie</option><option value="SSC">SelfSell</option><option value="BCDN">BlockCDN</option><option value="LBTC*">Lightning Bitcoin [Futures]</option><option value="WETH">WETH</option><option value="SCC">StockChain</option><option value="HLC">HalalChain</option><option value="IPC">IPChain</option><option value="ATC">Arbitracoin</option><option value="AMLT">AMLT Token</option><option value="FID">Fidelium</option><option value="EARTH">Earth Token</option><option value="PRS">PressOne</option><option value="EOSDAC">eosDAC</option><option value="QUBE">Qube</option><option value="BIG">BigONE Token</option><option value="DIG">Dignity</option><option value="MRK">MARK.SPACE</option><option value="UIP">UnlimitedIP</option><option value="ADK">Aidos Kuneen</option><option value="ADI">Aditus</option><option value="CFUN">CFun</option><option value="AVH">Animation Vision Cash</option><option value="READ">Read</option><option value="BBI">BelugaPay</option><option value="WC">WINCOIN</option><option value="XIN*">Infinity Economics</option><option value="CVH">Curriculum Vitae</option><option value="SBC">StrikeBitClub</option><option value="BRM">BrahmaOS</option><option value="TDS">TokenDesk</option><option value="CHX">Chainium</option><option value="CROP">Cropcoin</option><option value="XTL">Stellite</option><option value="XOT">Internet of Things</option><option value="SEN">Consensus</option><option value="CANDY">Candy</option><option value="IDT">InvestDigital</option><option value="GCS">GameChain System</option><option value="XID">Sphre AIR </option><option value="ECH">Etherecash</option><option value="BT2">BT2 [CST]</option><option value="SWTC">Jingtum Tech</option><option value="HPY">Hyper Pay</option><option value="GBG">Golos Gold</option><option value="DERO">Dero</option><option value="WIN">WCOIN</option><option value="GOD">Bitcoin God</option><option value="ANI">Animecoin</option><option value="B2X">SegWit2x</option><option value="SNIP">SnipCoin</option><option value="MLM">MktCoin</option><option value="BUBO">Budbo</option><option value="BELA">Bela</option><option value="SIC">Swisscoin</option><option value="ABC">Alphabit</option><option value="PCS">Pabyosi Coin (Special)</option><option value="BSR">BitSoar</option><option value="MSD">MSD</option><option value="XSTC">Safe Trade Coin</option><option value="FDZ">Friendz</option><option value="APC">AlpaCoin</option><option value="IFC">Infinitecoin</option><option value="GRMD">GreenMed</option><option value="EMB">EmberCoin</option><option value="PHI">PHI Token</option><option value="PCL">Peculium</option><option value="ACC**">ACChain</option><option value="MFG">SyncFab</option><option value="LST">Lendroid Support Token</option><option value="BAR">Titanium Blockchain</option><option value="W3C">W3Coin</option><option value="ENT*">ENTCash</option><option value="XID*">International Diamond</option><option value="CLUB">ClubCoin</option><option value="DUTCH">Dutch Coin</option><option value="CEFS">CryptopiaFeeShares</option><option value="OX">OX Fina</option><option value="SPK">Sparks</option><option value="EDRC">EDRCoin</option><option value="WA">WA Space</option><option value="NOX">Nitro</option><option value="HDLB">HODL Bucks</option><option value="UTT">United Traders Token</option><option value="EDT">EtherDelta Token</option><option value="CLD">Cloud</option><option value="MCR">Macro</option><option value="SLOTH">Slothcoin</option><option value="COR">CORION</option><option value="MARX">MarxCoin</option><option value="PRES">President Trump</option><option value="RBBT">RabbitCoin</option><option value="NAMO">NamoCoin</option><option value="MCI">Musiconomi</option><option value="ERA">ERA</option><option value="SONO">SONO</option><option value="HIGH">High Gain</option><option value="XRY">Royalties</option><option value="BET">BetaCoin</option><option value="SIGMA">SIGMAcoin</option><option value="HC">Harvest Masternode Coin</option><option value="INDI">Indicoin</option><option value="ZBC">Zilbercoin</option><option value="TLE">Tattoocoin (Limited Edition)</option><option value="EAG">EA Coin</option><option value="ZENGOLD">ZenGold</option><option value="TESLA">TeslaCoilCoin</option><option value="FUTC">FutCoin</option><option value="FRN">Francs</option><option value="BTCM">BTCMoon</option><option value="ROYAL">RoyalCoin</option><option value="NUMUS">NumusCash</option><option value="DON">Donationcoin</option><option value="PRN">Protean</option><option value="TER">TerraNova</option><option value="RYZ">ANRYZE</option><option value="LDCN">LandCoin</option><option value="SJW">SJWCoin</option><option value="GDC">GrandCoin</option><option value="CYDER">Cyder</option><option value="MBL">MobileCash</option><option value="BITCF">First Bitcoin Capital</option><option value="GAIN">UGAIN</option><option value="DAV">DavorCoin</option><option value="PLX">PlexCoin</option><option value="ELITE">Ethereum Lite</option><option value="CHEAP">Cheapcoin</option><option value="UNRC">UniversalRoyalCoin</option><option value="SJCX">Storjcoin X</option><option value="SKR">Sakuracoin</option><option value="HYPER">Hyper</option><option value="AV">AvatarCoin</option><option value="TURBO">TurboCoin</option><option value="TOPAZ">Topaz Coin</option><option value="ETT*">EncryptoTel [ETH]</option><option value="BLAZR">BlazerCoin</option><option value="TELL">Tellurion</option><option value="TCOIN">T-coin</option><option value="DMC">DynamicCoin</option><option value="WINK">Wink</option><option value="QBT">Cubits</option><option value="BIT">First Bitcoin</option><option value="MINEX">Minex</option><option value="GAY">GAY Money</option><option value="CME">Cashme</option><option value="HNC*">Huncoin</option><option value="GRX">GOLD Reward Token</option><option value="BTE">BitSerial</option><option value="BUB">Bubble</option><option value="SHA">SHACoin</option><option value="BEST">BestChain</option><option value="GMX">GoldMaxCoin</option><option value="POKE">PokeCoin</option><option value="SUP">Superior Coin</option><option value="XTD">XTD Coin</option><option value="HALLO">Halloween Coin</option><option value="RUNNERS">Runners</option><option value="ANTX">Antimatter</option><option value="KDC">KlondikeCoin</option><option value="WIC">Wi Coin</option><option value="LEVO">Levocoin</option><option value="UNITY">SuperNET</option><option value="SMOKE">Smoke</option><option value="UNC">UNCoin</option><option value="PRIMU">Primulon</option><option value="NEOG">NEO GOLD</option><option value="CFC">CoffeeCoin</option><option value="RICHX">RichCoin</option><option value="BAT*">BatCoin</option><option value="OP">Operand</option><option value="GARY">President Johnson</option><option value="RHFC">RHFCoin</option><option value="MAGN">Magnetcoin</option><option value="INDIA">India Coin</option><option value="UR">UR</option><option value="WSX">WeAreSatoshi</option><option value="AKY">Akuya Coin</option><option value="ZSE">ZSEcoin</option><option value="BTBc">Bitbase</option><option value="KARMA">Karmacoin</option><option value="XQN">Quotient</option><option value="TODAY">TodayCoin</option><option value="AXIOM">Axiom</option><option value="RCN*">Rcoin</option><option value="STEX">STEX</option><option value="CC">CyberCoin</option><option value="BSN">Bastonet</option><option value="NBIT">netBit</option><option value="ACES">Aces</option><option value="RUBIT">RubleBit</option><option value="DASHS">Dashs</option><option value="FONZ">Fonziecoin</option><option value="DBG">Digital Bullion Gold</option><option value="LEPEN">LePen</option><option value="SKULL">Pirate Blocks</option><option value="SISA">SISA</option><option value="LKC">LinkedCoin</option><option value="MONETA">Moneta</option><option value="SAK">Sharkcoin</option><option value="PSY">Psilocybin</option><option value="FAP">FAPcoin</option><option value="FAZZ">Fazzcoin</option><option value="REGA">Regacoin</option><option value="CYC">Cycling Coin</option><option value="DCRE">DeltaCredits</option><option value="SPORT">SportsCoin</option><option value="TRICK">TrickyCoin</option><option value="X2">X2</option><option value="SHELL">ShellCoin</option><option value="OPES">Opescoin</option><option value="PAYP">PayPeer</option><option value="HCC">Happy Creator Coin</option><option value="FRWC">FrankyWillCoin</option><option value="KASHH">KashhCoin</option><option value="BITOK">Bitok</option><option value="TCR">TheCreed</option><option value="DISK">DarkLisk</option><option value="OMC">Omicron</option><option value="EGG">EggCoin</option><option value="LAZ">Lazaruscoin</option><option value="GML">GameLeagueCoin</option><option value="PRM">PrismChain</option><option value="BIRDS">Birds</option><option value="THS">TechShares</option><option value="ACN">Avoncoin</option><option value="QORA">Qora</option><option value="TOP*">TopCoin</option><option value="CRYPT">CryptCoin</option><option value="ASN">Aseancoin</option><option value="EREAL">eREAL</option><option value="XVC">Vcash</option><option value="UGT">UG Token</option><option value="FRCT">Farstcoin</option></select>            </div>
        </div>

    </nav>

<div class="pusher">

    <div id="stats" class="ui basic segment">
        <div class="ui mini statistics">
            <div class="yellow statistic">
                <div class="value">1587</div>
                <div class="label">Total Cryptocurrencies</div>
            </div>
            <div class="yellow statistic">
                <div class="value">10,409</div>
                <div class="label">Markets</div>
            </div>
            <div class="yellow statistic">
                <div class="value">407,510,746,675</div>
                <div class="label">Total Market Cap</div>
            </div>
            <div class="yellow statistic">
                <div class="value">26,365,761,598</div>
                <div class="label">Volume 24H</div>
            </div>
            <div class="yellow statistic">
                <div class="value">37.7 %</div>
                <div class="label">Bitcoin Dominance</div>
            </div>
        </div>
    </div>


    <main id="content">

        <div class="ui container">

    
    <div class="ui basic  segment">
        <h1 class="ui centered header">
            ICOs            <div class="sub header">ICOs List</div>
        </h1>
    </div>

    

    <div class="ui stackable secondary menu">
        <a href="finished.html" class="item active button">
            <i class="hourglass end icon"></i>
            Finished        </a>
        <a href="live.html" class="item  button">
            <i class="clock icon"></i>
            Live        </a>
        <a href="upcoming.html" class="item  button">
            <i class="calendar plus outline icon"></i>
            Upcoming        </a>
    </div>

    <table id="icos-list" class="ui basic fluid table">
        <tbody>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/augur" class="ui small image">
                        <img src="../../icowatchlist.com/logos/augur.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/augur">Augur</a>
                    </h3>
                    Augur is a decentralized prediction market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/augur" class="ui green button">
                            17/08/2015 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/augur" class="ui red button">
                            01/10/2015 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lisk" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lisk.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lisk">Lisk</a>
                    </h3>
                    It is a cryptocurrency and decentralized application platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lisk" class="ui green button">
                            22/02/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lisk" class="ui red button">
                            21/03/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/digixdao" class="ui small image">
                        <img src="../../icowatchlist.com/logos/digixdao.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/digixdao">Digix DAO</a>
                    </h3>
                    A Decentralized Autonomous Organization focused on goldtracking assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/digixdao" class="ui green button">
                            30/03/2016 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/digixdao" class="ui red button">
                            30/03/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/waves" class="ui small image">
                        <img src="../../icowatchlist.com/logos/waves.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/waves">Waves</a>
                    </h3>
                    Waves helps to make the launching and coordination of projects on blockchain very easy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/waves" class="ui green button">
                            12/04/2016 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/waves" class="ui red button">
                            31/05/2016 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/neo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/neo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/neo">NEO</a>
                    </h3>
                    Antshares is a China based smart contract blockchain project                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/neo" class="ui green button">
                            09/07/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/neo" class="ui red button">
                            09/07/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/stratis" class="ui small image">
                        <img src="../../icowatchlist.com/logos/stratis.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/stratis">Stratis</a>
                    </h3>
                    Stratis was developed to help organisations develop their own private blockchains                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/stratis" class="ui green button">
                            21/06/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/stratis" class="ui red button">
                            26/07/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/taonetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/taonetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/taonetwork">Tao Network</a>
                    </h3>
                    Tao Network posits itself as a digital asset management system meant to be used by stakeholders in the music industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/taonetwork" class="ui green button">
                            16/07/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/taonetwork" class="ui red button">
                            15/08/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/incent" class="ui small image">
                        <img src="../../icowatchlist.com/logos/incent.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/incent">Incent</a>
                    </h3>
                    Incent is a blockchain based loyalty program for traders especially retailers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/incent" class="ui green button">
                            01/09/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/incent" class="ui red button">
                            01/09/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockpay" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockpay.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpay">BlockPay</a>
                    </h3>
                    This is a retail platform that allows multicryptocurrency payment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpay" class="ui green button">
                            15/08/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpay" class="ui red button">
                            15/09/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/firstblood" class="ui small image">
                        <img src="../../icowatchlist.com/logos/firstblood.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/firstblood">FirstBlood</a>
                    </h3>
                    FirstBlood is a eSports matches and betting project                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/firstblood" class="ui green button">
                            25/09/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/firstblood" class="ui red button">
                            26/09/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iconomi" class="ui small image">
                        <img src="../../icowatchlist.com/logos/iconomi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iconomi">Iconomi</a>
                    </h3>
                    The Iconomi platform helps users with simple methods to enter the growing distributed economy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iconomi" class="ui green button">
                            25/08/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iconomi" class="ui red button">
                            26/09/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lykke" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lykke.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lykke">Lykke</a>
                    </h3>
                    Global market space based on blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lykke" class="ui green button">
                            09/10/2016 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lykke" class="ui red button">
                            09/10/2016 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/synereo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/synereo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/synereo">Synereo</a>
                    </h3>
                    Synereo is a decentralized and distributed social network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/synereo" class="ui green button">
                            18/09/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/synereo" class="ui red button">
                            18/10/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/singulardtv" class="ui small image">
                        <img src="../../icowatchlist.com/logos/singulardtv.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/singulardtv">SingularDTV</a>
                    </h3>
                    This is a film and television studio and also a distribution portal based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/singulardtv" class="ui green button">
                            05/10/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/singulardtv" class="ui red button">
                            29/10/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/beyondthevoid" class="ui small image">
                        <img src="../../icowatchlist.com/logos/beyondthevoid.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/beyondthevoid">Beyond The Void</a>
                    </h3>
                    Video Game in Real Time                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/beyondthevoid" class="ui green button">
                            01/10/2016 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/beyondthevoid" class="ui red button">
                            01/11/2016 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/decent" class="ui small image">
                        <img src="../../icowatchlist.com/logos/decent.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/decent">Decent</a>
                    </h3>
                    Decent is a content distribution project                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/decent" class="ui green button">
                            10/10/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/decent" class="ui red button">
                            10/11/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/golem" class="ui small image">
                        <img src="../../icowatchlist.com/logos/golem.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/golem">Golem</a>
                    </h3>
                    The Golem platform enables personal computers to perform functions traditionally reserved for servers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/golem" class="ui green button">
                            13/10/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/golem" class="ui red button">
                            13/11/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ark" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ark.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ark">Ark</a>
                    </h3>
                    The Ark project aims to make cryptocurrency adoption mainstream as quickly as possible                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ark" class="ui green button">
                            07/11/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ark" class="ui red button">
                            12/12/2016 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vdiceio" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vdiceio.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vdiceio">vDice.io</a>
                    </h3>
                    Betting Game based on the Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vdiceio" class="ui green button">
                            15/11/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vdiceio" class="ui red button">
                            15/12/2016 02:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/komodo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/komodo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/komodo">Komodo</a>
                    </h3>
                    Komodo is a decentralized ICO platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/komodo" class="ui green button">
                            15/10/2016 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/komodo" class="ui red button">
                            16/12/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/golos" class="ui small image">
                        <img src="../../icowatchlist.com/logos/golos.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/golos">Golos</a>
                    </h3>
                    Golos is open source technology bringing the power of voice media to blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/golos" class="ui green button">
                            22/11/2016 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/golos" class="ui red button">
                            22/12/2016 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/creativecoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/creativecoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/creativecoin">CreativeCoin</a>
                    </h3>
                    CreativeCoin for the registration and distribution of creative works and rights                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/creativecoin" class="ui green button">
                            15/03/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/creativecoin" class="ui red button">
                            05/01/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wings" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wings.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wings">Wings</a>
                    </h3>
                    A decentralized platform for the creation management and interlinking of DAOs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wings" class="ui green button">
                            18/11/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wings" class="ui red button">
                            06/01/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tokes" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tokes.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokes">Tokes</a>
                    </h3>
                    Tokes is a digital currency project for the legalization of the cannabis industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokes" class="ui green button">
                            12/12/2016 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tokes" class="ui red button">
                            16/01/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/chronobank" class="ui small image">
                        <img src="../../icowatchlist.com/logos/chronobank.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/chronobank">ChronoBank</a>
                    </h3>
                    Time based currencies on multiple blockchains                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/chronobank" class="ui green button">
                            15/12/2016 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/chronobank" class="ui red button">
                            15/02/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/qtum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/qtum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/qtum">Qtum</a>
                    </h3>
                    A smart contract platform for PoS transactions                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/qtum" class="ui green button">
                            12/03/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/qtum" class="ui red button">
                            17/03/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/edgeless" class="ui small image">
                        <img src="../../icowatchlist.com/logos/edgeless.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/edgeless">Edgeless</a>
                    </h3>
                    Edgeless solves Casino transparency problems through the use of the Ethereum blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/edgeless" class="ui green button">
                            28/02/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/edgeless" class="ui red button">
                            21/03/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iexec" class="ui small image">
                        <img src="../../icowatchlist.com/logos/iexec.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iexec">iEx.ec</a>
                    </h3>
                    IeXec is a fully decentralized cloud based computing system based on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iexec" class="ui green button">
                            19/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iexec" class="ui red button">
                            19/04/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/encryptotel" class="ui small image">
                        <img src="../../icowatchlist.com/logos/encryptotel.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/encryptotel">EncryptoTel</a>
                    </h3>
                    Encrypto Telecom offers solutions for secure communication over the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/encryptotel" class="ui green button">
                            24/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/encryptotel" class="ui red button">
                            24/04/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gnosis" class="ui small image">
                        <img src="../../icowatchlist.com/logos/gnosis.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gnosis">Gnosis</a>
                    </h3>
                    it is an Ethereumbased prediction market that works using crowdsourcing methods                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gnosis" class="ui green button">
                            24/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gnosis" class="ui red button">
                            24/04/2017 11:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mobilego" class="ui small image">
                        <img src="../../icowatchlist.com/logos/mobilego.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilego">MobileGo</a>
                    </h3>
                    MobileGoGameCredit is a proprietary payment gateway that allows gamers to use the tokens to buy ingame content                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilego" class="ui green button">
                            25/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mobilego" class="ui red button">
                            25/04/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/humaniq" class="ui small image">
                        <img src="../../icowatchlist.com/logos/humaniq.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/humaniq">Humaniq</a>
                    </h3>
                    Decentralized Banking based on blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/humaniq" class="ui green button">
                            06/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/humaniq" class="ui red button">
                            27/04/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lunyr" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lunyr.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lunyr">Lunyr</a>
                    </h3>
                    The future of knowledge sharing that lets you earn rewards for what you know                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lunyr" class="ui green button">
                            29/03/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lunyr" class="ui red button">
                            27/04/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/taas" class="ui small image">
                        <img src="../../icowatchlist.com/logos/taas.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/taas">TaaS</a>
                    </h3>
                    TaaS is a tokenized closedend fund specifically for blockchainbased assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/taas" class="ui green button">
                            27/03/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/taas" class="ui red button">
                            27/04/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockpool" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockpool.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpool">BlockPool</a>
                    </h3>
                    BlockPool is a B2B blockchain solution for many industries Fintech Media  more                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpool" class="ui green button">
                            01/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpool" class="ui red button">
                            01/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tokencard" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tokencard.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokencard">TokenCard</a>
                    </h3>
                    Token Market has been setup as the platform for the future financial era                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokencard" class="ui green button">
                            02/05/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tokencard" class="ui red button">
                            02/05/2017 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ecobit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ecobit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ecobit">EcoBit</a>
                    </h3>
                    EcoBit is taking charge in the fight to make the planet a safe and healthier place for us all to live in                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ecobit" class="ui green button">
                            09/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ecobit" class="ui red button">
                            09/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/boscoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/boscoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/boscoin">BOScoin</a>
                    </h3>
                    BOScoin is a selfevolving cryptocurrency platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/boscoin" class="ui green button">
                            10/05/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/boscoin" class="ui red button">
                            10/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockchaincapital" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockchaincapital.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaincapital">Blockchain Capital</a>
                    </h3>
                    Blockchain Capital is a venture capital firm investing in blockchain enterprises                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaincapital" class="ui green button">
                            10/04/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaincapital" class="ui red button">
                            10/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/zrcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/zrcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/zrcoin">ZrCoin</a>
                    </h3>
                    ZrCoin is a blockchain project for investing in the production of an indemand industrial material                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/zrcoin" class="ui green button">
                            11/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/zrcoin" class="ui red button">
                            11/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aeternity" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aeternity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aeternity">Aeternity</a>
                    </h3>
                    Aeternity is a new smart contract blockchain that interfaces with IoT FinTech  more                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aeternity" class="ui green button">
                            12/05/2017 13:05                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aeternity" class="ui red button">
                            12/05/2017 13:05                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethbits" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethbits.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbits">Ethbits</a>
                    </h3>
                    It is an easytouse secure cryptocurrency with an organization that has a futureoriented mindset                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbits" class="ui green button">
                            15/04/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbits" class="ui red button">
                            13/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/peerplays" class="ui small image">
                        <img src="../../icowatchlist.com/logos/peerplays.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/peerplays">Peerplays</a>
                    </h3>
                    Peerplays is a provably fair blockchainbased gaming platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/peerplays" class="ui green button">
                            26/02/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/peerplays" class="ui red button">
                            14/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aragon" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aragon.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aragon">Aragon</a>
                    </h3>
                    The Aragon platform lets a whole organization operate with the infrastracture of the blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aragon" class="ui green button">
                            17/05/2017 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aragon" class="ui red button">
                            17/05/2017 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/monaco" class="ui small image">
                        <img src="../../icowatchlist.com/logos/monaco.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/monaco">Monaco</a>
                    </h3>
                    Monaco is creating a cryptocurrency card with extra affordable exchange rates                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/monaco" class="ui green button">
                            18/05/2017 09:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/monaco" class="ui red button">
                            18/05/2017 09:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/storj" class="ui small image">
                        <img src="../../icowatchlist.com/logos/storj.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/storj">Storj</a>
                    </h3>
                    Storj is a platform allows users to store data in a secure and decentralized manner                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/storj" class="ui green button">
                            19/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/storj" class="ui red button">
                            19/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crypviser" class="ui small image">
                        <img src="../../icowatchlist.com/logos/crypviser.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crypviser">Crypviser</a>
                    </h3>
                    Crypviser is an encrypted network for business and social on the Blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crypviser" class="ui green button">
                            20/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crypviser" class="ui red button">
                            20/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/quantumrl" class="ui small image">
                        <img src="../../icowatchlist.com/logos/quantumrl.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/quantumrl">Quantum RL </a>
                    </h3>
                    The Quantum Resistant Ledger QRL is new technology which is resistant to hacking by quantum computers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/quantumrl" class="ui green button">
                            01/05/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/quantumrl" class="ui red button">
                            24/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptoping" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptoping.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoping">CryptoPing</a>
                    </h3>
                    CryptoPing is a real time altcoins trading intelligence chatbot as a service                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoping" class="ui green button">
                            25/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoping" class="ui red button">
                            25/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/adelphoi" class="ui small image">
                        <img src="../../icowatchlist.com/logos/adelphoi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/adelphoi">Adelphoi</a>
                    </h3>
                    Adel is a selfsustaining cryptocurrency system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/adelphoi" class="ui green button">
                            01/05/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/adelphoi" class="ui red button">
                            25/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/veritaseum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/veritaseum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/veritaseum">Veritaseum</a>
                    </h3>
                    Veritaseum is a smart contractsbased peertopeer wallet interface                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/veritaseum" class="ui green button">
                            25/04/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/veritaseum" class="ui red button">
                            26/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mysterium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/mysterium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mysterium">Mysterium</a>
                    </h3>
                    Mysterium is an open sourced network that enables anyone to rent out their unused network traffic                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mysterium" class="ui green button">
                            30/05/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mysterium" class="ui red button">
                            30/05/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/exscudo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/exscudo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/exscudo">Exscudo</a>
                    </h3>
                    Exscudos main goal is to integrate cryptocurrencies into the traditional financial                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/exscudo" class="ui green button">
                            25/04/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/exscudo" class="ui red button">
                            31/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/patientory" class="ui small image">
                        <img src="../../icowatchlist.com/logos/patientory.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/patientory">Patientory</a>
                    </h3>
                    Patientory is a distributed electronic medical record storage computing platform on the blockchain                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/patientory" class="ui green button">
                            31/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/patientory" class="ui red button">
                            31/05/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/basicattentiontoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/basicattentiontoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/basicattentiontoken">Basic Attention Token</a>
                    </h3>
                    Basic Attention Token is bringing blockchain technology to digital advertising                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/basicattentiontoken" class="ui green button">
                            31/05/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/basicattentiontoken" class="ui red button">
                            31/05/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wagerr" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wagerr.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wagerr">Wagerr</a>
                    </h3>
                    Wagerr is a decentralized sportsbook that changes the way the world bets on sports                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wagerr" class="ui green button">
                            01/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wagerr" class="ui red button">
                            01/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nvo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nvo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nvo">NVO</a>
                    </h3>
                    NVO is building a crossplatform modular decentralized exchange                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nvo" class="ui green button">
                            01/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nvo" class="ui red button">
                            01/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sphre" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sphre.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sphre">Sphre</a>
                    </h3>
                    SphreAir is a smart contract based platform for the secure management and monetisation of digital identities                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sphre" class="ui green button">
                            01/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sphre" class="ui red button">
                            01/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dcorp" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dcorp.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dcorp">Dcorp</a>
                    </h3>
                    Dcorp is an autonomous organization system based on a smartcontract blockchain solution                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dcorp" class="ui green button">
                            01/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dcorp" class="ui red button">
                            01/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/giga-watt" class="ui small image">
                        <img src="../../icowatchlist.com/logos/giga-watt.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/giga-watt">GigaWatt</a>
                    </h3>
                    Giga Watt facilitys distinctive infrastructure consists of numerous independent mining units                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/giga-watt" class="ui green button">
                            02/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/giga-watt" class="ui red button">
                            02/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/voise" class="ui small image">
                        <img src="../../icowatchlist.com/logos/voise.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/voise">Voise</a>
                    </h3>
                    A platform that levels the playing field for all musicians                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/voise" class="ui green button">
                            06/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/voise" class="ui red button">
                            06/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bancor" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bancor.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bancor">Bancor</a>
                    </h3>
                    The Bancor protocol allows anyone to easily create completely liquid smart tokens                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bancor" class="ui green button">
                            12/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bancor" class="ui red button">
                            12/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fundyourselfnow" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fundyourselfnow.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fundyourselfnow">Fund Yourself Now</a>
                    </h3>
                    FundYourselfNow is a platform that will allow project creators raise funds for projects without the need of technical cryptocurrency knowledge                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fundyourselfnow" class="ui green button">
                            13/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fundyourselfnow" class="ui red button">
                            13/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/minexcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/minexcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/minexcoin">Minexcoin</a>
                    </h3>
                    MinexCoin is a global payments system based on a low volatility cryptocurrency which is a part of Minex ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/minexcoin" class="ui green button">
                            15/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/minexcoin" class="ui red button">
                            14/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/compcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/compcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/compcoin">Compcoin</a>
                    </h3>
                    Compcoin is an investment system that uses AI  blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/compcoin" class="ui green button">
                            14/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/compcoin" class="ui red button">
                            14/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sonm" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sonm.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sonm">SONM</a>
                    </h3>
                    SONM is a decentralized worldwide fog computer for any general purpose computing from site hosting to scientific calculations                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sonm" class="ui green button">
                            15/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sonm" class="ui red button">
                            15/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/status" class="ui small image">
                        <img src="../../icowatchlist.com/logos/status.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/status">Status</a>
                    </h3>
                    Status is a browser app and messenger gateway to a decentralized world                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/status" class="ui green button">
                            17/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/status" class="ui red button">
                            17/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/21-million" class="ui small image">
                        <img src="../../icowatchlist.com/logos/21-million.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/21-million">21 Million</a>
                    </h3>
                    The first Cryptocurrencyfunded blockchain INDY TV series                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/21-million" class="ui green button">
                            12/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/21-million" class="ui red button">
                            18/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/beth" class="ui small image">
                        <img src="../../icowatchlist.com/logos/beth.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/beth">Beth</a>
                    </h3>
                    Beth is a closedend fund focused on applying deep learning research combined with financial expertise                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/beth" class="ui green button">
                            05/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/beth" class="ui red button">
                            20/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/onegram" class="ui small image">
                        <img src="../../icowatchlist.com/logos/onegram.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/onegram">OneGram</a>
                    </h3>
                    Each coin in the OneGram blockchain is backed by 1 gram of 24k gold                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/onegram" class="ui green button">
                            21/05/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/onegram" class="ui red button">
                            20/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/civic" class="ui small image">
                        <img src="../../icowatchlist.com/logos/civic.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/civic">Civic</a>
                    </h3>
                    Secure access to identity verification via the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/civic" class="ui green button">
                            21/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/civic" class="ui red button">
                            21/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coinstorm" class="ui small image">
                        <img src="../../icowatchlist.com/logos/coinstorm.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinstorm">Internet of Coins</a>
                    </h3>
                    Internet of Coins is a new peertopeer financial network on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinstorm" class="ui green button">
                            21/03/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coinstorm" class="ui red button">
                            21/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/populous" class="ui small image">
                        <img src="../../icowatchlist.com/logos/populous.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/populous">Populous</a>
                    </h3>
                    Populous is a smart contract invoice system on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/populous" class="ui green button">
                            24/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/populous" class="ui red button">
                            24/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/primalbase" class="ui small image">
                        <img src="../../icowatchlist.com/logos/primalbase.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/primalbase">Primalbase</a>
                    </h3>
                    Primalbase is an offices workspace sharing platform managed on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/primalbase" class="ui green button">
                            26/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/primalbase" class="ui red button">
                            26/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/adtoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/adtoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/adtoken">AdToken</a>
                    </h3>
                    Digital advertising powered by Ethereum                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/adtoken" class="ui green button">
                            26/06/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/adtoken" class="ui red button">
                            26/06/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/omisego" class="ui small image">
                        <img src="../../icowatchlist.com/logos/omisego.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/omisego">Omise GO</a>
                    </h3>
                    Omise GO is a blockchain wallet solution built on the Ethereum platform for payments rewards points and much more                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/omisego" class="ui green button">
                            27/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/omisego" class="ui red button">
                            27/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mybit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/mybit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mybit">MyBit</a>
                    </h3>
                    MyBit is a decentralized asset management project built to add an ownership layer to the internet                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mybit" class="ui green button">
                            27/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mybit" class="ui red button">
                            27/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitquence" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitquence.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitquence">Bitquence</a>
                    </h3>
                    Bitquence is making to cryptocurrency world accessible to more people and market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitquence" class="ui green button">
                            28/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitquence" class="ui red button">
                            28/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/santiment" class="ui small image">
                        <img src="../../icowatchlist.com/logos/santiment.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/santiment">Santiment</a>
                    </h3>
                    Santiment will analyze crypto market trends and help cryptotraders manage risk                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/santiment" class="ui green button">
                            30/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/santiment" class="ui red button">
                            30/06/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cofoundit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cofoundit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cofoundit">Cofound.it</a>
                    </h3>
                    A VC Ecosystem based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cofoundit" class="ui green button">
                            01/01/1970 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cofoundit" class="ui red button">
                            06/07/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/metal" class="ui small image">
                        <img src="../../icowatchlist.com/logos/metal.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/metal">Metal</a>
                    </h3>
                    The Metal project aims to transform how digital money operates                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/metal" class="ui green button">
                            09/06/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/metal" class="ui red button">
                            08/07/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/insure-x" class="ui small image">
                        <img src="../../icowatchlist.com/logos/insure-x.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/insure-x">InsureX</a>
                    </h3>
                    InsureX is a marketplace for insurance based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/insure-x" class="ui green button">
                            11/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/insure-x" class="ui red button">
                            11/07/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dent" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dent.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dent">Dent</a>
                    </h3>
                    Dent builds the global exchange for mobile data on the blockchain                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dent" class="ui green button">
                            12/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dent" class="ui red button">
                            12/07/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tezos" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tezos.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tezos">Tezos</a>
                    </h3>
                    Smart contract platform that can evolve and in theory will never need any hard forks                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tezos" class="ui green button">
                            01/07/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tezos" class="ui red button">
                            13/07/2017 15:20                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tenx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tenx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tenx">TenX</a>
                    </h3>
                    TenX develops a debit card that is connected to your blockchain assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tenx" class="ui green button">
                            24/06/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tenx" class="ui red button">
                            24/07/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/district0x" class="ui small image">
                        <img src="../../icowatchlist.com/logos/district0x.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/district0x">district0x</a>
                    </h3>
                    This is a network that creates decentralized communities and market places                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/district0x" class="ui green button">
                            18/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/district0x" class="ui red button">
                            01/08/2017 11:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/stox" class="ui small image">
                        <img src="../../icowatchlist.com/logos/stox.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/stox">Stox</a>
                    </h3>
                    Stox is a prediction market platform for traders built on the Ethereum blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/stox" class="ui green button">
                            02/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/stox" class="ui red button">
                            02/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/starta" class="ui small image">
                        <img src="../../icowatchlist.com/logos/starta.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/starta">Starta</a>
                    </h3>
                    Starta Capital VC Fund created the startup investing accelerator on the Waves platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/starta" class="ui green button">
                            04/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/starta" class="ui red button">
                            03/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptoabs" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptoabs.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoabs">CryptoABS</a>
                    </h3>
                    Physical assets financing platform on the Ethereum blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoabs" class="ui green button">
                            14/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoabs" class="ui red button">
                            04/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/suretly" class="ui small image">
                        <img src="../../icowatchlist.com/logos/suretly.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/suretly">Suretly</a>
                    </h3>
                    Crowd vouching platform  allows people to earn money vouching for other people who need a loan                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/suretly" class="ui green button">
                            11/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/suretly" class="ui red button">
                            11/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hive">Hive</a>
                    </h3>
                    Hive provides new financial liquidity to small businesses by leveraging blockchain technology                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hive" class="ui green button">
                            03/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hive" class="ui red button">
                            14/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coinjob" class="ui small image">
                        <img src="../../icowatchlist.com/logos/coinjob.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinjob">CoinJob</a>
                    </h3>
                    Decentralized platform for freelancers based on Etheruem                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coinjob" class="ui green button">
                            14/07/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coinjob" class="ui red button">
                            14/08/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/0x" class="ui small image">
                        <img src="../../icowatchlist.com/logos/0x.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/0x">0x</a>
                    </h3>
                    0x is a protocol for a decentralized exchange of Ethereums ERC20 tokens and assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/0x" class="ui green button">
                            15/08/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/0x" class="ui red button">
                            16/08/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coindash" class="ui small image">
                        <img src="../../icowatchlist.com/logos/coindash.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coindash">CoinDash</a>
                    </h3>
                    CoinDash is an asset management platform for crypto investors that enables users to view other portfolios in realtime                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coindash" class="ui green button">
                            17/07/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coindash" class="ui red button">
                            17/08/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/decentraland" class="ui small image">
                        <img src="../../icowatchlist.com/logos/decentraland.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentraland">Decentraland</a>
                    </h3>
                    This is a a blockchain based virtual reality platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentraland" class="ui green button">
                            18/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/decentraland" class="ui red button">
                            18/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/rivet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/rivet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/rivet">Rivet</a>
                    </h3>
                    Cyber security on the blockchain The Token provides proof and assurance of security on the hardware level                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/rivet" class="ui green button">
                            10/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/rivet" class="ui red button">
                            24/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/obsidian" class="ui small image">
                        <img src="../../icowatchlist.com/logos/obsidian.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/obsidian">Obsidian</a>
                    </h3>
                    Cryptocurrency  secure messaging platform built on the Stratis blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/obsidian" class="ui green button">
                            01/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/obsidian" class="ui red button">
                            26/08/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/corion" class="ui small image">
                        <img src="../../icowatchlist.com/logos/corion.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/corion">Corion Platform</a>
                    </h3>
                    Crypto platform built on Ethereum Classic with a price controlled currency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/corion" class="ui green button">
                            18/06/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/corion" class="ui red button">
                            27/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/imperium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/imperium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/imperium">iMPERIUM</a>
                    </h3>
                    iMPERIUM is a NOFEE sports betting platform built on the Ethereum network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/imperium" class="ui green button">
                            20/08/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/imperium" class="ui red button">
                            27/08/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aicoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aicoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aicoin">AICoin</a>
                    </h3>
                    Trading cryptocurrencies with artificial intelligence technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aicoin" class="ui green button">
                            17/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aicoin" class="ui red button">
                            28/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/roc" class="ui small image">
                        <img src="../../icowatchlist.com/logos/roc.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/roc">RasputinOnline Coin</a>
                    </h3>
                    The First ICO for Adult Entertainment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/roc" class="ui green button">
                            20/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/roc" class="ui red button">
                            29/08/2017 04:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bowhead" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bowhead.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bowhead">Bowhead</a>
                    </h3>
                    Bowhead is a medical instrument powered by the blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bowhead" class="ui green button">
                            30/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bowhead" class="ui red button">
                            31/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/atbcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/atbcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/atbcoin">ATB Coin</a>
                    </h3>
                    Financial platform for organizing investment assets on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/atbcoin" class="ui green button">
                            12/07/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/atbcoin" class="ui red button">
                            31/08/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/monetha" class="ui small image">
                        <img src="../../icowatchlist.com/logos/monetha.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/monetha">Monetha</a>
                    </h3>
                    Welcome to a proficient installment answer for dealers that empowers comprehensively trustful trade Decentralized Enabled by the Ethereum blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/monetha" class="ui green button">
                            31/08/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/monetha" class="ui red button">
                            31/08/2017 10:18                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/benjacoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/benjacoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/benjacoin">Benjacoin</a>
                    </h3>
                    Benja is a decentralized merchandise ad network                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/benjacoin" class="ui green button">
                            01/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/benjacoin" class="ui red button">
                            01/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tron" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tron.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tron">Tron</a>
                    </h3>
                    Tron is a decentralized content entertainment protocol based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tron" class="ui green button">
                            31/08/2017 21:33                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tron" class="ui red button">
                            02/09/2017 21:34                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/arena" class="ui small image">
                        <img src="../../icowatchlist.com/logos/arena.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/arena">Arena</a>
                    </h3>
                    Arena is a cryptocurrency sports predication and betting system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/arena" class="ui green button">
                            04/08/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/arena" class="ui red button">
                            04/09/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/snapup" class="ui small image">
                        <img src="../../icowatchlist.com/logos/snapup.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/snapup">Snapup</a>
                    </h3>
                    Snapup disrupts the way you buy premium products                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/snapup" class="ui green button">
                            28/08/2017 10:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/snapup" class="ui red button">
                            04/09/2017 10:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/filecoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/filecoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/filecoin">FileCoin</a>
                    </h3>
                    A decentralized storage network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/filecoin" class="ui green button">
                            10/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/filecoin" class="ui red button">
                            07/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hubiinetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hubiinetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hubiinetwork">Hubii Network</a>
                    </h3>
                    This is a decentralized content market place based on blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hubiinetwork" class="ui green button">
                            24/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hubiinetwork" class="ui red button">
                            07/09/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ahoolee" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ahoolee.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ahoolee">Ahoolee</a>
                    </h3>
                    Ahoolee is the worlds first search engine for products                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ahoolee" class="ui green button">
                            28/08/2017 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ahoolee" class="ui red button">
                            11/09/2017 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wildcrypto" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wildcrypto.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wildcrypto">Wild Crypto</a>
                    </h3>
                    Merging Blockchain Technology with Lottery  eGaming                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wildcrypto" class="ui green button">
                            05/09/2017 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wildcrypto" class="ui red button">
                            11/09/2017 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aventus" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aventus.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aventus">Aventus</a>
                    </h3>
                    A revolutionary global standard for a more fair secure and transparent ticketing industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aventus" class="ui green button">
                            06/09/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aventus" class="ui red button">
                            13/09/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/daseron" class="ui small image">
                        <img src="../../icowatchlist.com/logos/daseron.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/daseron">Daseron</a>
                    </h3>
                    Daseron is the worlds decentralized and secure information system for selling and sharing of content                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/daseron" class="ui green button">
                            14/08/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/daseron" class="ui red button">
                            14/09/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitdice" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitdice.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdice">BitDice</a>
                    </h3>
                    Cryptocurrency gambling  Online casino technology on the blockchain                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdice" class="ui green button">
                            15/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdice" class="ui red button">
                            15/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/icobox" class="ui small image">
                        <img src="../../icowatchlist.com/logos/icobox.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/icobox">ICOBox</a>
                    </h3>
                    First token which allows blockchain community to vote for the best projects to be brought to life through their own ICOs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/icobox" class="ui green button">
                            15/08/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/icobox" class="ui red button">
                            15/09/2017 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kickico" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kickico.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kickico">KICKICO</a>
                    </h3>
                    KICKICO is the first already working platform for crowdfunding and crowdinvesting in cryptocurrency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kickico" class="ui green button">
                            29/08/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kickico" class="ui red button">
                            16/09/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/umbrellacoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/umbrellacoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/umbrellacoin">Umbrella Coin</a>
                    </h3>
                    Decentralized insurance platform built on Ethereum                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/umbrellacoin" class="ui green button">
                            20/08/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/umbrellacoin" class="ui red button">
                            17/09/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kybernetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kybernetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kybernetwork">Kyber Network</a>
                    </h3>
                    KyberNetwork is a system which allows the exchange and conversion of digital assets                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kybernetwork" class="ui green button">
                            15/09/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kybernetwork" class="ui red button">
                            17/09/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/becksang" class="ui small image">
                        <img src="../../icowatchlist.com/logos/becksang.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/becksang">Becksang</a>
                    </h3>
                    Cryptocurrency cloud mining tools that reduces mining fees                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/becksang" class="ui green button">
                            18/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/becksang" class="ui red button">
                            18/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/detectortoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/detectortoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/detectortoken">DetectorToken</a>
                    </h3>
                    DETECTOR DTCT is a bot that monitors cryptocurrency and betting markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/detectortoken" class="ui green button">
                            20/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/detectortoken" class="ui red button">
                            20/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kin">Kin</a>
                    </h3>
                    Kik one of the most popular massaging apps in the world is creating a crypto token for its ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kin" class="ui green button">
                            12/09/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kin" class="ui red button">
                            26/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/realityclash" class="ui small image">
                        <img src="../../icowatchlist.com/logos/realityclash.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/realityclash">Reality Clash</a>
                    </h3>
                    Augmented reality combat game with social features and a decentralized crypto token                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/realityclash" class="ui green button">
                            29/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/realityclash" class="ui red button">
                            29/09/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/jnet1" class="ui small image">
                        <img src="../../icowatchlist.com/logos/jnet1.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/jnet1">jNet1</a>
                    </h3>
                    jNET1 is a platform that enables B2B and B2C jewelrybased transactions                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/jnet1" class="ui green button">
                            31/08/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/jnet1" class="ui red button">
                            29/09/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/litra" class="ui small image">
                        <img src="../../icowatchlist.com/logos/litra.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/litra">Litra Coin</a>
                    </h3>
                    Litra is here to create uncontested new market space that make the competition irrelevant by decentralize Healthcare                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/litra" class="ui green button">
                            30/08/2017 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/litra" class="ui red button">
                            30/09/2017 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/axionv" class="ui small image">
                        <img src="../../icowatchlist.com/logos/axionv.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/axionv">AxionV</a>
                    </h3>
                    AxionV is an agile AI crypto fund that uses proprietary algorithms and complex trading methods to consistently outperform the market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/axionv" class="ui green button">
                            16/09/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/axionv" class="ui red button">
                            30/09/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/moneypotx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/moneypotx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneypotx">MoneypotX</a>
                    </h3>
                    MPX is partnered with the Moneypot network to provide the fuel for a versatile webwallet gaming platform and bitcoinaltcoin exchange                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneypotx" class="ui green button">
                            17/09/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/moneypotx" class="ui red button">
                            30/09/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/prover" class="ui small image">
                        <img src="../../icowatchlist.com/logos/prover.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/prover">Prover</a>
                    </h3>
                    Technology of authenticity verification of video content                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/prover" class="ui green button">
                            31/08/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/prover" class="ui red button">
                            30/09/2017 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/planescloud" class="ui small image">
                        <img src="../../icowatchlist.com/logos/planescloud.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/planescloud">Planes Cloud</a>
                    </h3>
                    Decentralized data marketplace                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/planescloud" class="ui green button">
                            09/09/2017 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/planescloud" class="ui red button">
                            01/10/2017 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lustagency" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lustagency.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lustagency">Lust.agency</a>
                    </h3>
                    A decentralized sex marketplace with a goal to enable all human beings on earth to find their perfect sexual partner anonymously                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lustagency" class="ui green button">
                            18/08/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lustagency" class="ui red button">
                            02/10/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/powerledger" class="ui small image">
                        <img src="../../icowatchlist.com/logos/powerledger.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/powerledger">Power Ledger</a>
                    </h3>
                    Power Ledger is a blockchainbased peertopeer energy trading platform enabling consumers and businesses to share excess solar power with their neighbours                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/powerledger" class="ui green button">
                            08/09/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/powerledger" class="ui red button">
                            05/10/2017 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/domraider" class="ui small image">
                        <img src="../../icowatchlist.com/logos/domraider.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/domraider">DomRaider</a>
                    </h3>
                    Decentralized Blockchain auctions in realtime DRT tokens                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/domraider" class="ui green button">
                            12/09/2017 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/domraider" class="ui red button">
                            11/10/2017 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitjob" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitjob.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitjob">BitJob</a>
                    </h3>
                    Decentralized higher education  student community blockchain project                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitjob" class="ui green button">
                            02/08/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitjob" class="ui red button">
                            13/10/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eventchain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/eventchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eventchain">EventChain</a>
                    </h3>
                    Solving ticketing issues for the event industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eventchain" class="ui green button">
                            13/09/2017 00:13                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eventchain" class="ui red button">
                            14/10/2017 00:13                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hedgetoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hedgetoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hedgetoken">HEDGE TOKEN</a>
                    </h3>
                    The project is establishing a platform to help investors hedge their bets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hedgetoken" class="ui green button">
                            15/09/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hedgetoken" class="ui red button">
                            15/10/2017 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/paragoncoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/paragoncoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/paragoncoin">Paragon Coin</a>
                    </h3>
                    Bringing blockchain technology to the world of legal cannabis industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/paragoncoin" class="ui green button">
                            15/09/2017 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/paragoncoin" class="ui red button">
                            15/10/2017 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dlsacademy" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dlsacademy.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dlsacademy">DLS Academy</a>
                    </h3>
                    A tool that offers all you need for your professional growth and also a way to share knowledge and get paid or not                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dlsacademy" class="ui green button">
                            15/09/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dlsacademy" class="ui red button">
                            15/10/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethbet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethbet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbet">Ethbet</a>
                    </h3>
                    Ethbet is a decentralized peertopeer and provablyfair Ethereumbased dicing game without a house edge                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbet" class="ui green button">
                            17/09/2017 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethbet" class="ui red button">
                            15/10/2017 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eidoo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/eidoo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eidoo">Eidoo</a>
                    </h3>
                    Fast easy and not only a Multicurrency Wallet its a Hybrid Exchange too Its Eidoo                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eidoo" class="ui green button">
                            04/10/2017 00:01                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eidoo" class="ui red button">
                            16/10/2017 00:01                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/digi" class="ui small image">
                        <img src="../../icowatchlist.com/logos/digi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/digi">DIGI</a>
                    </h3>
                    Blockchain based digital goods and services                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/digi" class="ui green button">
                            07/09/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/digi" class="ui red button">
                            19/10/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/airtoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/airtoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/airtoken">AirToken</a>
                    </h3>
                    Mobile internet access using advertising and microloans                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/airtoken" class="ui green button">
                            19/09/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/airtoken" class="ui red button">
                            19/10/2017 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/chainlink" class="ui small image">
                        <img src="../../icowatchlist.com/logos/chainlink.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainlink">ChainLink</a>
                    </h3>
                    The LINK Network provides smart contracts with data bank payments and access to APIs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainlink" class="ui green button">
                            19/09/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/chainlink" class="ui red button">
                            19/10/2017 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mywillplatform" class="ui small image">
                        <img src="../../icowatchlist.com/logos/mywillplatform.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mywillplatform">MyWill Platform</a>
                    </h3>
                    Decentralized platform for crypto assets management in various life circumstances                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mywillplatform" class="ui green button">
                            19/09/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mywillplatform" class="ui red button">
                            20/10/2017 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/flypme" class="ui small image">
                        <img src="../../icowatchlist.com/logos/flypme.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/flypme">Flyp.me</a>
                    </h3>
                    The most private accountless exchange with 50 profit sharing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/flypme" class="ui green button">
                            28/09/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/flypme" class="ui red button">
                            21/10/2017 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cobinhood" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cobinhood.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cobinhood">COBINHOOD</a>
                    </h3>
                    COBINHOOD is the worlds first ZERO Trading Fees cryptocurrency exchange with the vision to maximize traders profits                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cobinhood" class="ui green button">
                            13/09/2017 09:29                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cobinhood" class="ui red button">
                            22/10/2017 09:29                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sexservice" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sexservice.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sexservice">Sex Service</a>
                    </h3>
                    A friendly sex dating service based on a blockchain Do you believe in sex                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sexservice" class="ui green button">
                            12/09/2017 23:59                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sexservice" class="ui red button">
                            22/10/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bookira" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bookira.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bookira">Bookira</a>
                    </h3>
                    Bookira is created to make the online booking process easier while reducing the risk and costs for users                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bookira" class="ui green button">
                            24/09/2017 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bookira" class="ui red button">
                            24/10/2017 01:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockv" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockv.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockv">BLOCKv</a>
                    </h3>
                    The foundation of the Virtual Goods Economy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockv" class="ui green button">
                            19/10/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockv" class="ui red button">
                            24/10/2017 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/chex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/chex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/chex">CHEX</a>
                    </h3>
                    Modular marketplace supernetwork initially powering the Cannabis industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/chex" class="ui green button">
                            25/08/2017 23:20                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/chex" class="ui red button">
                            24/10/2017 23:20                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/keytoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/keytoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/keytoken">KEY TOKEN</a>
                    </h3>
                    KeYtoken aims to establish the nextgeneration smartbank and a worldwide exchange network on blockchain platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/keytoken" class="ui green button">
                            25/09/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/keytoken" class="ui red button">
                            25/10/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/astronaut" class="ui small image">
                        <img src="../../icowatchlist.com/logos/astronaut.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/astronaut">Astronaut</a>
                    </h3>
                    An asset management platform for investing in ICOs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/astronaut" class="ui green button">
                            28/09/2017 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/astronaut" class="ui red button">
                            25/10/2017 23:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/clearpoll" class="ui small image">
                        <img src="../../icowatchlist.com/logos/clearpoll.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/clearpoll">ClearPoll</a>
                    </h3>
                    Social public opinion poll network on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/clearpoll" class="ui green button">
                            01/10/2017 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/clearpoll" class="ui red button">
                            25/10/2017 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/soma" class="ui small image">
                        <img src="../../icowatchlist.com/logos/soma.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/soma">Soma</a>
                    </h3>
                    A decentralized social market place                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/soma" class="ui green button">
                            26/09/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/soma" class="ui red button">
                            26/10/2017 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/swarmfund" class="ui small image">
                        <img src="../../icowatchlist.com/logos/swarmfund.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/swarmfund">Swarm Fund</a>
                    </h3>
                    Cooperative Ownership Platform for Real Assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/swarmfund" class="ui green button">
                            21/10/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/swarmfund" class="ui red button">
                            27/10/2017 23:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/langpie" class="ui small image">
                        <img src="../../icowatchlist.com/logos/langpie.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/langpie">LangPie</a>
                    </h3>
                    Onlinetranslation platform based on blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/langpie" class="ui green button">
                            28/09/2017 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/langpie" class="ui red button">
                            28/10/2017 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tokenlab" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tokenlab.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokenlab">Tokenlab</a>
                    </h3>
                    Tokenlab offers Token and ICO services to clients towards their fund raising campaigns                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tokenlab" class="ui green button">
                            14/09/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tokenlab" class="ui red button">
                            28/10/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/granthero" class="ui small image">
                        <img src="../../icowatchlist.com/logos/granthero.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/granthero">Grant Hero</a>
                    </h3>
                    The Grant Hero Foundation is a decentralized nonprofit organization that fosters direct personal giving Grant Hero enables donors to create and award personal grants direct to recipients offering complete autonomy and transparency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/granthero" class="ui green button">
                            02/10/2017 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/granthero" class="ui red button">
                            30/10/2017 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptopay" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptopay.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptopay">Cryptopay</a>
                    </h3>
                    Central entry point into a decentralized space                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptopay" class="ui green button">
                            25/09/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptopay" class="ui red button">
                            30/10/2017 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aeron" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aeron.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aeron">Aeron</a>
                    </h3>
                    Aeron  the new standard of aviation safety powered by blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aeron" class="ui green button">
                            18/09/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aeron" class="ui red button">
                            30/10/2017 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/assistivereality" class="ui small image">
                        <img src="../../icowatchlist.com/logos/assistivereality.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/assistivereality">Assistive Reality</a>
                    </h3>
                    AIintegrated Augmented Reality applications and cloud service                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/assistivereality" class="ui green button">
                            30/09/2017 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/assistivereality" class="ui red button">
                            31/10/2017 01:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bannercoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bannercoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bannercoin">BannerCoin</a>
                    </h3>
                    Payment processing system for acceptance of digital currencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bannercoin" class="ui green button">
                            15/09/2017 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bannercoin" class="ui red button">
                            31/10/2017 18:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/atlant" class="ui small image">
                        <img src="../../icowatchlist.com/logos/atlant.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/atlant">ATLANT</a>
                    </h3>
                    Atlant aims to be the Worlds Real Estate Blockchain Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/atlant" class="ui green button">
                            07/09/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/atlant" class="ui red button">
                            31/10/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aldoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aldoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aldoin">Aldoin</a>
                    </h3>
                    Green Blockchain  Mining with monthly dividends                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aldoin" class="ui green button">
                            22/08/2017 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aldoin" class="ui red button">
                            31/10/2017 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dentacoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dentacoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dentacoin">Dentacoin</a>
                    </h3>
                    Dentacoin The Blockchain Solution for the Global Dental Industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dentacoin" class="ui green button">
                            01/10/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dentacoin" class="ui red button">
                            01/11/2017 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethino" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethino.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethino">Ethino</a>
                    </h3>
                    The first and only erc20 Ethereum casino                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethino" class="ui green button">
                            02/10/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethino" class="ui red button">
                            02/11/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ripiocreditnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ripiocreditnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ripiocreditnetwork">Ripio Credit Network</a>
                    </h3>
                    A global peertopeer credit network based on cosigned smart contracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ripiocreditnetwork" class="ui green button">
                            24/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ripiocreditnetwork" class="ui red button">
                            05/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptotickets" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptotickets.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotickets">crypto.tickets</a>
                    </h3>
                    Blockchain platform for ticket systems and event organisers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotickets" class="ui green button">
                            05/10/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotickets" class="ui red button">
                            05/11/2017 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/utrust" class="ui small image">
                        <img src="../../icowatchlist.com/logos/utrust.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/utrust">Utrust</a>
                    </h3>
                    The future of online payments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/utrust" class="ui green button">
                            02/11/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/utrust" class="ui red button">
                            08/11/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/starbase" class="ui small image">
                        <img src="../../icowatchlist.com/logos/starbase.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/starbase">Starbase</a>
                    </h3>
                    A Platform for issuing tokens and launch crowdfunding projects                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/starbase" class="ui green button">
                            18/09/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/starbase" class="ui red button">
                            10/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/qvolta" class="ui small image">
                        <img src="../../icowatchlist.com/logos/qvolta.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/qvolta">Qvolta</a>
                    </h3>
                    Qvolta will let people convert cryptocurrencies into the fiat currencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/qvolta" class="ui green button">
                            10/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/qvolta" class="ui red button">
                            10/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/altocar" class="ui small image">
                        <img src="../../icowatchlist.com/logos/altocar.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/altocar">Altocar</a>
                    </h3>
                    Taxi rides aggregator service on the wave blockchain platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/altocar" class="ui green button">
                            10/10/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/altocar" class="ui red button">
                            10/11/2017 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptohive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptohive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohive">CryptoHive</a>
                    </h3>
                    Trading bot advisor with smart algorithms to gather useful trading information globally                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohive" class="ui green button">
                            10/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohive" class="ui red button">
                            11/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockstack" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockstack.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockstack">Blockstack</a>
                    </h3>
                    Blockstack has been designed as the new internet for decentralized apps                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockstack" class="ui green button">
                            01/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockstack" class="ui red button">
                            13/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/genesisvision" class="ui small image">
                        <img src="../../icowatchlist.com/logos/genesisvision.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/genesisvision">Genesis Vision</a>
                    </h3>
                    Genesis Vision is the platform for the private trust management market built on blockchain technology and smart contracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/genesisvision" class="ui green button">
                            15/09/2017 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/genesisvision" class="ui red button">
                            15/11/2017 09:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crederoom" class="ui small image">
                        <img src="../../icowatchlist.com/logos/crederoom.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crederoom">CREDEROOM</a>
                    </h3>
                    Lending company with modern analytical platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crederoom" class="ui green button">
                            16/10/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crederoom" class="ui red button">
                            15/11/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/privatix" class="ui small image">
                        <img src="../../icowatchlist.com/logos/privatix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/privatix">Privatix</a>
                    </h3>
                    First Internet Bandwidth Marketplace powered by P2P VPN Network on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/privatix" class="ui green button">
                            19/10/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/privatix" class="ui red button">
                            16/11/2017 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/copico" class="ui small image">
                        <img src="../../icowatchlist.com/logos/copico.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/copico">COPICO</a>
                    </h3>
                    COPICO is the project powering the XCPO masternode Coin                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/copico" class="ui green button">
                            17/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/copico" class="ui red button">
                            17/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/micromoney" class="ui small image">
                        <img src="../../icowatchlist.com/logos/micromoney.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/micromoney">MicroMoney</a>
                    </h3>
                    MicroMoney is an Open Source Credit  Big Data Bureau that connects new customers to all existing financial services                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/micromoney" class="ui green button">
                            18/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/micromoney" class="ui red button">
                            18/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/careerxon" class="ui small image">
                        <img src="../../icowatchlist.com/logos/careerxon.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/careerxon">CareerXon</a>
                    </h3>
                    First Decentralized Career Oriented  Skills Training Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/careerxon" class="ui green button">
                            04/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/careerxon" class="ui red button">
                            18/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cashpoker" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cashpoker.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cashpoker">Cash Poker Pro</a>
                    </h3>
                    Modern online poker room based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cashpoker" class="ui green button">
                            26/10/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cashpoker" class="ui red button">
                            18/11/2017 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/happiestatwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/happiestatwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/happiestatwork">Happiest at work</a>
                    </h3>
                    Attracting people to work in the clothing manufacturing industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/happiestatwork" class="ui green button">
                            23/10/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/happiestatwork" class="ui red button">
                            20/11/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/synapse" class="ui small image">
                        <img src="../../icowatchlist.com/logos/synapse.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/synapse">Synapse</a>
                    </h3>
                    Decentralized Data and AI Marketplace                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/synapse" class="ui green button">
                            21/10/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/synapse" class="ui red button">
                            21/11/2017 14:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wandx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wandx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wandx">WandX</a>
                    </h3>
                    Decentralized financial instruments on ERC20 tokens                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wandx" class="ui green button">
                            22/10/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wandx" class="ui red button">
                            21/11/2017 19:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockbid" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockbid.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockbid">Blockbid</a>
                    </h3>
                    Blockbid is an ultrasecure exchange with the goal of facilitating the highest volume of trades for the most cryptocurrencies with a single login                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockbid" class="ui green button">
                            21/10/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockbid" class="ui red button">
                            21/11/2017 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/confideal" class="ui small image">
                        <img src="../../icowatchlist.com/logos/confideal.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/confideal">Confideal</a>
                    </h3>
                    Escrow Platform on The Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/confideal" class="ui green button">
                            02/11/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/confideal" class="ui red button">
                            22/11/2017 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/safechildfuture" class="ui small image">
                        <img src="../../icowatchlist.com/logos/safechildfuture.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/safechildfuture">Safe Child Future</a>
                    </h3>
                    The child safety system that will be used to protect children on the roads and streets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/safechildfuture" class="ui green button">
                            23/10/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/safechildfuture" class="ui red button">
                            23/11/2017 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/multibot" class="ui small image">
                        <img src="../../icowatchlist.com/logos/multibot.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/multibot">Multibot</a>
                    </h3>
                    A multifunctional multithreaded trading platform in the cloud                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/multibot" class="ui green button">
                            20/10/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/multibot" class="ui red button">
                            24/11/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/zeus" class="ui small image">
                        <img src="../../icowatchlist.com/logos/zeus.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/zeus">ZEUS</a>
                    </h3>
                    First Ecomining in the World Recycling platform on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/zeus" class="ui green button">
                            24/10/2017 22:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/zeus" class="ui red button">
                            24/11/2017 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bonpay" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bonpay.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bonpay">Bonpay</a>
                    </h3>
                    Blockchain powered wallet and debit card for variety of cryptocurrencies Bonpay makes transactions as simple as possible                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bonpay" class="ui green button">
                            31/10/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bonpay" class="ui red button">
                            28/11/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wax" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wax.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wax">WAX</a>
                    </h3>
                    A decentralized platform that enables anyone to operate a fully functioning virtual asset marketplace                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wax" class="ui green button">
                            01/11/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wax" class="ui red button">
                            29/11/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/storm" class="ui small image">
                        <img src="../../icowatchlist.com/logos/storm.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/storm">Storm</a>
                    </h3>
                    Creating the StorMarket  a decentralized microtask marketplace platform                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/storm" class="ui green button">
                            01/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/storm" class="ui red button">
                            30/11/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/playkeyio" class="ui small image">
                        <img src="../../icowatchlist.com/logos/playkeyio.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/playkeyio">Playkey.io</a>
                    </h3>
                    Decentralized Cloud Gaming Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/playkeyio" class="ui green button">
                            01/11/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/playkeyio" class="ui red button">
                            30/11/2017 03:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sense" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sense.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sense">SENSE</a>
                    </h3>
                    The Value for Human Capital Enabled by Smart Contracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sense" class="ui green button">
                            07/11/2017 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sense" class="ui red button">
                            30/11/2017 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vezt-ico" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vezt-ico.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vezt-ico">Vezt ICO</a>
                    </h3>
                    Vezt lets music fans share ownership with artists in their favorite songs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vezt-ico" class="ui green button">
                            03/11/2017 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vezt-ico" class="ui red button">
                            30/11/2017 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/coppay" class="ui small image">
                        <img src="../../icowatchlist.com/logos/coppay.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/coppay">CopPay</a>
                    </h3>
                    Multicryptocurrency payment platform for businesses consumers  community                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/coppay" class="ui green button">
                            30/10/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/coppay" class="ui red button">
                            30/11/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ccore" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ccore.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ccore">CCORE</a>
                    </h3>
                    Your Crypto Payment Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ccore" class="ui green button">
                            09/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ccore" class="ui red button">
                            30/11/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/publica" class="ui small image">
                        <img src="../../icowatchlist.com/logos/publica.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/publica">Publica</a>
                    </h3>
                    Blockchain revolution for the publishing economy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/publica" class="ui green button">
                            31/10/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/publica" class="ui red button">
                            30/11/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dmarket" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dmarket.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dmarket">DMarket</a>
                    </h3>
                    Dmarket  the first decentralized marketplace where you can trade all your ingame items globally                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dmarket" class="ui green button">
                            17/10/2017 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dmarket" class="ui red button">
                            01/12/2017 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/verifyunion" class="ui small image">
                        <img src="../../icowatchlist.com/logos/verifyunion.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/verifyunion">VerifyUnion</a>
                    </h3>
                    Decentralized Platform for Digital Identification and Social Scoring Engine                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/verifyunion" class="ui green button">
                            03/10/2017 03:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/verifyunion" class="ui red button">
                            03/12/2017 03:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/geens" class="ui small image">
                        <img src="../../icowatchlist.com/logos/geens.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/geens">Geens</a>
                    </h3>
                    Privacy Focused Blockchain Timestamping Office                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/geens" class="ui green button">
                            07/11/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/geens" class="ui red button">
                            07/12/2017 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/jboxcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/jboxcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/jboxcoin">JBOXCOIN</a>
                    </h3>
                    A Blockchain based decentralized video streaming platform                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/jboxcoin" class="ui green button">
                            08/11/2017 02:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/jboxcoin" class="ui red button">
                            08/12/2017 02:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dimnd" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dimnd.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dimnd">DIMND</a>
                    </h3>
                    Digital Currency powered by Ethreum represented by Diamonds                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dimnd" class="ui green button">
                            07/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dimnd" class="ui red button">
                            10/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/algoland" class="ui small image">
                        <img src="../../icowatchlist.com/logos/algoland.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/algoland">algo.land</a>
                    </h3>
                    The autonomous algorithmic trading blockchain fund                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/algoland" class="ui green button">
                            31/10/2017 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/algoland" class="ui red button">
                            10/12/2017 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/amlbitcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/amlbitcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/amlbitcoin">AML Bitcoin</a>
                    </h3>
                    AML BitCoin is the first AML KYC compliant coin for legitimate financial use on a global scale                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/amlbitcoin" class="ui green button">
                            06/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/amlbitcoin" class="ui red button">
                            15/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/worldcore" class="ui small image">
                        <img src="../../icowatchlist.com/logos/worldcore.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldcore">Worldcore</a>
                    </h3>
                    Modern Banking Solutions For The Digital World Tomorrow                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/worldcore" class="ui green button">
                            13/10/2017 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/worldcore" class="ui red button">
                            14/12/2017 23:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/delphisystems" class="ui small image">
                        <img src="../../icowatchlist.com/logos/delphisystems.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/delphisystems">Delphi Systems</a>
                    </h3>
                    Oracle Platform and Prediction Market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/delphisystems" class="ui green button">
                            01/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/delphisystems" class="ui red button">
                            15/12/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aigang" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aigang.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aigang">Aigang Network</a>
                    </h3>
                    Blockchain Protocol for Digital Insurance built for InternetofThings                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aigang" class="ui green button">
                            15/11/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aigang" class="ui red button">
                            15/12/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/medibloc" class="ui small image">
                        <img src="../../icowatchlist.com/logos/medibloc.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/medibloc">MediBloc</a>
                    </h3>
                    The largest healthcare blockchain Medibloc will help champion the worlds shift to private information decentralization                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/medibloc" class="ui green button">
                            20/11/2017 02:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/medibloc" class="ui red button">
                            15/12/2017 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nagagroup" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nagagroup.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nagagroup">NAGA Group</a>
                    </h3>
                    Smart Cryptocurrency for gaming and trading                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nagagroup" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nagagroup" class="ui red button">
                            15/12/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/xred" class="ui small image">
                        <img src="../../icowatchlist.com/logos/xred.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/xred">XRED</a>
                    </h3>
                    The First Cryptocurrency fund for real estate development and investment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/xred" class="ui green button">
                            01/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/xred" class="ui red button">
                            15/12/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vegaaisolutions" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vegaaisolutions.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vegaaisolutions">Vega AI Solutions</a>
                    </h3>
                    Automated Intelligent Trading App Help Traders and Investors Get Good Returns On Their Investments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vegaaisolutions" class="ui green button">
                            24/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vegaaisolutions" class="ui red button">
                            16/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/prosenselive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/prosenselive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/prosenselive">ProsenseLive</a>
                    </h3>
                    ProsenseLive is the worlds first decentralized peertopeer livestreaming platform for the distribution of virtual reality content                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/prosenselive" class="ui green button">
                            19/10/2017 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/prosenselive" class="ui red button">
                            16/12/2017 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/neufund" class="ui small image">
                        <img src="../../icowatchlist.com/logos/neufund.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/neufund">Neufund</a>
                    </h3>
                    Neufund is a communityowned fundraising platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/neufund" class="ui green button">
                            17/11/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/neufund" class="ui red button">
                            17/12/2017 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sophiatx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sophiatx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sophiatx">SophiaTX</a>
                    </h3>
                    Blockchain PlatformMarketplace integrating business apps  solutions to collaborative environments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sophiatx" class="ui green button">
                            07/12/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sophiatx" class="ui red button">
                            17/12/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/investy" class="ui small image">
                        <img src="../../icowatchlist.com/logos/investy.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/investy">Investy</a>
                    </h3>
                    Investy is a platform for decentralized investments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/investy" class="ui green button">
                            23/11/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/investy" class="ui red button">
                            17/12/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/chainium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/chainium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainium">Chainium</a>
                    </h3>
                    We are reinventing the global equity market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainium" class="ui green button">
                            27/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/chainium" class="ui red button">
                            18/12/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/miniappspro" class="ui small image">
                        <img src="../../icowatchlist.com/logos/miniappspro.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/miniappspro">MiniApps.pro</a>
                    </h3>
                    AI and Blockchain Powered Chatbot Ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/miniappspro" class="ui green button">
                            18/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/miniappspro" class="ui red button">
                            19/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/foreground" class="ui small image">
                        <img src="../../icowatchlist.com/logos/foreground.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/foreground">Foreground</a>
                    </h3>
                    Foreground is an affiliate marketing solution for the traditional internet and the rapidly growing decentralized web                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/foreground" class="ui green button">
                            28/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/foreground" class="ui red button">
                            19/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/novacool" class="ui small image">
                        <img src="../../icowatchlist.com/logos/novacool.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/novacool">NOVAcool</a>
                    </h3>
                    The first immersion cooling system for PC                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/novacool" class="ui green button">
                            28/09/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/novacool" class="ui red button">
                            19/12/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/connectius" class="ui small image">
                        <img src="../../icowatchlist.com/logos/connectius.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/connectius">Connectius</a>
                    </h3>
                    Connectius  a blockchain SaaS solution for ecommerce                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/connectius" class="ui green button">
                            20/11/2017 20:59                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/connectius" class="ui red button">
                            19/12/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/regarisksharing" class="ui small image">
                        <img src="../../icowatchlist.com/logos/regarisksharing.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/regarisksharing">REGA Risk Sharing</a>
                    </h3>
                    Aims to unlock the power of blockchain technology to revolutionize traditional insurance industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/regarisksharing" class="ui green button">
                            15/10/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/regarisksharing" class="ui red button">
                            20/12/2017 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/propthereum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/propthereum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/propthereum">Propthereum</a>
                    </h3>
                    Tokens bought with Ethereum and distributed to participants backed by immoveable property                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/propthereum" class="ui green button">
                            20/11/2017 11:59                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/propthereum" class="ui red button">
                            20/12/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethersport" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethersport.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethersport">EtherSport</a>
                    </h3>
                    Online Sports Lottery Platform with Provably Fair Results 15 Profit Share for Token Holders                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethersport" class="ui green button">
                            13/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethersport" class="ui red button">
                            20/12/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/indahash" class="ui small image">
                        <img src="../../icowatchlist.com/logos/indahash.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/indahash">indaHash</a>
                    </h3>
                    Indahash is tokenizing the influencer industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/indahash" class="ui green button">
                            29/11/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/indahash" class="ui red button">
                            20/12/2017 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/debitumnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/debitumnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/debitumnetwork">Debitum Network</a>
                    </h3>
                    Borderless SME business financing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/debitumnetwork" class="ui green button">
                            07/12/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/debitumnetwork" class="ui red button">
                            21/12/2017 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kevin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kevin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kevin">kevin</a>
                    </h3>
                    kevin is an innovative online banking service that allows to easily link and manage different crypto accounts and bank accounts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kevin" class="ui green button">
                            17/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kevin" class="ui red button">
                            22/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hdac" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hdac.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hdac">Hdac</a>
                    </h3>
                    Hdac is the worlds 1st IoT Contract  Payment Platform based on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hdac" class="ui green button">
                            27/11/2017 23:58                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hdac" class="ui red button">
                            22/12/2017 23:58                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethereumhigh" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethereumhigh.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethereumhigh">Ethereum High</a>
                    </h3>
                    Ethereum High is a robust and featherlight cryptocurrency designed to hedge the risk of your portfolio                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethereumhigh" class="ui green button">
                            20/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethereumhigh" class="ui red button">
                            24/12/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/binarycom" class="ui small image">
                        <img src="../../icowatchlist.com/logos/binarycom.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/binarycom">Binary.com</a>
                    </h3>
                    The easiest way to get started in the financial market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/binarycom" class="ui green button">
                            15/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/binarycom" class="ui red button">
                            25/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/finney" class="ui small image">
                        <img src="../../icowatchlist.com/logos/finney.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/finney">Finney</a>
                    </h3>
                    Sirin Labs is building an ultra secured  open sourced communication device for the blockchain era                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/finney" class="ui green button">
                            12/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/finney" class="ui red button">
                            25/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/remme" class="ui small image">
                        <img src="../../icowatchlist.com/logos/remme.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/remme">REMME</a>
                    </h3>
                    Access Management solution replacing passwords with the distributed authentication                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/remme" class="ui green button">
                            04/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/remme" class="ui red button">
                            25/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/insecosystem" class="ui small image">
                        <img src="../../icowatchlist.com/logos/insecosystem.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/insecosystem">INS Ecosystem</a>
                    </h3>
                    Decentralized ecosystem directly connecting grocery manufacturers and consumers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/insecosystem" class="ui green button">
                            04/12/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/insecosystem" class="ui red button">
                            25/12/2017 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/prosumeenergy" class="ui small image">
                        <img src="../../icowatchlist.com/logos/prosumeenergy.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/prosumeenergy">Prosume Energy</a>
                    </h3>
                    The biggest energy revolution ever                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/prosumeenergy" class="ui green button">
                            06/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/prosumeenergy" class="ui red button">
                            25/12/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/canya" class="ui small image">
                        <img src="../../icowatchlist.com/logos/canya.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/canya">CanYa</a>
                    </h3>
                    Real working platform for a 2 trillion dollar peer to peer market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/canya" class="ui green button">
                            25/11/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/canya" class="ui red button">
                            25/12/2017 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/decentralizedescrow" class="ui small image">
                        <img src="../../icowatchlist.com/logos/decentralizedescrow.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralizedescrow">Decentralized Escrow</a>
                    </h3>
                    DesAnti Scam helps to protect blockchain investors from financial losses                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralizedescrow" class="ui green button">
                            29/11/2017 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/decentralizedescrow" class="ui red button">
                            27/12/2017 08:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethlend" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethlend.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethlend">EthLend</a>
                    </h3>
                    ETHLend a blockchain startup that introduces decentralized lending it aims to enable decentralized lending globally by allowing crypto borrowing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethlend" class="ui green button">
                            25/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethlend" class="ui red button">
                            27/12/2017 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bankex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bankex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bankex">BANKEX</a>
                    </h3>
                    A ProofofAsset Protocol that brings together BankasaService and Blockchain technology to evolve capital markets Tokenization of realworld and financial assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bankex" class="ui green button">
                            28/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bankex" class="ui red button">
                            28/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/spectiv" class="ui small image">
                        <img src="../../icowatchlist.com/logos/spectiv.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/spectiv">Spectiv</a>
                    </h3>
                    Spectiv is a signal token protocol                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/spectiv" class="ui green button">
                            08/12/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/spectiv" class="ui red button">
                            29/12/2017 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nau" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nau.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nau">NAU</a>
                    </h3>
                    NAU directly links buyers and sellers n a retail market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nau" class="ui green button">
                            31/10/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nau" class="ui red button">
                            29/12/2017 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/daoplaymarket20" class="ui small image">
                        <img src="../../icowatchlist.com/logos/daoplaymarket20.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/daoplaymarket20">DAO PlayMarket 2.0</a>
                    </h3>
                    A decentralized Android app store combined with an ICO developer platform crypto exchange that accepts payment in cryptocurrency                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/daoplaymarket20" class="ui green button">
                            07/11/2017 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/daoplaymarket20" class="ui red button">
                            29/12/2017 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lhcrypto" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lhcrypto.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lhcrypto">LH-Crypto</a>
                    </h3>
                    LHCoin is a token with monthly income from operational activities                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lhcrypto" class="ui green button">
                            30/10/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lhcrypto" class="ui red button">
                            30/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/liveshow" class="ui small image">
                        <img src="../../icowatchlist.com/logos/liveshow.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/liveshow">LiveShow</a>
                    </h3>
                    LIVESHOW is creating a webcam platform of a new generation which is based on blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/liveshow" class="ui green button">
                            09/11/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/liveshow" class="ui red button">
                            29/12/2017 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/styras" class="ui small image">
                        <img src="../../icowatchlist.com/logos/styras.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/styras">STYRAS</a>
                    </h3>
                    STYRAS Connects everyone anywhere and everywhere                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/styras" class="ui green button">
                            21/11/2017 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/styras" class="ui red button">
                            30/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/odmcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/odmcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/odmcoin">ODMCoin</a>
                    </h3>
                    First investment blockchain option in the oil and gas sector                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/odmcoin" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/odmcoin" class="ui red button">
                            31/12/2017 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/freedomstreaming" class="ui small image">
                        <img src="../../icowatchlist.com/logos/freedomstreaming.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/freedomstreaming">Freedom Streaming</a>
                    </h3>
                    Freedom Streaming offers a full live streaming platform that allows you to stream from anywhere in the world uncensored safe and anonymously                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/freedomstreaming" class="ui green button">
                            15/11/2017 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/freedomstreaming" class="ui red button">
                            31/12/2017 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/familypoints" class="ui small image">
                        <img src="../../icowatchlist.com/logos/familypoints.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/familypoints">FamilyPoints</a>
                    </h3>
                    Bringing Smart Contacts to Smart Parents                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/familypoints" class="ui green button">
                            01/12/2017 04:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/familypoints" class="ui red button">
                            01/01/2018 03:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptonetix" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptonetix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonetix">Cryptonetix</a>
                    </h3>
                    Cryptonetix will be the foremost blockchain asset management analytics funding and educational platform for the rapidly growing cryptocurrency markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonetix" class="ui green button">
                            15/11/2017 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonetix" class="ui red button">
                            01/01/2018 05:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fantasymarket" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fantasymarket.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fantasymarket">Fantasy Market</a>
                    </h3>
                    Fantasy Market is an innovative marketplace where users control the performers through the use of our token                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fantasymarket" class="ui green button">
                            03/12/2017 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fantasymarket" class="ui red button">
                            01/01/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/loanorlease" class="ui small image">
                        <img src="../../icowatchlist.com/logos/loanorlease.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/loanorlease">Loan or Lease</a>
                    </h3>
                    Decentralized Lending Network of Masternodes                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/loanorlease" class="ui green button">
                            01/12/2017 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/loanorlease" class="ui red button">
                            04/01/2018 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tradeio" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tradeio.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tradeio">Trade.io</a>
                    </h3>
                    tradeio is an innovative new blockchain trading platform that will disrupt the financial ecosystem and democratize the markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tradeio" class="ui green button">
                            07/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tradeio" class="ui red button">
                            04/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cybertrust" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cybertrust.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cybertrust">CyberTrust</a>
                    </h3>
                    We help Banks buy Bitcoin                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cybertrust" class="ui green button">
                            28/11/2017 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cybertrust" class="ui red button">
                            05/01/2018 20:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockchaintradedfund" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockchaintradedfund.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaintradedfund">Blockchain Traded Fund</a>
                    </h3>
                    The Blockchain Traded Fund is a closed ended fund that invests in the best Ethereum                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaintradedfund" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockchaintradedfund" class="ui red button">
                            06/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ucash" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ucash.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ucash">U.CASH</a>
                    </h3>
                    Cash meets digital currencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ucash" class="ui green button">
                            08/09/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ucash" class="ui red button">
                            07/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/starsgroup" class="ui small image">
                        <img src="../../icowatchlist.com/logos/starsgroup.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/starsgroup">Stars Group</a>
                    </h3>
                    Progressive financial infrastructure for professional footballers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/starsgroup" class="ui green button">
                            15/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/starsgroup" class="ui red button">
                            10/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/swissborg" class="ui small image">
                        <img src="../../icowatchlist.com/logos/swissborg.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/swissborg">SwissBorg</a>
                    </h3>
                    The New Era of Swiss Private Banking with Smart Contracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/swissborg" class="ui green button">
                            07/12/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/swissborg" class="ui red button">
                            10/01/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lendoit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lendoit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lendoit">LENDOIT</a>
                    </h3>
                    Lendoit is the only True Decentralized P2P Lending Platform using Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lendoit" class="ui green button">
                            13/12/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lendoit" class="ui red button">
                            13/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crypterium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/crypterium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crypterium">Crypterium</a>
                    </h3>
                    Digital mobile cryptobank                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crypterium" class="ui green button">
                            31/10/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crypterium" class="ui red button">
                            14/01/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/envionevn" class="ui small image">
                        <img src="../../icowatchlist.com/logos/envionevn.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/envionevn">envion (EVN)</a>
                    </h3>
                    ENVION makes mining green  mobile                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/envionevn" class="ui green button">
                            15/12/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/envionevn" class="ui red button">
                            14/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gatcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/gatcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gatcoin">Gatcoin</a>
                    </h3>
                    GATCOIN transforms traditional discount coupons loyalty points and shopping vouchers into liquid tradable digital tokens                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gatcoin" class="ui green button">
                            14/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gatcoin" class="ui red button">
                            14/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/covesting" class="ui small image">
                        <img src="../../icowatchlist.com/logos/covesting.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/covesting">Covesting</a>
                    </h3>
                    Revolutionary copytrading platform combined with the most complete infrastructure for investors and cryptocurrency traders                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/covesting" class="ui green button">
                            24/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/covesting" class="ui red button">
                            15/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/appcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/appcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/appcoin">AppCoins</a>
                    </h3>
                    AppCoins is the first cryptocurrency for app stores serving 200 million active users                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/appcoin" class="ui green button">
                            13/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/appcoin" class="ui red button">
                            15/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tzero" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tzero.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tzero">tZERO</a>
                    </h3>
                    The tZERO platform integrates cryptographically secure distributed ledgers with existing market processes to reduce settlement time and costs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tzero" class="ui green button">
                            18/12/2017 19:32                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tzero" class="ui red button">
                            18/01/2018 19:32                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/solareum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/solareum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/solareum">Solareum</a>
                    </h3>
                    Solareum brings solar energy on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/solareum" class="ui green button">
                            25/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/solareum" class="ui red button">
                            18/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/travelflexcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/travelflexcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/travelflexcoin">TravelFlex Coin</a>
                    </h3>
                    New DAG tech based cryptocurrency decentralized social travel network and payment system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/travelflexcoin" class="ui green button">
                            13/12/2017 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/travelflexcoin" class="ui red button">
                            22/01/2018 03:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/elastos" class="ui small image">
                        <img src="../../icowatchlist.com/logos/elastos.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/elastos">Elastos</a>
                    </h3>
                    Blockchain with totally decentralized P2P economic infrastructure which authenticates digital rights and turns digital information into assets                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/elastos" class="ui green button">
                            02/01/2018 18:47                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/elastos" class="ui red button">
                            23/01/2018 18:48                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/realestatecoupon" class="ui small image">
                        <img src="../../icowatchlist.com/logos/realestatecoupon.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/realestatecoupon">Real Estate Coupon</a>
                    </h3>
                    The First Real Estate Coupon Ethereum Token for Purchasing Properties                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/realestatecoupon" class="ui green button">
                            16/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/realestatecoupon" class="ui red button">
                            25/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitdegree" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitdegree.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdegree">BitDegree</a>
                    </h3>
                    The worlds first blockchainpowered online education platform with token scholarships  tech talent acquisition                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdegree" class="ui green button">
                            01/12/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitdegree" class="ui red button">
                            25/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/liveedu" class="ui small image">
                        <img src="../../icowatchlist.com/logos/liveedu.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/liveedu">LiveEdu</a>
                    </h3>
                    LiveEdu is Youtube for Online Education the nextgeneration Lyndacom                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/liveedu" class="ui green button">
                            15/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/liveedu" class="ui red button">
                            26/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/propify" class="ui small image">
                        <img src="../../icowatchlist.com/logos/propify.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/propify">Propify</a>
                    </h3>
                    The Decentralized Real Estate Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/propify" class="ui green button">
                            14/12/2017 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/propify" class="ui red button">
                            26/01/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/jibrelnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/jibrelnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/jibrelnetwork">Jibrel Network</a>
                    </h3>
                    Jibrel provides traditional financial assets such as currencies bonds and equities as standard ERC20 tokens on the Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/jibrelnetwork" class="ui green button">
                            27/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/jibrelnetwork" class="ui red button">
                            26/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/polymath" class="ui small image">
                        <img src="../../icowatchlist.com/logos/polymath.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/polymath">Polymath</a>
                    </h3>
                    Polimath is the interface between financial securities and the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/polymath" class="ui green button">
                            27/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/polymath" class="ui red button">
                            27/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/storiqa" class="ui small image">
                        <img src="../../icowatchlist.com/logos/storiqa.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/storiqa">Storiqa</a>
                    </h3>
                    Storiqa  a marketplace with a wide range of functions for effective sales in the world of a new digital economy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/storiqa" class="ui green button">
                            29/11/2017 18:20                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/storiqa" class="ui red button">
                            29/01/2018 18:20                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gameflip" class="ui small image">
                        <img src="../../icowatchlist.com/logos/gameflip.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gameflip">Gameflip - FLIP (FLP)</a>
                    </h3>
                    FLIP Cryptotoken for gamers from gaming experts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gameflip" class="ui green button">
                            04/12/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gameflip" class="ui red button">
                            29/01/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vimarket" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vimarket.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vimarket">ViMarket</a>
                    </h3>
                    A 3D marketplace that allows users to create and share virtual reality VR experiences ViMarket promises to bring about a muchneeded breakthrough in the global ecommerce ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vimarket" class="ui green button">
                            07/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vimarket" class="ui red button">
                            31/01/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/pocketinns" class="ui small image">
                        <img src="../../icowatchlist.com/logos/pocketinns.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/pocketinns">Pocketinns</a>
                    </h3>
                    The worlds first decentralized blockchain driven marketplace ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/pocketinns" class="ui green button">
                            15/01/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/pocketinns" class="ui red button">
                            31/01/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crowdwiz" class="ui small image">
                        <img src="../../icowatchlist.com/logos/crowdwiz.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdwiz">Crowdwiz</a>
                    </h3>
                    CrowdWiz  Bringing the future of investment into your hands                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdwiz" class="ui green button">
                            20/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdwiz" class="ui red button">
                            31/01/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/the-bee-token" class="ui small image">
                        <img src="../../icowatchlist.com/logos/the-bee-token.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/the-bee-token">The Bee Token</a>
                    </h3>
                    Decentralizing ShortTerm Housing Rentals Blockchain Powered Platform With 0 Commissions Network Effects                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/the-bee-token" class="ui green button">
                            02/01/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/the-bee-token" class="ui red button">
                            31/01/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/shipchain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/shipchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/shipchain">ShipChain</a>
                    </h3>
                    Disrupting transport and logistics on the Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/shipchain" class="ui green button">
                            01/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/shipchain" class="ui red button">
                            31/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/shping" class="ui small image">
                        <img src="../../icowatchlist.com/logos/shping.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/shping">Shping</a>
                    </h3>
                    Shping is an innovative shoppermarketing ecosystem that enables participating brands and organisations the opportunity to reward shoppers who use the Shping App with a new cryptocurrency called Shping Coin                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/shping" class="ui green button">
                            22/01/2018 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/shping" class="ui red button">
                            01/02/2018 00:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iungo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/iungo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iungo">IUNGO</a>
                    </h3>
                    Global wireless internet service providerpowered by blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iungo" class="ui green button">
                            07/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iungo" class="ui red button">
                            31/01/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/uservice" class="ui small image">
                        <img src="../../icowatchlist.com/logos/uservice.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/uservice">Uservice</a>
                    </h3>
                    Global Decentralized Blockchain Platform For Automotive Industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/uservice" class="ui green button">
                            20/11/2017 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/uservice" class="ui red button">
                            01/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aidcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aidcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aidcoin">AidCoin</a>
                    </h3>
                    AidCoin is the token for charitable giving built on Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aidcoin" class="ui green button">
                            16/01/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aidcoin" class="ui red button">
                            01/02/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/energitoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/energitoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/energitoken">EnergiToken</a>
                    </h3>
                    EnergiToken rewards energy saving behaviour                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/energitoken" class="ui green button">
                            01/02/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/energitoken" class="ui red button">
                            01/02/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wepower" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wepower.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wepower">WePower</a>
                    </h3>
                    WePower is launching blockchain and smart contracts powered green energy trading platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wepower" class="ui green button">
                            01/02/2018 21:49                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wepower" class="ui red button">
                            02/02/2018 21:50                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/inspeer" class="ui small image">
                        <img src="../../icowatchlist.com/logos/inspeer.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/inspeer">Inspeer</a>
                    </h3>
                    A Peertopeer lending service that works with Cryptocurrency and Fiat                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/inspeer" class="ui green button">
                            11/12/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/inspeer" class="ui red button">
                            05/02/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sharpecapital" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sharpecapital.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sharpecapital">Sharpe Capital</a>
                    </h3>
                    Sharpe Capital is a blockchain based investment fund that invests in cryptocurrency assets based on predictions from token holders Token holders who make accurate predictions earn Ether                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sharpecapital" class="ui green button">
                            06/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sharpecapital" class="ui red button">
                            05/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/escapetoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/escapetoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/escapetoken">EscapeToken</a>
                    </h3>
                    Escape games booking service powered by Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/escapetoken" class="ui green button">
                            23/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/escapetoken" class="ui red button">
                            09/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/arcblock" class="ui small image">
                        <img src="../../icowatchlist.com/logos/arcblock.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/arcblock">ArcBlock</a>
                    </h3>
                    ArcBlock is a platform and an ecosystem for building and deploying decentralized blockchain applications                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/arcblock" class="ui green button">
                            04/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/arcblock" class="ui red button">
                            10/02/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fusion" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fusion.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fusion">Fusion</a>
                    </h3>
                    Blockchain based inclusive cryptofinance platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fusion" class="ui green button">
                            01/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fusion" class="ui red button">
                            10/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/scorum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/scorum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/scorum">Scorum</a>
                    </h3>
                    Scorum is the first sports social media powered by blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/scorum" class="ui green button">
                            14/01/2018 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/scorum" class="ui red button">
                            11/02/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/3dtoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/3dtoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/3dtoken">3D-Token</a>
                    </h3>
                    The glocal decentralized justintime factory 40                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/3dtoken" class="ui green button">
                            18/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/3dtoken" class="ui red button">
                            11/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/redmegawattmwat" class="ui small image">
                        <img src="../../icowatchlist.com/logos/redmegawattmwat.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/redmegawattmwat">REDMegaWatt</a>
                    </h3>
                    Major EU energy company launches energy trading ecosystem and the first power retail franchise                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/redmegawattmwat" class="ui green button">
                            15/01/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/redmegawattmwat" class="ui red button">
                            12/02/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/skraps" class="ui small image">
                        <img src="../../icowatchlist.com/logos/skraps.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/skraps">Skraps</a>
                    </h3>
                    Invest your spare change into diversified portfolios of cryptocurrencies and crypto assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/skraps" class="ui green button">
                            15/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/skraps" class="ui red button">
                            14/02/2018 11:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dether" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dether.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dether">Dether</a>
                    </h3>
                    Buy  sell crypto for cash Spend it at physical stores                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dether" class="ui green button">
                            07/02/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dether" class="ui red button">
                            14/02/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/digitcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/digitcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/digitcoin">DIGIT Coin</a>
                    </h3>
                    Empowering BlockchainBased Digital Marketing The Most Powerful Digital Marketing Solutions on Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/digitcoin" class="ui green button">
                            08/12/2017 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/digitcoin" class="ui red button">
                            14/02/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptoibet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptoibet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoibet">cryptoibet</a>
                    </h3>
                    CryptoIBet is the next generation platform for online gaming experience                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoibet" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptoibet" class="ui red button">
                            15/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bmarkt" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bmarkt.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bmarkt">BMarkt</a>
                    </h3>
                    Futureoriented platorm for exchanging real objects for cryptocurrency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bmarkt" class="ui green button">
                            15/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bmarkt" class="ui red button">
                            15/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fuzex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fuzex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fuzex">FuzeX</a>
                    </h3>
                    FuzeX offers an all in one payment solution that provides a smarter way to pay Paying with cryptocurrency debit credit and reward cards is easier                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fuzex" class="ui green button">
                            15/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fuzex" class="ui red button">
                            15/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/matrix" class="ui small image">
                        <img src="../../icowatchlist.com/logos/matrix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/matrix">MATRIX</a>
                    </h3>
                    Matrix has been built as a distributed network of artificial intelligence and blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/matrix" class="ui green button">
                            15/01/2018 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/matrix" class="ui red button">
                            14/02/2018 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/krios" class="ui small image">
                        <img src="../../icowatchlist.com/logos/krios.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/krios">Krios</a>
                    </h3>
                    Decentralised digital marketing platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/krios" class="ui green button">
                            08/01/2018 22:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/krios" class="ui red button">
                            16/02/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/republic-protocol" class="ui small image">
                        <img src="../../icowatchlist.com/logos/republic-protocol.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/republic-protocol">Republic Protocol</a>
                    </h3>
                    An opensource decentralized dark pool for trustless crosschain atomic trading of Ether ERC20 tokens and Bitcoin pairs                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/republic-protocol" class="ui green button">
                            03/02/2018 05:56                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/republic-protocol" class="ui red button">
                            17/02/2018 05:56                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vaultbank" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vaultbank.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vaultbank">VaultBank</a>
                    </h3>
                    A blueprint for disintermediated financial services                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vaultbank" class="ui green button">
                            13/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vaultbank" class="ui red button">
                            18/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/colulocalnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/colulocalnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/colulocalnetwork">Colu Local Network</a>
                    </h3>
                    A decentralized payment system powered by everyday consumption                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/colulocalnetwork" class="ui green button">
                            14/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/colulocalnetwork" class="ui red button">
                            18/02/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/outing" class="ui small image">
                        <img src="../../icowatchlist.com/logos/outing.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/outing">Outing</a>
                    </h3>
                    The first community app dedicated to events in real time that rewards users with its own cryptocurrency usable anywhere in the world                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/outing" class="ui green button">
                            07/01/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/outing" class="ui red button">
                            18/02/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitroad" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitroad.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitroad">BITROAD</a>
                    </h3>
                    A modern solution for reliable global money transactions                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitroad" class="ui green button">
                            16/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitroad" class="ui red button">
                            20/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/taklimakannetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/taklimakannetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/taklimakannetwork">Taklimakan Network</a>
                    </h3>
                    The Blockchain Investment Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/taklimakannetwork" class="ui green button">
                            12/12/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/taklimakannetwork" class="ui red button">
                            20/02/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/babb" class="ui small image">
                        <img src="../../icowatchlist.com/logos/babb.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/babb">BABB</a>
                    </h3>
                    Decentralised banking platform Access to a bank account for P2P financial services for anyone in the world                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/babb" class="ui green button">
                            06/02/2018 08:33                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/babb" class="ui red button">
                            21/02/2018 08:33                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/biofactorycoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/biofactorycoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/biofactorycoin">BioFactoryCoin</a>
                    </h3>
                    BioFactoryCoin BFC the first factory in the world producing healthy milk production with availability for cryptocurrency payments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/biofactorycoin" class="ui green button">
                            27/11/2017 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/biofactorycoin" class="ui red button">
                            21/02/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptotrustnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptotrustnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotrustnetwork">Crypto Trust Network</a>
                    </h3>
                    Protecting you from cryptocurrency fraud                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotrustnetwork" class="ui green button">
                            22/01/2018 18:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotrustnetwork" class="ui red button">
                            22/02/2018 18:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/localworldforwarders" class="ui small image">
                        <img src="../../icowatchlist.com/logos/localworldforwarders.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/localworldforwarders">Local World Forwarders</a>
                    </h3>
                    Local World Forwarders is the first decentralized logistics platform based on the blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/localworldforwarders" class="ui green button">
                            23/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/localworldforwarders" class="ui red button">
                            23/02/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/odyssey" class="ui small image">
                        <img src="../../icowatchlist.com/logos/odyssey.html">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/odyssey">Odyssey</a>
                    </h3>
                    ODYSSEYs mission is to build the nextgeneration decentralized sharing economy  Peer to Peer Ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/odyssey" class="ui green button">
                            23/01/2018 18:20                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/odyssey" class="ui red button">
                            23/02/2018 18:27                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/remechain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/remechain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/remechain">Remechain</a>
                    </h3>
                    A Global Market place for the safe and secure trading of secondary metals                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/remechain" class="ui green button">
                            25/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/remechain" class="ui red button">
                            25/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hoqu" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hoqu.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hoqu">HOQU</a>
                    </h3>
                    HOQU is the worlds first Decentralized Affiliate Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hoqu" class="ui green button">
                            27/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hoqu" class="ui red button">
                            25/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/paypro" class="ui small image">
                        <img src="../../icowatchlist.com/logos/paypro.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/paypro">PayPro</a>
                    </h3>
                    The first decentralized financialmarketplace as a DAO using Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/paypro" class="ui green button">
                            08/01/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/paypro" class="ui red button">
                            26/02/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/streamspace" class="ui small image">
                        <img src="../../icowatchlist.com/logos/streamspace.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/streamspace">StreamSpace</a>
                    </h3>
                    Blockchain powered Streaming Video on Demand Connecting content creators directly with consumers                 </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/streamspace" class="ui green button">
                            15/01/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/streamspace" class="ui red button">
                            27/02/2018 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/markspace" class="ui small image">
                        <img src="../../icowatchlist.com/logos/markspace.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/markspace">MARK.SPACE</a>
                    </h3>
                    MARKSPACE is worlds first opensource platform for creation of 3D VR and ARcompatible websites units and objects and for their fast integration into a single ecosystem The platform is Blockchainbased and supported by miners                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/markspace" class="ui green button">
                            23/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/markspace" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/raison" class="ui small image">
                        <img src="../../icowatchlist.com/logos/raison.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/raison">RAISON</a>
                    </h3>
                    AI Platform for investment and personal finance                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/raison" class="ui green button">
                            01/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/raison" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/rentberry" class="ui small image">
                        <img src="../../icowatchlist.com/logos/rentberry.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/rentberry">Rentberry</a>
                    </h3>
                    Decentralized Home Rental Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/rentberry" class="ui green button">
                            05/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/rentberry" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/stockchainglobal" class="ui small image">
                        <img src="../../icowatchlist.com/logos/stockchainglobal.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/stockchainglobal">Stockchain Global</a>
                    </h3>
                    Stockchain Global brings a global blockchainbased platform to the market for issuance trading and management of financial instruments                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/stockchainglobal" class="ui green button">
                            19/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/stockchainglobal" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/multigames" class="ui small image">
                        <img src="../../icowatchlist.com/logos/multigames.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/multigames">MultiGames</a>
                    </h3>
                    The first gaming online casino based on Ethereum                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/multigames" class="ui green button">
                            08/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/multigames" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hurify" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hurify.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hurify">Hurify</a>
                    </h3>
                    A Blockchain platform that aims to help SMEs build their IoT products  solution faster by connecting them to skilled IoT developers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hurify" class="ui green button">
                            01/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hurify" class="ui red button">
                            28/02/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cacaoshares" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cacaoshares.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cacaoshares">CacaoShares</a>
                    </h3>
                    Saving the Future of Chocolate using the Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cacaoshares" class="ui green button">
                            13/02/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cacaoshares" class="ui red button">
                            27/02/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/chainid" class="ui small image">
                        <img src="../../icowatchlist.com/logos/chainid.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainid">Chain ID</a>
                    </h3>
                    Platform for keeping personal diplomas certificates and licenses in blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/chainid" class="ui green button">
                            01/02/2018 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/chainid" class="ui red button">
                            28/02/2018 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dadi" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dadi.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dadi">DADI</a>
                    </h3>
                    A new era of cloud computing services powered by blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dadi" class="ui green button">
                            22/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dadi" class="ui red button">
                            28/02/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blocklancer" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blocklancer.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blocklancer">Blocklancer</a>
                    </h3>
                    Blocklancer is a Decentralized Autonomous Job Market DAJ on the Ethereum platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blocklancer" class="ui green button">
                            16/01/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blocklancer" class="ui red button">
                            28/02/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tradove" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tradove.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tradove">Tradove</a>
                    </h3>
                    Token based businesstobusiness B2B marketing sales and trade platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tradove" class="ui green button">
                            01/02/2018 18:21                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tradove" class="ui red button">
                            28/02/2018 18:21                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/volinex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/volinex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/volinex">Volinex</a>
                    </h3>
                    We make crypto easy                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/volinex" class="ui green button">
                            15/12/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/volinex" class="ui red button">
                            28/02/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lucyd" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lucyd.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lucyd">Lucyd</a>
                    </h3>
                    Join the Augmented Reality Revolution with Lucyd                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lucyd" class="ui green button">
                            17/10/2017 20:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lucyd" class="ui red button">
                            28/02/2018 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/datx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/datx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/datx">DATx</a>
                    </h3>
                    A Blockchain Empowered Digital Advertising Terminal                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/datx" class="ui green button">
                            11/02/2018 12:16                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/datx" class="ui red button">
                            28/02/2018 12:16                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/apex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/apex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/apex">Apex</a>
                    </h3>
                    APEX passes value and data ownership back to consumers increases marketing effectiveness data quality and customer loyalty                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/apex" class="ui green button">
                            29/01/2018 22:31                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/apex" class="ui red button">
                            28/02/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lympo" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lympo.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lympo">Lympo</a>
                    </h3>
                    Lympo is building an app a fitness wallet which will help people to reach their healthy lifestyle goals and earn tokens in return                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lympo" class="ui green button">
                            17/02/2018 22:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lympo" class="ui red button">
                            28/02/2018 22:31                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nucleusvision" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nucleusvision.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nucleusvision">Nucleus.Vision</a>
                    </h3>
                    An IoTbased contactless identification system that empowers retailers to identify and better serve their customers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nucleusvision" class="ui green button">
                            26/02/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nucleusvision" class="ui red button">
                            28/02/2018 23:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/credits" class="ui small image">
                        <img src="../../icowatchlist.com/logos/credits.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/credits">CREDITS</a>
                    </h3>
                    CREDITS Cryptocurrency and Blockchain platform for the financial industry with more than 1 mln txsec and 001 sec for a transaction                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/credits" class="ui green button">
                            15/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/credits" class="ui red button">
                            28/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vionex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vionex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vionex">Vionex</a>
                    </h3>
                    Vionex is a revolutionary blockchainbased smart home system                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vionex" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vionex" class="ui red button">
                            28/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/minerdog" class="ui small image">
                        <img src="../../icowatchlist.com/logos/minerdog.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/minerdog">MinerDog</a>
                    </h3>
                    MinerDog coin pays you monthly dividends in Ether from profits of our crypto mining operations                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/minerdog" class="ui green button">
                            17/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/minerdog" class="ui red button">
                            28/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/napoleonx" class="ui small image">
                        <img src="../../icowatchlist.com/logos/napoleonx.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/napoleonx">NapoleonX</a>
                    </h3>
                    The first 100 algorithmic crypto asset manager                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/napoleonx" class="ui green button">
                            22/01/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/napoleonx" class="ui red button">
                            28/02/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptohawk" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptohawk.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohawk">CryptoHawk</a>
                    </h3>
                    The worlds first AllinOne solution for cryptocurrencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohawk" class="ui green button">
                            31/12/2017 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptohawk" class="ui red button">
                            28/02/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/deex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/deex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/deex">DEEX</a>
                    </h3>
                    The first ever created decentralized platform for convenient cryptocurrency trading                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/deex" class="ui green button">
                            10/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/deex" class="ui red button">
                            28/02/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kyclegal" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kyclegal.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kyclegal">KYC.LEGAL</a>
                    </h3>
                    KYCLEGAL is the identity verification platform on a blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kyclegal" class="ui green button">
                            29/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kyclegal" class="ui red button">
                            01/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/corusblock" class="ui small image">
                        <img src="../../icowatchlist.com/logos/corusblock.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/corusblock">Corusblock</a>
                    </h3>
                    Corusblock is the next generation of cryptocurrency Lending staking mining in best performance This is Corusblock                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/corusblock" class="ui green button">
                            01/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/corusblock" class="ui red button">
                            01/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/watertech" class="ui small image">
                        <img src="../../icowatchlist.com/logos/watertech.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/watertech">WaterTech</a>
                    </h3>
                    Affordable clean water for everyone under the sun                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/watertech" class="ui green button">
                            21/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/watertech" class="ui red button">
                            01/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/medicalchain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/medicalchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/medicalchain">MedicalChain</a>
                    </h3>
                    Blockchain technology for secure storage and transfer of electronic health records It provides the infrastructure for digital health applications                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/medicalchain" class="ui green button">
                            01/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/medicalchain" class="ui red button">
                            01/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/echat" class="ui small image">
                        <img src="../../icowatchlist.com/logos/echat.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/echat">e-Chat</a>
                    </h3>
                    Blockchainbased decentralized secure messenger and fastestgrowing social network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/echat" class="ui green button">
                            08/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/echat" class="ui red button">
                            01/03/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/electrifyasia" class="ui small image">
                        <img src="../../icowatchlist.com/logos/electrifyasia.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/electrifyasia">Electrify.asia</a>
                    </h3>
                    ELECTRIFY is the first retail electricity marketplace in SoutheastAsia addressing the need for transparency and security                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/electrifyasia" class="ui green button">
                            13/02/2018 21:25                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/electrifyasia" class="ui red button">
                            01/03/2018 21:26                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/helbizcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/helbizcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/helbizcoin">Helbiz Coin</a>
                    </h3>
                    Helbiz is a decentralized transportation marketplace that makes renting a vehicle convenient affordable and rewarding                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/helbizcoin" class="ui green button">
                            26/01/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/helbizcoin" class="ui red button">
                            04/03/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/daneel" class="ui small image">
                        <img src="../../icowatchlist.com/logos/daneel.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/daneel">Daneel</a>
                    </h3>
                    Daneel purpose is to bring data intelligence into the crypto jungle                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/daneel" class="ui green button">
                            29/01/2018 13:21                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/daneel" class="ui red button">
                            05/03/2018 13:21                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ip-sharing-exchange" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ip-sharing-exchange.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ip-sharing-exchange">IP Sharing Exchange</a>
                    </h3>
                    IPSX is the first truly decentralized IP Sharing Exchange that will create a distributed network layer                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ip-sharing-exchange" class="ui green button">
                            28/02/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ip-sharing-exchange" class="ui red button">
                            05/03/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/jet8" class="ui small image">
                        <img src="../../icowatchlist.com/logos/jet8.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/jet8">Jet8</a>
                    </h3>
                    JET8 is a decentralized mobile engagement network connecting influencers audiences and brands through the value of social currency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/jet8" class="ui green button">
                            28/02/2018 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/jet8" class="ui red button">
                            06/03/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/havven" class="ui small image">
                        <img src="../../icowatchlist.com/logos/havven.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/havven">Havven</a>
                    </h3>
                    A decentralised payment network and stable coin                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/havven" class="ui green button">
                            28/02/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/havven" class="ui red button">
                            07/03/2018 07:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/serenity" class="ui small image">
                        <img src="../../icowatchlist.com/logos/serenity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/serenity">Serenity</a>
                    </h3>
                    The First Blockchain Escrow for Financial Markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/serenity" class="ui green button">
                            25/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/serenity" class="ui red button">
                            07/03/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/phi-token" class="ui small image">
                        <img src="../../icowatchlist.com/logos/phi-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/phi-token">PHI Token</a>
                    </h3>
                    The Alibaba of Wealth Management PHI means Platform for Hybrid Investments but also Hybrid Platform for Investing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/phi-token" class="ui green button">
                            03/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/phi-token" class="ui red button">
                            08/03/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/telegram-ico" class="ui small image">
                        <img src="../../icowatchlist.com/logos/telegram-ico.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/telegram-ico">Telegram</a>
                    </h3>
                    UltraFast Blockchain technology from Telegram messenger                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/telegram-ico" class="ui green button">
                            08/03/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/telegram-ico" class="ui red button">
                            08/03/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dogezer" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dogezer.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dogezer">Dogezer</a>
                    </h3>
                    DoSoftwareTogether  Dogezer is a software development platform that allows team members to become product investors by investing their time and labor                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dogezer" class="ui green button">
                            15/01/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dogezer" class="ui red button">
                            08/03/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ocean-protocol" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ocean-protocol.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ocean-protocol">Ocean protocol</a>
                    </h3>
                    Ocean Protocol is an ecosystem for sharing data and associated services                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ocean-protocol" class="ui green button">
                            07/03/2018 01:07                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ocean-protocol" class="ui red button">
                            09/03/2018 01:07                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ethic-hub" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ethic-hub.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethic-hub">Ethic Hub</a>
                    </h3>
                    Decentralized Crowdlending  Maximize returns from your money                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ethic-hub" class="ui green button">
                            08/02/2018 14:24                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ethic-hub" class="ui red button">
                            09/03/2018 14:24                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/safehaven" class="ui small image">
                        <img src="../../icowatchlist.com/logos/safehaven.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/safehaven">Safe Haven</a>
                    </h3>
                    The first inheritable digital asset                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/safehaven" class="ui green button">
                            24/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/safehaven" class="ui red button">
                            10/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptotask" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptotask.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotask">Cryptotask</a>
                    </h3>
                    First fully scalable decentralized freelance task market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotask" class="ui green button">
                            03/02/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptotask" class="ui red button">
                            10/03/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/scrinium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/scrinium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/scrinium">Scrinium</a>
                    </h3>
                    The future of portfolio investment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/scrinium" class="ui green button">
                            11/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/scrinium" class="ui red button">
                            11/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sp8de" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sp8de.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sp8de">Sp8de</a>
                    </h3>
                    Sp8de is a blockchainbased platform capable of supplying unbiased public randomness for developing and running distributed gaming apps                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sp8de" class="ui green button">
                            08/01/2018 10:18                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sp8de" class="ui red button">
                            11/03/2018 10:18                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/leadcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/leadcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/leadcoin">LeadCoin</a>
                    </h3>
                    A Decentralized Lead Sharing Network The blockchain technology feature of the LeadCoin platform enables realtime lead sharing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/leadcoin" class="ui green button">
                            01/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/leadcoin" class="ui red button">
                            11/03/2018 10:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptaur" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptaur.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptaur">Cryptaur</a>
                    </h3>
                    dApps launchpad and global marketplace without middlemen                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptaur" class="ui green button">
                            27/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptaur" class="ui red button">
                            12/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/refereum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/refereum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/refereum">Refereum</a>
                    </h3>
                    Refereum cuts out the marketing middleman by directly rewarding influencers and gamers to promote and play video games                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/refereum" class="ui green button">
                            12/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/refereum" class="ui red button">
                            12/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/travelchainproject" class="ui small image">
                        <img src="../../icowatchlist.com/logos/travelchainproject.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/travelchainproject">TravelChain Project</a>
                    </h3>
                    DECENTRALIZED DATA EXCHANGE FOR THE TRAVEL INDUSTRY where travelers and businesses profit from sharing their info                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/travelchainproject" class="ui green button">
                            15/12/2017 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/travelchainproject" class="ui red button">
                            12/03/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/myoddzbet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/myoddzbet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/myoddzbet">MyOddz.bet</a>
                    </h3>
                    Ethereum Blockchain Betting  Gambling with Profit Share                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/myoddzbet" class="ui green button">
                            12/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/myoddzbet" class="ui red button">
                            12/03/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/prodeum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/prodeum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/prodeum">Prodeum</a>
                    </h3>
                    Tracking produce on the Ethereum blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/prodeum" class="ui green button">
                            20/01/2018 06:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/prodeum" class="ui red button">
                            13/03/2018 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/play2live" class="ui small image">
                        <img src="../../icowatchlist.com/logos/play2live.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/play2live">Play2live</a>
                    </h3>
                    The first decentralized streaming platform for gamers and eSports fans                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/play2live" class="ui green button">
                            21/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/play2live" class="ui red button">
                            14/03/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/viso" class="ui small image">
                        <img src="../../icowatchlist.com/logos/viso.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/viso">VISO</a>
                    </h3>
                    VISO is a payment system that combines cryptocurrencies and traditional bank cards and terminals into one ecosystem                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/viso" class="ui green button">
                            25/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/viso" class="ui red button">
                            15/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dragoninc" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dragoninc.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dragoninc">Dragon Inc</a>
                    </h3>
                    Bringing Gaming into the 21st Century                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dragoninc" class="ui green button">
                            15/02/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dragoninc" class="ui red button">
                            15/03/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/syncfab" class="ui small image">
                        <img src="../../icowatchlist.com/logos/syncfab.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/syncfab">SyncFab</a>
                    </h3>
                    Decentralized hardware manufacturing Syncfab helps to make use of Smart Manufacturing Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/syncfab" class="ui green button">
                            15/02/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/syncfab" class="ui red button">
                            15/03/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/denaro" class="ui small image">
                        <img src="../../icowatchlist.com/logos/denaro.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/denaro">DENARO</a>
                    </h3>
                    Cryptocurrency wallet and worldwide debit cards                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/denaro" class="ui green button">
                            09/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/denaro" class="ui red button">
                            15/03/2018 11:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/aiom" class="ui small image">
                        <img src="../../icowatchlist.com/logos/aiom.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/aiom">AIOM</a>
                    </h3>
                    Medical analysis and research artificial intelligence application                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/aiom" class="ui green button">
                            15/02/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/aiom" class="ui red button">
                            15/03/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/capdax" class="ui small image">
                        <img src="../../icowatchlist.com/logos/capdax.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/capdax">Capdax</a>
                    </h3>
                    Capdax is one of the first exchanges that introduces premium customer service social trading and infrastructure stability                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/capdax" class="ui green button">
                            17/02/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/capdax" class="ui red button">
                            17/03/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/valid" class="ui small image">
                        <img src="../../icowatchlist.com/logos/valid.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/valid">VALID</a>
                    </h3>
                    VALID is a fully integrated personal data management platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/valid" class="ui green button">
                            24/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/valid" class="ui red button">
                            17/03/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/egold" class="ui small image">
                        <img src="../../icowatchlist.com/logos/egold.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/egold">eGold</a>
                    </h3>
                    The ultimate eSports betting cryptocurrency                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/egold" class="ui green button">
                            01/02/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/egold" class="ui red button">
                            18/03/2018 20:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/globitex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/globitex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/globitex">Globitex</a>
                    </h3>
                    An institutionalgrade cryptocurrency exchange allowing everyone to trade commodities and money market instruments for Bitcoin                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/globitex" class="ui green button">
                            10/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/globitex" class="ui red button">
                            19/03/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/opporty" class="ui small image">
                        <img src="../../icowatchlist.com/logos/opporty.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/opporty">Opporty</a>
                    </h3>
                    Opporty is a decentralized service marketplace and selfregulated knowledgesharing community platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/opporty" class="ui green button">
                            01/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/opporty" class="ui red button">
                            20/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/adhive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/adhive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/adhive">AdHive</a>
                    </h3>
                    The first AIpowered platform for influencer marketing                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/adhive" class="ui green button">
                            21/02/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/adhive" class="ui red button">
                            21/03/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/viewly" class="ui small image">
                        <img src="../../icowatchlist.com/logos/viewly.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/viewly">Viewly</a>
                    </h3>
                    Viewly is a decentralized video platform powered by blockchain and peertopeer video sharing technologies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/viewly" class="ui green button">
                            22/02/2018 08:18                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/viewly" class="ui red button">
                            22/03/2018 08:18                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cappasity" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cappasity.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cappasity">Cappasity</a>
                    </h3>
                    Decentralized ARVR ecosystem for 3D content exchange                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cappasity" class="ui green button">
                            22/02/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cappasity" class="ui red button">
                            22/03/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/origami-network" class="ui small image">
                        <img src="../../icowatchlist.com/logos/origami-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/origami-network">Origami Network</a>
                    </h3>
                    BlockchainPowered global solution that builds decentralized online marketplaces faster and easier than current models                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/origami-network" class="ui green button">
                            23/02/2018 13:19                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/origami-network" class="ui red button">
                            23/03/2018 13:19                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cryptonkafe" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cryptonkafe.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonkafe">Crypto N Kafe</a>
                    </h3>
                    First coffee trading ecosystem entirely supporting smallscale farmers traders roasters and retailers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonkafe" class="ui green button">
                            18/01/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cryptonkafe" class="ui red button">
                            25/03/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fundfantasy" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fundfantasy.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fundfantasy">FundFantasy</a>
                    </h3>
                    FundFantasy is an online social platform featuring peertopeer provablyfair simulated investing contests                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fundfantasy" class="ui green button">
                            25/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fundfantasy" class="ui red button">
                            25/03/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vestopia" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vestopia.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vestopia">Vestopia</a>
                    </h3>
                    Vestopia is a decentralized peertopeer investment ecosystem connecting the mass population to wealth and investment opportunities in an unprecedented model                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vestopia" class="ui green button">
                            25/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vestopia" class="ui red button">
                            26/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/exenium" class="ui small image">
                        <img src="../../icowatchlist.com/logos/exenium.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/exenium">Exenium</a>
                    </h3>
                    EXENIUM is a fullyfunctional cryptocurrency exchange implemented as a chatbot for messengers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/exenium" class="ui green button">
                            14/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/exenium" class="ui red button">
                            26/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/selfllery" class="ui small image">
                        <img src="../../icowatchlist.com/logos/selfllery.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/selfllery">SELFLLERY</a>
                    </h3>
                    The Social Platform for Visual Content Monetization                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/selfllery" class="ui green button">
                            05/03/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/selfllery" class="ui red button">
                            26/03/2018 09:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gilgamesh" class="ui small image">
                        <img src="../../icowatchlist.com/logos/gilgamesh.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gilgamesh">Gilgamesh</a>
                    </h3>
                    KnowledgeSharing social network platform powered by Ethereum Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gilgamesh" class="ui green button">
                            16/01/2018 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gilgamesh" class="ui red button">
                            26/03/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/booleancoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/booleancoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/booleancoin">Booleancoin</a>
                    </h3>
                    Booleancoin Powers Boolean A News Accuracy Platform Aiming To Combat Fake News In The Media                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/booleancoin" class="ui green button">
                            01/11/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/booleancoin" class="ui red button">
                            27/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/namitrade" class="ui small image">
                        <img src="../../icowatchlist.com/logos/namitrade.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/namitrade">Nami.trade</a>
                    </h3>
                    A blockchain broker which will bring no spread no swap and no commission to traders worldwide                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/namitrade" class="ui green button">
                            31/01/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/namitrade" class="ui red button">
                            28/03/2018 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/winco" class="ui small image">
                        <img src="../../icowatchlist.com/logos/winco.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/winco">Winco</a>
                    </h3>
                    Solutions for the decentralization of startups financing the franchise market and the real estate market                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/winco" class="ui green button">
                            19/02/2018 09:14                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/winco" class="ui red button">
                            29/03/2018 09:15                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/joy-token" class="ui small image">
                        <img src="../../icowatchlist.com/logos/joy-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/joy-token">Joy Token</a>
                    </h3>
                    Joy Token is a new development platform specifically for the creation and marketing of online casino games                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/joy-token" class="ui green button">
                            27/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/joy-token" class="ui red button">
                            29/03/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wawllet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wawllet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wawllet">WAWLLET</a>
                    </h3>
                    Worlds first multiasset wallet and personal financial passport                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wawllet" class="ui green button">
                            29/01/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wawllet" class="ui red button">
                            30/03/2018 09:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/oxalor" class="ui small image">
                        <img src="../../icowatchlist.com/logos/oxalor.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/oxalor">CDG</a>
                    </h3>
                    Technology which covers the treatment process of raw domestic waste and green waste from agriculture                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/oxalor" class="ui green button">
                            15/03/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/oxalor" class="ui red button">
                            30/03/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/requitix" class="ui small image">
                        <img src="../../icowatchlist.com/logos/requitix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/requitix">Requitix</a>
                    </h3>
                    Trusted Token and Confidence System                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/requitix" class="ui green button">
                            20/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/requitix" class="ui red button">
                            31/03/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ensbid" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ensbid.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ensbid">ENS.BID</a>
                    </h3>
                    ENSBID focuses on offering the best identity storage and domain name service to the decentralized world of Ethereum                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ensbid" class="ui green button">
                            10/01/2018 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ensbid" class="ui red button">
                            31/03/2018 01:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/wikibits" class="ui small image">
                        <img src="../../icowatchlist.com/logos/wikibits.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/wikibits">Wikibits</a>
                    </h3>
                    Be Part of the Next Generation Wiki                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/wikibits" class="ui green button">
                            15/12/2017 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/wikibits" class="ui red button">
                            31/03/2018 05:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/pitch" class="ui small image">
                        <img src="../../icowatchlist.com/logos/pitch.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/pitch">Pitch</a>
                    </h3>
                    Entrepreneurs and Startups can Pitch Investors Live on the Platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/pitch" class="ui green button">
                            28/02/2018 05:55                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/pitch" class="ui red button">
                            31/03/2018 05:55                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/thought" class="ui small image">
                        <img src="../../icowatchlist.com/logos/thought.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/thought">Thought</a>
                    </h3>
                    Eliminate Traditional Applications with Data That Thinks                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/thought" class="ui green button">
                            01/03/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/thought" class="ui red button">
                            31/03/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/crowdholding" class="ui small image">
                        <img src="../../icowatchlist.com/logos/crowdholding.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdholding">Crowdholding</a>
                    </h3>
                    A Decentralized Open Innovation platform that connects entrepreneurs and supporters                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdholding" class="ui green button">
                            01/11/2017 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/crowdholding" class="ui red button">
                            31/03/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitrent" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitrent.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrent">BitRent</a>
                    </h3>
                    First decentralized Blockchain construction platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrent" class="ui green button">
                            24/11/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitrent" class="ui red button">
                            31/03/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/beefcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/beefcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/beefcoin">BeefCoin</a>
                    </h3>
                    Integrated production of organic beef from farm to table                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/beefcoin" class="ui green button">
                            01/01/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/beefcoin" class="ui red button">
                            31/03/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fortysevenbank" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fortysevenbank.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fortysevenbank">Forty Seven Bank</a>
                    </h3>
                    Forty Seven Bank is financial technology startup aimed at building a bridge between cryptocurrency world and the world of traditional monetary finance                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fortysevenbank" class="ui green button">
                            16/11/2017 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fortysevenbank" class="ui red button">
                            31/03/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/handelion" class="ui small image">
                        <img src="../../icowatchlist.com/logos/handelion.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/handelion">Handelion</a>
                    </h3>
                    Handelion is a revolutionary blockchain ecosystem for cofunded wholesale trade                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/handelion" class="ui green button">
                            15/12/2017 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/handelion" class="ui red button">
                            31/03/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/tutellus" class="ui small image">
                        <img src="../../icowatchlist.com/logos/tutellus.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/tutellus">Tutellus</a>
                    </h3>
                    The platform that pays you for learning                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/tutellus" class="ui green button">
                            18/12/2017 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/tutellus" class="ui red button">
                            31/03/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/abchain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/abchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/abchain">AB-CHAIN</a>
                    </h3>
                    ABCHAIN ADVERTISING NETWORK  Blockchain and AI for enhanced campaigns                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/abchain" class="ui green button">
                            19/02/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/abchain" class="ui red button">
                            31/03/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/galaxyesolutions" class="ui small image">
                        <img src="../../icowatchlist.com/logos/galaxyesolutions.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxyesolutions">Galaxy eSolutions</a>
                    </h3>
                    A global distribution and ecommerce marketplace for refurbished consumer electronics                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxyesolutions" class="ui green button">
                            28/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/galaxyesolutions" class="ui red button">
                            31/03/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/skychain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/skychain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/skychain">Skychain</a>
                    </h3>
                    Blockchain infrastructure aimed to host train and use artificial intelligence AI in healthcare                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/skychain" class="ui green button">
                            25/02/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/skychain" class="ui red button">
                            31/03/2018 22:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/clearcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/clearcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/clearcoin">Clearcoin</a>
                    </h3>
                    ClearCoin is a technology company that powers the realtime buying and selling of media on decentralized applications and the broader digital environment                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/clearcoin" class="ui green button">
                            16/11/2017 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/clearcoin" class="ui red button">
                            01/04/2018 07:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/eroiy" class="ui small image">
                        <img src="../../icowatchlist.com/logos/eroiy.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/eroiy">Eroiy</a>
                    </h3>
                    The anonymous and safe payment method of the adult industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/eroiy" class="ui green button">
                            30/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/eroiy" class="ui red button">
                            31/03/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/fabrictoken" class="ui small image">
                        <img src="../../icowatchlist.com/logos/fabrictoken.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/fabrictoken">Fabric Token</a>
                    </h3>
                    Draganddrop smart contracts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/fabrictoken" class="ui green button">
                            15/02/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/fabrictoken" class="ui red button">
                            01/04/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/the-coffee-token" class="ui small image">
                        <img src="../../icowatchlist.com/logos/the-coffee-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/the-coffee-token">The Coffee Token</a>
                    </h3>
                    First and only global decentralized ecosystem directly connecting coffee producers and consumers using the blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/the-coffee-token" class="ui green button">
                            14/02/2018 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/the-coffee-token" class="ui red button">
                            01/04/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/true-reply" class="ui small image">
                        <img src="../../icowatchlist.com/logos/true-reply.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/true-reply">True Reply</a>
                    </h3>
                    True Reply is the future of voicebased datacollection across IoT devices and telephones                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/true-reply" class="ui green button">
                            01/03/2018 18:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/true-reply" class="ui red button">
                            01/04/2018 18:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/paysura" class="ui small image">
                        <img src="../../icowatchlist.com/logos/paysura.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/paysura">PAYSURA</a>
                    </h3>
                    PAYSURA is providing the International PayReward Coin IPC in order to create a worldwide uniform reward system that applies the advantages of the Blockchain Technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/paysura" class="ui green button">
                            03/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/paysura" class="ui red button">
                            02/04/2018 12:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nkor" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nkor.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nkor">Nkor</a>
                    </h3>
                    Solving copyright issues forever                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nkor" class="ui green button">
                            03/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nkor" class="ui red button">
                            02/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hashbux" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hashbux.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hashbux">HASHBUX</a>
                    </h3>
                    Decentralized online Gaming EcoSystem for Gamers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hashbux" class="ui green button">
                            26/03/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hashbux" class="ui red button">
                            03/04/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bittoexchange" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bittoexchange.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bittoexchange">BITTO Exchange</a>
                    </h3>
                    Bitcoin Exchange with 6 in 1 consisting of LendingStakingSignalReferralBorrowingTrading                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bittoexchange" class="ui green button">
                            16/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bittoexchange" class="ui red button">
                            03/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ether-legends-elet" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ether-legends-elet.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ether-legends-elet">Ether Legends (ELET)</a>
                    </h3>
                    Ethereum Based Collectible Trading Card Game driven by the gaming platform token elementeum ELET                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ether-legends-elet" class="ui green button">
                            15/02/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ether-legends-elet" class="ui red button">
                            04/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/amon" class="ui small image">
                        <img src="../../icowatchlist.com/logos/amon.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/amon">Amon</a>
                    </h3>
                    Enabling crypto spending in everyday life                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/amon" class="ui green button">
                            04/03/2018 09:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/amon" class="ui red button">
                            04/04/2018 09:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vestarin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vestarin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vestarin">Vestarin</a>
                    </h3>
                    Cryptocurrency market place for goods and services                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vestarin" class="ui green button">
                            05/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vestarin" class="ui red button">
                            04/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/thrive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/thrive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/thrive">Thrive</a>
                    </h3>
                    Blockchainbased Decentralized Advertising Marketplace                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/thrive" class="ui green button">
                            15/02/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/thrive" class="ui red button">
                            05/04/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/r3sec" class="ui small image">
                        <img src="../../icowatchlist.com/logos/r3sec.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/r3sec">R3SEC</a>
                    </h3>
                    Moving target defense  ultimate security on blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/r3sec" class="ui green button">
                            20/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/r3sec" class="ui red button">
                            05/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/repux" class="ui small image">
                        <img src="../../icowatchlist.com/logos/repux.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/repux">RepuX</a>
                    </h3>
                    RepuXs blockchainbacked platform enables Small and Medium Enterprises SMEs to securely sell their data                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/repux" class="ui green button">
                            06/03/2018 06:17                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/repux" class="ui red button">
                            05/04/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bank-of-hash-power" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bank-of-hash-power.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bank-of-hash-power">Bank of Hash Power</a>
                    </h3>
                    The blockchain financial system guaranteed by Hash Power enable easiest access to crypto portfolio and trade settlement for EVERYONE                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bank-of-hash-power" class="ui green button">
                            07/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bank-of-hash-power" class="ui red button">
                            05/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/renteum" class="ui small image">
                        <img src="../../icowatchlist.com/logos/renteum.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/renteum">Renteum</a>
                    </h3>
                    Renteum is going to be the first of its kind to tie its token to realestate in Scandinavia and England                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/renteum" class="ui green button">
                            03/01/2018 23:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/renteum" class="ui red button">
                            07/04/2018 23:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bills" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bills.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bills">Bills</a>
                    </h3>
                    Bills is a technology that allows placing advertisements to an outdoor billboard located in any part of the world within a couple of minutes                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bills" class="ui green button">
                            08/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bills" class="ui red button">
                            08/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sandblock" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sandblock.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sandblock">Sandblock</a>
                    </h3>
                    Rewarding customers for their loyalty engagement and feedback using cryptocurrencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sandblock" class="ui green button">
                            21/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sandblock" class="ui red button">
                            08/04/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/vlb" class="ui small image">
                        <img src="../../icowatchlist.com/logos/vlb.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/vlb">VLB</a>
                    </h3>
                    The number one blockchain fuel for the transport industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/vlb" class="ui green button">
                            05/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/vlb" class="ui red button">
                            09/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/signalsnetwork" class="ui small image">
                        <img src="../../icowatchlist.com/logos/signalsnetwork.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/signalsnetwork">Signals Network</a>
                    </h3>
                    Data science marketplace to help you discover create and monetize cryptocurrency trading                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/signalsnetwork" class="ui green button">
                            12/03/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/signalsnetwork" class="ui red button">
                            09/04/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/gizer" class="ui small image">
                        <img src="../../icowatchlist.com/logos/gizer.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/gizer">Gizer</a>
                    </h3>
                    The real global gaming network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/gizer" class="ui green button">
                            16/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/gizer" class="ui red button">
                            10/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/md-tokens" class="ui small image">
                        <img src="../../icowatchlist.com/logos/md-tokens.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/md-tokens">MD Tokens</a>
                    </h3>
                    Creating a universal digital payment engine to power a smart secure and efficient healthcare ecosystem accessible anywhere at anytime                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/md-tokens" class="ui green button">
                            10/03/2018 16:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/md-tokens" class="ui red button">
                            10/04/2018 16:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/cubaaz" class="ui small image">
                        <img src="../../icowatchlist.com/logos/cubaaz.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/cubaaz">CUBAAZ</a>
                    </h3>
                    Travel for a Blockchain Era  Pay for goods and services whiles enjoying great discounts                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/cubaaz" class="ui green button">
                            05/01/2018 23:59                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/cubaaz" class="ui red button">
                            10/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/onlive" class="ui small image">
                        <img src="../../icowatchlist.com/logos/onlive.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/onlive">On.Live</a>
                    </h3>
                    An open and decentralized platform for video broadcast and remote consultations markets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/onlive" class="ui green button">
                            11/03/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/onlive" class="ui red button">
                            11/04/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/rxeal" class="ui small image">
                        <img src="../../icowatchlist.com/logos/rxeal.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/rxeal">RxEAL</a>
                    </h3>
                    The latest way to profit from Real Estate                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/rxeal" class="ui green button">
                            12/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/rxeal" class="ui red button">
                            11/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/flogmall" class="ui small image">
                        <img src="../../icowatchlist.com/logos/flogmall.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/flogmall">FLOGmall</a>
                    </h3>
                    An international ecommerce site created for users  from all over the world who sell and buy various products and services with tokens                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/flogmall" class="ui green button">
                            22/03/2018 04:59                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/flogmall" class="ui red button">
                            12/04/2018 04:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/mosaic" class="ui small image">
                        <img src="../../icowatchlist.com/logos/mosaic.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/mosaic">Mosaic</a>
                    </h3>
                    Decentralized Market Intelligence Network for Publishers and Stakeholders                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/mosaic" class="ui green button">
                            14/02/2018 20:56                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/mosaic" class="ui red button">
                            12/04/2018 20:56                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/violaai" class="ui small image">
                        <img src="../../icowatchlist.com/logos/violaai.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/violaai">Viola.AI</a>
                    </h3>
                    ViolaAI is the Worlds First AIdriven Marketplace for Dating and Relationships with real business backing of 13 years                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/violaai" class="ui green button">
                            14/03/2018 04:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/violaai" class="ui red button">
                            13/04/2018 04:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/iolite" class="ui small image">
                        <img src="../../icowatchlist.com/logos/iolite.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/iolite">iOlite</a>
                    </h3>
                    iOlite allows anyone to write smart contract using any language natural or programming                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/iolite" class="ui green button">
                            27/03/2018 05:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/iolite" class="ui red button">
                            14/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/moxyone" class="ui small image">
                        <img src="../../icowatchlist.com/logos/moxyone.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/moxyone">MoxyOne</a>
                    </h3>
                    Branded debit cards and secure payment infrastructure for all companies and ICOs that issue cryptocurrencies                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/moxyone" class="ui green button">
                            14/03/2018 01:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/moxyone" class="ui red button">
                            14/04/2018 01:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/rentaway" class="ui small image">
                        <img src="../../icowatchlist.com/logos/rentaway.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/rentaway">RentAway</a>
                    </h3>
                    RentAway is an online global platform the unique rental marketplace that will facilitate rental transactions between private individuals peertopeer and businesses for a wide range of goods equipment and real estate                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/rentaway" class="ui green button">
                            01/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/rentaway" class="ui red button">
                            15/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/neurochain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/neurochain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/neurochain">NeuroChain</a>
                    </h3>
                    Implementing AI at the heart of the Blockchain                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/neurochain" class="ui green button">
                            19/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/neurochain" class="ui red button">
                            15/04/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/nativevideobox" class="ui small image">
                        <img src="../../icowatchlist.com/logos/nativevideobox.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/nativevideobox">Native Video Box</a>
                    </h3>
                    An independent video distribution platform with native eco approach to advertising based on machine learning                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/nativevideobox" class="ui green button">
                            01/12/2017 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/nativevideobox" class="ui red button">
                            15/04/2018 11:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/midex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/midex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/midex">Midex</a>
                    </h3>
                    Midex makes cryptocurrency use accessible to business traders and everyday users Midex is a financial ecosystem which encompasses the needs of each economic agent through a fully licensed and encrypted exchange                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/midex" class="ui green button">
                            15/01/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/midex" class="ui red button">
                            15/04/2018 23:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/node" class="ui small image">
                        <img src="../../icowatchlist.com/logos/node.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/node">Node</a>
                    </h3>
                    Intelligent Technology for Wireless Energy For Private and Commercial Use                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/node" class="ui green button">
                            14/02/2018 22:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/node" class="ui red button">
                            15/04/2018 22:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitether" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitether.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitether">BITETHER</a>
                    </h3>
                    Dapp for gaming tournament and lending platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitether" class="ui green button">
                            16/03/2018 00:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitether" class="ui red button">
                            16/04/2018 00:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/blockpix" class="ui small image">
                        <img src="../../icowatchlist.com/logos/blockpix.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpix">BLOCKPIX</a>
                    </h3>
                    Ecommerce Solution for the Creative and Entertainment Industry                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpix" class="ui green button">
                            18/03/2018 10:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/blockpix" class="ui red button">
                            18/04/2018 10:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/hamster-marketplace" class="ui small image">
                        <img src="../../icowatchlist.com/logos/hamster-marketplace.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/hamster-marketplace">Hamster Marketplace</a>
                    </h3>
                    Decentralized trading platform for sale of innovative indiegadgets run by manufacturers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/hamster-marketplace" class="ui green button">
                            18/02/2018 21:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/hamster-marketplace" class="ui red button">
                            18/04/2018 21:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/moneytap-token" class="ui small image">
                        <img src="../../icowatchlist.com/logos/moneytap-token.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytap-token">MoneyTap Token</a>
                    </h3>
                    App that allows bank customers to settle transactions instantly                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytap-token" class="ui green button">
                            23/03/2018 08:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/moneytap-token" class="ui red button">
                            19/04/2018 08:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/giftcoin" class="ui small image">
                        <img src="../../icowatchlist.com/logos/giftcoin.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/giftcoin">Giftcoin</a>
                    </h3>
                    Giftcoin is a groundbreaking new system designed to revolutionise charitable giving                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/giftcoin" class="ui green button">
                            20/03/2018 14:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/giftcoin" class="ui red button">
                            19/04/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/benebit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/benebit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/benebit">Benebit</a>
                    </h3>
                    Benebit is a global decentralized ecosystem that enables interaction without borders between brands companies and consumers and is built on Blockchain technology                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/benebit" class="ui green button">
                            22/01/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/benebit" class="ui red button">
                            19/04/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/xyo-network" class="ui small image">
                        <img src="../../icowatchlist.com/logos/xyo-network.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/xyo-network">XYO Network</a>
                    </h3>
                    With over 1 million locationverifying beacons already in the world XYO is blockchain39s first cryptolocation oracle network                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/xyo-network" class="ui green button">
                            20/03/2018 08:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/xyo-network" class="ui red button">
                            20/04/2018 08:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/sportscastr-fanchain" class="ui small image">
                        <img src="../../icowatchlist.com/logos/sportscastr-fanchain.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/sportscastr-fanchain">SportsCastr FanChain</a>
                    </h3>
                    Sports Token and Decentralized Ecosystem That Knows Your Favorite Team                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/sportscastr-fanchain" class="ui green button">
                            19/04/2018 02:25                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/sportscastr-fanchain" class="ui red button">
                            20/04/2018 02:25                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/ponder" class="ui small image">
                        <img src="../../icowatchlist.com/logos/ponder.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/ponder">Ponder</a>
                    </h3>
                    A decentralized matchmaking platform revolutionizing how people meet                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/ponder" class="ui green button">
                            14/02/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/ponder" class="ui red button">
                            20/04/2018 06:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitcar" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitcar.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitcar">BitCar</a>
                    </h3>
                    PeertoPeer exotic car trading platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitcar" class="ui green button">
                            31/01/2018 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitcar" class="ui red button">
                            20/04/2018 07:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/rexpax" class="ui small image">
                        <img src="../../icowatchlist.com/logos/rexpax.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/rexpax">Rexpax</a>
                    </h3>
                    Rexpax encourages lending and sharing among neighbors                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/rexpax" class="ui green button">
                            20/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/rexpax" class="ui red button">
                            20/04/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/dehedge" class="ui small image">
                        <img src="../../icowatchlist.com/logos/dehedge.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/dehedge">DeHedge</a>
                    </h3>
                    RiskHedging Platform for cryptocurrency investors DeHedge helps the investor guard against market volatility                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/dehedge" class="ui green button">
                            15/03/2018 11:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/dehedge" class="ui red button">
                            20/04/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/kryllio" class="ui small image">
                        <img src="../../icowatchlist.com/logos/kryllio.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/kryllio">Kryll.io</a>
                    </h3>
                    Bringing professional trading tools to everyone                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/kryllio" class="ui green button">
                            07/02/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/kryllio" class="ui red button">
                            20/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/auctus" class="ui small image">
                        <img src="../../icowatchlist.com/logos/auctus.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/auctus">Auctus</a>
                    </h3>
                    Smart Contract Powered Retirement Plans AUCTUS Helps People Plan Ahead of Retirement                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/auctus" class="ui green button">
                            10/04/2018 14:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/auctus" class="ui red button">
                            20/04/2018 14:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/pokersports" class="ui small image">
                        <img src="../../icowatchlist.com/logos/pokersports.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/pokersports">PokerSports</a>
                    </h3>
                    Decentralized  community driven platform that integrates Blockchain iGaming eSports and Fantasy Sports                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/pokersports" class="ui green button">
                            24/02/2018 19:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/pokersports" class="ui red button">
                            21/04/2018 19:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/smrt" class="ui small image">
                        <img src="../../icowatchlist.com/logos/smrt.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/smrt">SMRT</a>
                    </h3>
                    The Smart Startup Token project is Making Blockchain Accessible to Startups and Small Businesses                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/smrt" class="ui green button">
                            24/03/2018 13:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/smrt" class="ui red button">
                            21/04/2018 13:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/lendingblock" class="ui small image">
                        <img src="../../icowatchlist.com/logos/lendingblock.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/lendingblock">Lendingblock</a>
                    </h3>
                    Fully collateralised borrowing and lending of crypto assets                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/lendingblock" class="ui green button">
                            15/04/2018 15:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/lendingblock" class="ui red button">
                            22/04/2018 15:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/alax" class="ui small image">
                        <img src="../../icowatchlist.com/logos/alax.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/alax">ALAX</a>
                    </h3>
                    The Blockchain Appstore Designed for Gamers                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/alax" class="ui green button">
                            17/04/2018 10:30                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/alax" class="ui red button">
                            23/04/2018 10:30                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/follex" class="ui small image">
                        <img src="../../icowatchlist.com/logos/follex.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/follex">FolleX</a>
                    </h3>
                    Global Cryptocurrency Exchange and interactive Social platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/follex" class="ui green button">
                            23/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/follex" class="ui red button">
                            23/04/2018 12:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/otcrit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/otcrit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/otcrit">Otcrit</a>
                    </h3>
                    Advanced Cryptocurrency Exchange and Informational Marketplace                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/otcrit" class="ui green button">
                            15/02/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/otcrit" class="ui red button">
                            23/04/2018 17:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/bitnation" class="ui small image">
                        <img src="../../icowatchlist.com/logos/bitnation.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitnation">Bitnation</a>
                    </h3>
                    Pangea Arbitration Token PAT powers the Pangea Jurisdiction                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/bitnation" class="ui green button">
                            25/03/2018 12:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/bitnation" class="ui red button">
                            24/04/2018 11:00                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/checqit" class="ui small image">
                        <img src="../../icowatchlist.com/logos/checqit.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/checqit">Checqit</a>
                    </h3>
                    The Smartest Decentralized Peertopeer lending platform                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/checqit" class="ui green button">
                            24/03/2018 17:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/checqit" class="ui red button">
                            24/04/2018 16:59                        </a>
                    </div>
                </td>
            </tr>
                    <tr>
                <td class="center aligned">
                    <a href="https://api.icowatchlist.com/public/v1/url/glu" class="ui small image">
                        <img src="../../icowatchlist.com/logos/glu.png">
                    </a>
                </td>
                <td>
                    <h3 class="ui header">
                        <a href="https://api.icowatchlist.com/public/v1/url/glu">Gluon</a>
                    </h3>
                    Gluons platform establishes an interconnected network of vehicles and owners for diagnostics                </td>
                <td class="single line">
                    <div class="ui vertical two buttons">
                        <a href="https://api.icowatchlist.com/public/v1/url/glu" class="ui green button">
                            27/03/2018 07:00                        </a>
                        <a href="https://api.icowatchlist.com/public/v1/url/glu" class="ui red button">
                            27/04/2018 21:59                        </a>
                    </div>
                </td>
            </tr>
                </tbody>
    </table>


    
</div>

    </main>

    <footer id="footer">
        <div class="ui stackable grid">

            <div id="footer-main" class="centered row">
                <div class="middle aligned five wide column">
                    <h3 class="ui header">
                        Mize Market                        <br>
                                                    <img class="ui image" src="../images/1524688786.png">
                                            </h3>
                </div>

                                                            <div class="center aligned five wide column">
                            <h3 class="ui header">Social</h3>
                            <div class="ui large list">
                                <a class="item menu-item" href="https://www.facebook.com/MizeNetworkOfficial/">Facebook&nbsp;<i class="facebook icon"></i></a><a class="item menu-item" href="https://www.youtube.com/channel/UCbLzWgvX0n1LSyltWxGMBAg">Youtube&nbsp;<i class="youtube icon"></i></a><a class="item menu-item" href="https://www.instagram.com/mizenetworkofficial/">Instagram&nbsp;<i class="instagram icon"></i></a>                            </div>
                        </div>
                                                                                <div class="center aligned five wide column">
                            <h3 class="ui header">Official Websites</h3>
                            <div class="ui large list">
                                <a class="item menu-item" href="../go/footer_2/0.html">Mize Network</a><a class="item menu-item" href="../go/footer_2/1.html">Mize Academy</a>                            </div>
                        </div>
                                                                                    </div>

            <div id="footer-bottom-bar" class="centered row">
                <div class="center aligned sixteen wide column">
                    2018 @ Mize Market -                     Powered By <a href="https://www.cryptocompare.com/" target="_blank">CryptoCompare</a>
                </div>
            </div>
        </div>
    </footer>
    <br>
</div>

<div id="donation-box" class="ui modal">
    <div class="scrolling content">
        <div class="ui icon huge message">
            <i class="hand peace icon"></i>
            <div class="content">
                <div class="header"></div>
                <div></div>
            </div>
        </div>
                    </div>
    <div class="actions">
        <div class="ui ok green button"></div>
    </div>
</div>

<div id="slide-up" class="ui yellow icon button" style="z-index: 9999; display: none;"><i class="arrow up icon"></i></div>

<script>
    //<![CDATA[
    window.CoinTableConstants = {"site_url":"http:\/\/mize.market\/","currency_page":"http:\/\/mize.market\/currency\/","price_currency":"USD"};
    //]]>
</script>
    <script src="../../cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="../../cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.js"></script>
    <script src="../../cdnjs.cloudflare.com/ajax/libs/money.js/0.2.0/money.min.js"></script>
    <script src="../assets/frontend/js/frontend.min.js"></script>


</body>

<!-- Mirrored from mize.market/icos/finished by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Apr 2018 21:02:30 GMT -->
</html>